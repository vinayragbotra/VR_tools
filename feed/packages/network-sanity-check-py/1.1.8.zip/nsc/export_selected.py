"""Package a saved selection in a disposable 3ds Max Batch session."""
from collections import Counter
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import tempfile
import time

from . import collection, maxops, scan


def export_name(value):
    name = value.strip()
    if (not name or name.endswith('.') or re.search(r'[<>:"/\\|?*\x00-\x1f]', name)
            or re.fullmatch(r'CON|PRN|AUX|NUL|COM[1-9¹²³]|LPT[1-9¹²³]', name.split('.')[0], re.I)):
        raise ValueError('Enter a valid Windows folder name.')
    return name


def package_scene(job, executable, snapshot, destination, nodes, roots, recursive, exclude):
    """Run Max off the UI thread and publish the finished folder in one rename."""
    destination = Path(destination)
    with tempfile.TemporaryDirectory(prefix='vr-export-') as temporary:
        work = Path(temporary)
        staged = Path(tempfile.mkdtemp(prefix=destination.name + '-incomplete-', dir=destination.parent))
        package = staged / 'package'
        package.mkdir()
        data = dict(snapshot=snapshot, scene=str(package / (destination.name + '.max')),
                    nodes=nodes, roots=roots, recursive=recursive, exclude=exclude)
        request = work / 'request.json'
        request.write_text(json.dumps(data), encoding='utf-8')
        script = work / 'build.py'
        script.write_text(
            f'import sys\nsys.path.insert(0, {str(Path(__file__).resolve().parents[1])!r})\n'
            f'from nsc.export_selected import build\nbuild({str(request)!r})\n', encoding='utf-8')
        env = os.environ.copy()
        for key, name in (
            ('ADSK_3DSMAX_APPDATA_DIR', 'profile'),
            ('ADSK_3DSMAX_USERSETTINGS_DIR', 'settings'),
            ('ADSK_3DSMAX_USERTOOLS_DIR', 'tools'),
            ('ADSK_3DSMAX_STARTUPSCRIPTS_ADDON_DIR', 'startup'),
        ):
            env[key] = str(work / name)
        progress = work / 'progress.txt'
        cancel = work / 'cancel'
        job.frac = None
        job.text = 'Starting the export session...'
        try:
            with (work / 'batch.log').open('wb') as log:
                child = subprocess.Popen([str(executable), str(script)], env=env,
                                         stdout=log, stderr=subprocess.STDOUT,
                                         creationflags=subprocess.CREATE_NO_WINDOW)
                while child.poll() is None:
                    if job.cancel and not cancel.exists():
                        cancel.touch()
                    try:
                        job.text = progress.read_text(encoding='utf-8') or job.text
                    except OSError:
                        pass
                    time.sleep(.15)
            if job.cancel:
                return None
            response = work / 'result.json'
            if not response.is_file():
                raise RuntimeError('3ds Max Batch exited before completing the export.')
            result = json.loads(response.read_text(encoding='utf-8'))
            if 'error' in result:
                raise RuntimeError(result['error'])
            if job.cancel:
                return None
            # Windows rename rejects an existing destination folder.
            package.rename(destination)
            return str(destination / Path(data['scene']).name)
        except Exception as error:
            for source, filename in ((Path(snapshot), 'selection-original-paths.max'),
                                     (work / 'batch.log', 'batch.log')):
                try:
                    shutil.copyfile(source, staged / filename)
                except OSError as copy_error:
                    job.say(f'Could not preserve {filename}: {copy_error}')
            raise RuntimeError(f'{error}\n\nIncomplete export files and diagnostics:\n{staged}') from error
        finally:
            if job.cancel or not package.exists():
                shutil.rmtree(staged, ignore_errors=True)



def build(request):
    """Runs solely inside the isolated Max process."""
    import pymxs
    request = Path(request)
    data = json.loads(request.read_text(encoding='utf-8'))
    rt = maxops.rt
    scene = Path(data['scene'])

    cancelled = request.parent / 'cancel'

    def report(message):
        if cancelled.exists():
            raise collection.Cancelled()
        (request.parent / 'progress.txt').write_text(message, encoding='utf-8')

    def dependencies():
        paths = {}
        for node in rt.objects:
            _, files = rt.ATSOps.GetDependencyFileList(
                node, pymxs.byref(rt.Array()), True, getResolvedFileNames=False)
            for path in files:
                if path:
                    paths[scan.norm_key(str(path))] = str(path)
        return paths

    try:
        report('Loading the selected objects...')
        if not rt.mergeMAXFile(data['snapshot'], rt.Name('useMergedMtlDups'), quiet=True):
            raise RuntimeError('Could not load the selected objects in the export session.')
        if Counter(str(node.name) for node in rt.objects) != Counter(data['nodes']):
            raise RuntimeError('Max included extra scene nodes or could not load the entire selection.')
        old_paths = dependencies()
        report(f'Collecting {len(old_paths)} selected-object asset(s)...')
        roots = data['roots']
        pairs = []
        for path, resolved in zip(old_paths.values(), maxops.resolved_paths(list(old_paths.values())) if old_paths else []):
            candidate = resolved if scan.is_abs(resolved) else None
            if not candidate and not scan.is_abs(path):
                candidate = next((str(Path(root) / path) for root in roots if (Path(root) / path).is_file()), None)
            pairs.append((path, candidate))
        if len(pairs) != len(old_paths):
            raise RuntimeError('Could not read all selected-object asset paths.')
        class CopyJob:
            @property
            def cancel(self):
                return cancelled.exists()

            @staticmethod
            def say(message):
                print(message, flush=True)

        targets, errors = collection.prepare(CopyJob(), pairs, str(scene.parent / 'maps'),
                                             roots, data['recursive'], data['exclude'])
        if cancelled.exists():
            return
        if errors or len(targets) != len(old_paths):
            details = '\n'.join(f'{path}: {error}' for path, error in list(errors.items())[:8])
            raise RuntimeError('Some selected-object assets could not be collected.\n' + details)
        report('Repointing the exported scene to its maps folder...')
        # Save first so Max resolves relative asset paths beside the new scene.
        if not rt.saveMaxFile(str(scene), quiet=True):
            raise RuntimeError('Could not save the selected objects.')
        if targets:
            relative = {scan.norm_key(path): str(Path('maps') / Path(target).name)
                        for path, target in targets.items()}
            for owner, prop, old in maxops.assigned_texture_slots():
                new = relative.get(scan.norm_key(old))
                if new:
                    maxops.set_map_path(owner, prop, new)
            remaining = dependencies().keys() & relative.keys()
            if remaining:
                maxops.ats_files()
                maxops.retarget([old_paths[k] for k in remaining], [relative[k] for k in remaining])
            expected = {scan.norm_key(path) for path in relative.values()}
            if set(dependencies()) != expected:
                raise RuntimeError('Max could not verify all asset links relative to the exported scene.')
        else:
            expected = set()
        if not rt.saveMaxFile(str(scene), quiet=True):
            raise RuntimeError('Could not save the relinked scene.')
        report('Verifying the saved export...')
        if not rt.loadMaxFile(str(scene), quiet=True):
            raise RuntimeError('Could not reopen the exported scene.')
        if (set(dependencies()) != expected
                or not all((scene.parent / path).is_file() for path in expected)
                or Counter(str(node.name) for node in rt.objects) != Counter(data['nodes'])):
            raise RuntimeError('The saved scene did not retain its selected objects and portable asset links.')
        (request.parent / 'result.json').write_text('{}', encoding='utf-8')
    except collection.Cancelled:
        return
    except Exception as error:
        (request.parent / 'result.json').write_text(json.dumps({'error': str(error)}), encoding='utf-8')
        raise
