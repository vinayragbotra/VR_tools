-- Network Sanity Check (Python / Qt version) launcher.
-- Keep this file next to the "nsc" folder. Run it once (Scripting > Run Script, or drag into the
-- viewport): it adds "Network Sanity Check (Py)" to the VR_tools category and opens the tool.
-- No separate Python install is needed: 3ds Max 2022+ ships Python and Qt.
-- Every click force-reloads the .py files (no Max restart needed when files change).

global NSC_PyDir = getFilenamePath (getThisScriptFilename())

-- Remember where the tool lives so the toolbar / menu button works in later sessions.
-- A read-only plugcfg (locked-down machines, render nodes) must not break the install:
-- the macro below falls back to the NSC_PyDir global in that case.
try
(
    setINISetting ((getDir #plugcfg) + "\\NetworkSanityCheck.ini") "Python" "dir" NSC_PyDir
)
catch (undefined)

macroScript NetworkSanityCheckPy category:"VR_tools" buttonText:"NSC (Py)" tooltip:"Network Sanity Check (Python)"
(
    local dir = ""
    try (dir = getINISetting ((getDir #plugcfg) + "\\NetworkSanityCheck.ini") "Python" "dir") catch (undefined)
    if dir == undefined do dir = ""
    if dir == "" do
    (
        if NSC_PyDir != undefined do dir = NSC_PyDir
    )
    dir = substituteString (trimRight dir "\\") "\\" "/"
    dir = substituteString dir "\"" "\\\""
    local code = "import sys, os\n" + \
        "d = os.path.normpath(\"" + dir + "\")\n" + \
        "if d not in sys.path: sys.path.insert(0, d)\n" + \
        "u = sys.modules.get('nsc.ui')\n" + \
        "w = getattr(getattr(u, 'NSCWindow', None), 'instance', None)\n" + \
        "if w is not None: w.close()\n" + \
        "for k in [k for k in list(sys.modules) if k == 'nsc' or k.startswith('nsc.')]: del sys.modules[k]\n" + \
        "import nsc\n" + \
        "nsc.show()"
    try (python.Execute code) catch
    (
        format "NSC (Py) failed to start: %\n" (getCurrentException())
        messageBox "Network Sanity Check failed to start - see the MAXScript Listener for the error." title:"NSC (Py)"
    )
)

-- Open the tool right away when the script is run by hand.
try (macros.run "VR_tools" "NetworkSanityCheckPy") catch (undefined)
