"""Configuration management using JSON (replaces INI parsing)."""
from __future__ import annotations

import json
import os
import tempfile
from pathlib import Path
from typing import Any

try:
    from pymxs import runtime as rt

    CONFIG_DIR = Path(str(rt.getDir(rt.Name("plugcfg"))))
except Exception:
    # Outside 3ds Max (plain `python -m nsc`): keep the config importable, use a temp dir
    rt = None  # type: ignore
    CONFIG_DIR = Path(tempfile.gettempdir()) / "nsc"
CONFIG_FILE = CONFIG_DIR / "NetworkSanityCheck.json"

_DEFAULTS = {
    "Assets": {
        "dirs": [],
        "dirsOff": [],
        "sceneDirOn": True,
        "recursive": True,
        "exclude": [],
    },
    "Archive": {
        "folder": "",
        "convert": False,
        "xrefs": True,
        "keep": False,
    },
}


class Config:
    def __init__(self) -> None:
        self._data: dict[str, Any] = {}
        self._load()

    def _load(self) -> None:
        if CONFIG_FILE.is_file():
            try:
                with open(CONFIG_FILE, "r", encoding="utf-8") as f:
                    self._data = json.load(f)
            except (json.JSONDecodeError, OSError):
                self._data = {}
        # Merge defaults
        for section, keys in _DEFAULTS.items():
            if section not in self._data:
                self._data[section] = {}
            for key, default in keys.items():
                self._data[section].setdefault(key, default)

    def save(self) -> None:
        # Atomic write: a crash / kill mid-write can never leave a corrupt JSON
        # (a corrupt file would silently reset every setting on next load).
        try:
            CONFIG_DIR.mkdir(parents=True, exist_ok=True)
            tmp = CONFIG_FILE.with_name(CONFIG_FILE.name + ".tmp")
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(self._data, f, indent=2)
            os.replace(tmp, CONFIG_FILE)
        except OSError:
            pass  # config write must never break the tool (e.g. read-only plugcfg)

    def get(self, section: str, key: str) -> Any:
        return self._data.get(section, {}).get(key)

    def set(self, section: str, key: str, value: Any) -> None:
        if section not in self._data:
            self._data[section] = {}
        self._data[section][key] = value
        self.save()

    def get_bool(self, section: str, key: str) -> bool:
        val = self.get(section, key)
        if isinstance(val, bool):
            return val
        if isinstance(val, str):
            return val.lower() == "true"
        return bool(val)

    def get_list(self, section: str, key: str) -> list[str]:
        val = self.get(section, key)
        if isinstance(val, list):
            return val
        if isinstance(val, str):
            return [x for x in val.split("|") if x]
        return []

    def set_list(self, section: str, key: str, value: list[str]) -> None:
        self.set(section, key, value)


config = Config()

# Backward-compatible INI-style access for MAXScript version compatibility
def ini_get(section: str, key: str) -> str:
    val = config.get(section, key)
    if isinstance(val, bool):
        return "true" if val else "false"
    if isinstance(val, list):
        return "|".join(val)
    return str(val)


def ini_set(section: str, key: str, value: str) -> None:
    # Try to parse as bool or list
    if value.lower() in ("true", "false"):
        config.set(section, key, value.lower() == "true")
    elif "|" in value:
        config.set_list(section, key, [x for x in value.split("|") if x])
    else:
        config.set(section, key, value)
