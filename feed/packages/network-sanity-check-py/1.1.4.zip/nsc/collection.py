"""Prepare collected files on a worker. Only publish complete, verified destinations."""
import hashlib
import os
import tempfile
from pathlib import Path
from .scan import is_excluded


class Cancelled(Exception):
    pass


def check(job):
    if job.cancel:
        raise Cancelled()


def prepare(job, paths, folder, roots, recursive, exclude):
    folder = Path(folder).absolute()
    folder.mkdir(parents=True, exist_ok=True)
    targets, errors, sources, missing = {}, {}, {}, {}
    hashes, copied = {}, {}

    def digest(path):
        if path not in hashes:
            h = hashlib.sha256()
            with path.open('rb') as stream:
                while True:
                    check(job)
                    block = stream.read(1024 * 1024)
                    if not block:
                        break
                    h.update(block)
            hashes[path] = h.digest()
        return hashes[path]

    def collect(src):
        if src in copied:
            return copied[src]
        if src.suffix.lower() == '.ifl' and src.parent != folder:
            from .ops import ifl_frames
            frames = ifl_frames(str(src))
            if not frames:
                raise ValueError('Image sequence list has no readable frames')
            lines = []
            for frame, _, hold in frames:
                frame = Path(frame)
                if frame.suffix.lower() == '.ifl':
                    raise ValueError('Nested image sequence requires review')
                lines.append((collect(frame).name + str(hold)).rstrip())
            payload = ('\n'.join(lines) + '\n').encode()
        else:
            payload = None
        n = 0
        while True:
            check(job)
            dest = folder / (src.name if not n else f'{src.stem}_{n}{src.suffix}')
            if src == dest or (dest.is_file() and digest(dest) == (hashlib.sha256(payload).digest() if payload is not None else digest(src))):
                break
            if not dest.exists():
                temp = None
                try:
                    with tempfile.NamedTemporaryFile(dir=folder, delete=False) as out:
                        temp = Path(out.name)
                        if payload is not None:
                            out.write(payload)
                        else:
                            with src.open('rb') as stream:
                                while True:
                                    check(job)
                                    block = stream.read(1024 * 1024)
                                    if not block:
                                        break
                                    out.write(block)
                    check(job)
                    os.rename(temp, dest)  # Windows refuses to replace an existing file.
                    break
                except FileExistsError:
                    continue
                finally:
                    if temp is not None:
                        temp.unlink(missing_ok=True)
            n += 1
        copied[src] = dest
        return dest

    try:
        for old, resolved in paths:
            check(job)
            p = Path(old)
            candidates = [p] if p.is_absolute() else [Path(r)/p for r in roots]
            hits = {v for v in candidates if v.is_file() and not is_excluded(str(v), exclude)}
            if len(hits) == 1 and (p.is_absolute() or p.parent != Path('.') or not recursive):
                sources[old] = hits.pop()
            else:
                if resolved and Path(resolved).is_absolute() and Path(resolved).is_file() and not is_excluded(resolved, exclude):
                    hits.add(Path(resolved))
                missing[old] = (p.name.lower(), hits)
        wanted = {name for name, _ in missing.values()}
        found = {name:set() for name in wanted}
        visited = set()
        if wanted:
            pending = list(roots)
            while pending:
                check(job)
                directory = Path(pending.pop())
                if directory in visited or is_excluded(str(directory), exclude):
                    continue
                visited.add(directory)
                job.text = 'Searching ' + str(directory)
                try:
                    with os.scandir(directory) as entries:
                        for e in entries:
                            check(job)
                            if is_excluded(e.path, exclude):
                                continue
                            if recursive and e.is_dir(follow_symlinks=False) and not os.path.islink(e.path) and not (e.stat(follow_symlinks=False).st_file_attributes & 1024):
                                pending.append(e.path)
                            elif e.name.lower() in wanted and e.is_file():
                                found[e.name.lower()].add(Path(e.path))
                except OSError as exc:
                    job.say(str(exc))
        for old,(name,hits) in missing.items():
            hits |= found[name]
            if not hits:
                errors[old] = 'Source missing'
            elif len(hits) > 1 and len({digest(p) for p in hits}) > 1:
                errors[old] = 'Different files match this name'
            else:
                sources[old] = sorted(hits)[0]
        for i,(old,src) in enumerate(sources.items(),1):
            check(job)
            job.text = f'Collecting {i}/{len(sources)} | {src.name}'
            job.frac = (i - 1)/max(1,len(sources))
            try:
                targets[old] = str(collect(src))
            except (OSError,ValueError) as exc:
                errors[old] = str(exc)
    except Cancelled:
        pass
    return targets, errors

