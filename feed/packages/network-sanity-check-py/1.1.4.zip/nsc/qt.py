"""Qt import shim: Max 2025+ ships PySide6, Max 2022-2024 ship PySide2."""
try:
    from PySide6 import QtCore, QtGui, QtWidgets  # noqa: F401
    from PySide6.QtGui import QAction  # noqa: F401
    QT6 = True
except ImportError:
    try:
        from PySide2 import QtCore, QtGui, QtWidgets  # noqa: F401
        from PySide2.QtWidgets import QAction  # noqa: F401
        QT6 = False
    except ImportError:
        raise RuntimeError(
            "Network Sanity Check needs PySide6 or PySide2, which ships with "
            "3ds Max 2022+. No Qt binding found in this Python."
        )

Qt = QtCore.Qt


def max_main_window():
    """The 3ds Max main window as a QWidget (parent for our tool window)."""
    try:
        import qtmax
        return qtmax.GetQMaxMainWindow()
    except Exception:
        return None
