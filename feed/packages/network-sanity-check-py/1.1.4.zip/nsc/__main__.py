"""Headless CLI for Network Sanity Check.

Usage:
    python -m nsc scan --export-json report.json
    python -m nsc scan --export-csv report.csv
    python -m nsc archive --output archive.zip
    python -m nsc --help
"""
from __future__ import annotations

import argparse
import csv
import json
import os
import shutil
import sys
import tempfile
from pathlib import Path

try:
    from pymxs import runtime as rt
except ImportError:
    rt = None  # type: ignore

from . import scan as scanmod
from . import maxops
from . import ops


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="nsc",
        description="Network Sanity Check - 3ds Max preflight tool for network rendering",
    )
    p.add_argument("--version", action="version", version="%(prog)s 3.1.0")

    sub = p.add_subparsers(dest="command", required=True)

    # scan command
    scan_p = sub.add_parser("scan", help="Scan current scene for linked files")
    scan_p.add_argument("--export-json", metavar="FILE", help="Export scan results to JSON")
    scan_p.add_argument("--export-csv", metavar="FILE", help="Export scan results to CSV")
    scan_p.add_argument("--only-missing", action="store_true", help="Only show missing files")
    scan_p.add_argument("--only-used", action="store_true", help="Only show files used by scene")

    # archive command
    arch_p = sub.add_parser("archive", help="Create archive of current scene")
    arch_p.add_argument("--output", metavar="FILE", required=True, help="Output zip path")
    arch_p.add_argument("--convert", action="store_true", help="Convert TX/TIF to PNG")
    arch_p.add_argument("--include-xrefs", action="store_true", help="Include XRef scenes")
    arch_p.add_argument("--keep-folder", action="store_true", help="Keep unzipped folder")

    # relink command
    relink_p = sub.add_parser("relink", help="Relink missing files by searching folders")
    relink_p.add_argument("--search-dirs", nargs="+", help="Additional search directories")
    relink_p.add_argument("--recursive", action="store_true", help="Search subdirectories")

    return p


def run_scan(args: argparse.Namespace) -> int:
    if rt is None:
        print("Error: pymxs not available (not running inside 3ds Max)", file=sys.stderr)
        return 1

    def progress(frac: float, text: str) -> None:
        print(f"[{frac*100:5.1f}%] {text}", file=sys.stderr)

    result = scanmod.scan(progress)

    # Filter
    items = result.items
    if args.only_used:
        items = [i for i in items if i.used]
    if args.only_missing:
        items = [i for i in items if i.status == "missing"]

    # Output
    if args.export_json:
        data = {
            "scene": result.scene,
            "scan_time": result.seconds,
            "total_files": len(result.items),
            "used_files": len(result.used),
            "missing_files": len(result.missing),
            "effects": result.effects,
            "items": [
                {
                    "path": it.path,
                    "resolved": it.resolved,
                    "ext": it.ext,
                    "kind": it.kind,
                    "size": it.size,
                    "status": it.status,
                    "relative": it.relative,
                    "used": it.used,
                    "refs": len(it.refs),
                }
                for it in items
            ],
        }
        with open(args.export_json, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2)
        print(f"Exported JSON to {args.export_json}")
    elif args.export_csv:
        with open(args.export_csv, "w", encoding="utf-8", newline="") as f:
            w = csv.writer(f)
            w.writerow(["Path", "Resolved", "Ext", "Kind", "Size", "Status", "Relative", "Used", "Refs"])
            for it in items:
                w.writerow([
                    it.path, it.resolved or "", it.ext, it.kind, it.size,
                    it.status, it.relative, it.used, len(it.refs)
                ])
        print(f"Exported CSV to {args.export_csv}")
    else:
        # Print summary to stdout
        print(f"Scene: {result.scene or '(unsaved)'}")
        print(f"Scan time: {result.seconds:.2f}s")
        print(f"Total files: {len(result.items)}")
        print(f"Used by scene: {len(result.used)}")
        print(f"Missing: {len(result.missing)}")
        print(f"Effects: {len(result.effects)}")
        if result.effects:
            for e in result.effects:
                print(f"  - {e}")
        if result.missing:
            print("\nMissing files:")
            for it in result.missing:
                print(f"  {it.path} ({it.kind})")

    return 0


def run_archive(args: argparse.Namespace) -> int:
    if rt is None:
        print("Error: pymxs not available (not running inside 3ds Max)", file=sys.stderr)
        return 1

    if not rt.maxFileName:
        print("Error: Scene not saved", file=sys.stderr)
        return 1

    def progress(frac: float, text: str) -> None:
        print(f"[{frac*100:5.1f}%] {text}", file=sys.stderr)

    result = scanmod.scan(progress)
    result.recheck()

    good = [i for i in result.items if i.used and i.resolved and (args.include_xrefs or i.kind != "XRefs")]
    missing = [i for i in result.items if i.used and not i.resolved and (args.include_xrefs or i.kind != "XRefs")]

    if not good:
        print("Error: No files to archive", file=sys.stderr)
        return 1

    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    work = output.with_suffix("")  # folder name without .zip
    maps_dir = work / "maps"
    scene_name = str(rt.maxFileName)

    print(f"Archiving {len(good)} file(s) to {output}")
    if missing:
        print(f"Warning: {len(missing)} missing file(s) will not be included", file=sys.stderr)

    conv = ops.converter()
    exts = scanmod.CONVERT_EXTS if args.convert else set()

    job = ops.Job()
    copied = ops.archive_copy(job, good, str(maps_dir), conv, exts)
    if copied is None:
        print("Archive cancelled", file=sys.stderr)
        return 1

    # Relink to archive copies and save scene copy
    pairs = []
    for it, target, need_max in copied:
        if need_max and not maxops.max_to_png(it.resolved, target):
            print(f"  PNG conversion failed, archiving original: {it.resolved}", file=sys.stderr)
            target = ops.unique_target(str(maps_dir), os.path.basename(it.resolved), it.resolved)
            ops.copy_asset(it.resolved, target)
        pairs.append((it, "maps\\" + os.path.basename(target)))

    # Save scene copy with relative paths
    with tempfile.TemporaryDirectory() as tmpdir:
        tmp_scene = os.path.join(tmpdir, scene_name)
        # Always restore exact properties and dirty state, even when saving fails.
        dirty = maxops.save_required()
        undo_log = []
        try:
            with maxops.no_undo():
                ops.relink(pairs, undo_log=undo_log)
                if not maxops.save_copy(tmp_scene):
                    print("Error: Could not save scene copy", file=sys.stderr)
                    return 1
        finally:
            with maxops.no_undo():
                ops.undo_relink(undo_log)
            maxops.set_save_required(dirty)

        # Build final zip
        shutil.move(tmp_scene, work / scene_name)
        ops.zip_folder(job, str(work), str(output), args.keep_folder)

    print(f"Archive created: {output} ({output.stat().st_size:,} bytes)")
    return 0


def run_relink(args: argparse.Namespace) -> int:
    if rt is None:
        print("Error: pymxs not available (not running inside 3ds Max)", file=sys.stderr)
        return 1

    def progress(frac: float, text: str) -> None:
        print(f"[{frac*100:5.1f}%] {text}", file=sys.stderr)

    result = scanmod.scan(progress)
    missing = [i for i in result.items if i.used and i.status == "missing"]

    if not missing:
        print("No missing files to relink")
        return 0

    search_dirs = args.search_dirs or []
    if rt.maxFilePath:
        search_dirs.insert(0, str(rt.maxFilePath))

    wanted = {i.name.lower() for i in missing}
    job = ops.Job()
    found = ops.index_folders(job, search_dirs, args.recursive, wanted)

    pairs = [(i, found[i.name.lower()]) for i in missing if i.name.lower() in found]
    if not pairs:
        print("No missing files found in search directories")
        return 1

    with maxops.undo("NSC CLI Relink"):
        n = ops.relink(pairs)

    print(f"Relinked {n} of {len(missing)} missing file(s)")
    return 0


def main() -> int:
    parser = build_parser()
    args = parser.parse_args()

    if args.command == "scan":
        return run_scan(args)
    elif args.command == "archive":
        return run_archive(args)
    elif args.command == "relink":
        return run_relink(args)
    else:
        parser.print_help()
        return 1


if __name__ == "__main__":
    sys.exit(main())
