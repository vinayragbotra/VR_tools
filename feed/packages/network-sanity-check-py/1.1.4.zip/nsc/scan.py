"""Scene scan: every linked file, with the texture maps that use it (for direct relinking).

Maps come from one MAXScript call; everything else (proxies, IES, XRefs ...) from Asset Tracking.
"""
from __future__ import annotations

import fnmatch
import os
import time
import threading
from dataclasses import dataclass, field
from typing import TYPE_CHECKING

from pymxs import runtime as rt

from . import maxops

if TYPE_CHECKING:
    from typing import Any

KINDS: tuple[tuple[str, set[str]], ...] = (
    ("HDRI", {".hdr", ".hdri"}),
    ("IES", {".ies", ".ldt"}),
    (
        "Proxies",
        {
            ".vrmesh",
            ".vrscene",
            ".cgeo",
            ".abc",
            ".rs",
            ".rsproxy",
            ".ass",
            ".usd",
            ".usda",
            ".usdc",
            ".usdz",
            ".vdb",
            ".prx",
            ".fxd",
            ".xmesh",
            ".fbx",
            ".obj",
            ".ptc",
            ".vrmap",
            ".vrlmap",
        },
    ),
    ("XRefs", {".max"}),
    (
        "Textures",
        {
            ".jpg",
            ".jpeg",
            ".png",
            ".tga",
            ".bmp",
            ".tif",
            ".tiff",
            ".tx",
            ".exr",
            ".psd",
            ".dds",
            ".gif",
            ".webp",
            ".rla",
            ".rpf",
            ".cin",
            ".dpx",
            ".ifl",
            ".mov",
            ".mp4",
            ".avi",
        },
    ),
)
CONVERT_EXTS: set[str] = {".tx", ".tif", ".tiff"}


def kind_of(ext: str, prop: str | None = None) -> str:
    """Determine asset kind from extension and property name."""
    if prop == "HDRIMapName":
        return "HDRI"
    for k, exts in KINDS:
        if ext in exts:
            return k
    return "Other"


def norm_key(p: str | None) -> str:
    """Normalize path for comparison (case-insensitive, resolved)."""
    return os.path.normcase(os.path.normpath(p)) if p else ""


def is_abs(p: str) -> bool:
    """Check if path is absolute (Windows drive or UNC)."""
    return (len(p) > 2 and p[1] == ":" and p[2] in "/\\") or p.startswith(("\\", "//"))


@dataclass(slots=True)
class Item:
    """One linked file.

    status: 'ok' (absolute, on disk) | 'found' (relative or moved, resolved elsewhere) | 'missing'
    refs:   [(map, prop)] texture maps holding this path; empty -> relink through Asset Tracking
    """
    path: str
    kind: str | None = None
    resolved: str | None = None
    size: int = 0
    status: str = "missing"
    refs: list[tuple[Any, str]] = field(default_factory=list)
    relative: bool = False
    used: bool = True
    ext: str = field(init=False, default="")

    def __post_init__(self) -> None:
        self.ext = os.path.splitext(self.path)[1].lower()
        if self.kind is None:
            self.kind = kind_of(self.ext)
        self.relative = not is_abs(self.path)

    @property
    def name(self) -> str:
        return os.path.basename(self.path)

    @property
    def folder(self) -> str:
        return os.path.dirname(self.path)

    @property
    def key(self) -> str:
        return norm_key(self.path)

    def in_folder(self, folder: str) -> bool:
        """True when the file in use lives directly in / under folder."""
        if not self.resolved or not folder:
            return False
        f = norm_key(folder).rstrip(os.sep) + os.sep
        return norm_key(self.resolved).startswith(f)

    def check(self, roots: list[str], exclude=None, index=None) -> None:
        """(Re)evaluate status from disk. Excluded paths are treated as not present.

        Simple logic:
          absolute path on disk            -> ok
          absolute but moved               -> found via roots / scene-tree index (by file name)
          relative path                    -> found via root+path, else scene-tree index
                                                (scene folder AND its subfolders)
          not found anywhere               -> missing

        index: (rel_map, base_map) from scene_tree_index() - rel_map keys are lower-case
        '/'-separated paths relative to the scene folder, base_map maps lower-case file
        name -> full path.
        """
        self.resolved, self.status, self.size = None, "missing", 0
        p = self.path
        self.ext = os.path.splitext(p)[1].lower()
        self.relative = not is_abs(p)
        base = os.path.basename(p).lower()
        if not self.relative:
            if os.path.isfile(p) and not is_excluded(p, exclude):
                self.resolved, self.status = p, "ok"
            else:
                for r in roots:
                    c = os.path.join(r, os.path.basename(p))
                    if os.path.isfile(c) and not is_excluded(c, exclude):
                        self.resolved, self.status = c, "found"
                        break
                if not self.resolved and index is not None:
                    hit = index[1].get(base)
                    if hit and not is_excluded(hit, exclude):
                        self.resolved, self.status = hit, "found"
        else:
            for r in roots:
                c = os.path.normpath(os.path.join(r, p))
                if os.path.isfile(c) and not is_excluded(c, exclude):
                    self.resolved, self.status = c, "found"
                    break
            if not self.resolved and index is not None:
                key = p.replace("\\", "/").lower().lstrip("./")
                hit = index[0].get(key) or index[1].get(base)
                if hit and not is_excluded(hit, exclude):
                    self.resolved, self.status = hit, "found"
        if self.resolved:
            try:
                self.size = os.path.getsize(self.resolved)
            except OSError:
                pass


def is_excluded(path: str, patterns) -> bool:
    """True if path matches any exclude pattern (glob, matched against the file name
    and against the full path, case-insensitive). E.g. '*.tmp', 'thumbs.db', '.svn'."""
    if not patterns:
        return False
    name = os.path.basename(path).lower()
    full = path.replace("\\", "/").lower()
    for pat in patterns:
        p = str(pat).strip().lower().replace("\\", "/")
        if not p:
            continue
        if fnmatch.fnmatch(name, p) or fnmatch.fnmatch(full, "*" + p + "*"):
            return True
    return False


def search_roots() -> list[str]:
    """Collect search roots: scene folder, project folder, map paths."""
    roots: list[str] = []
    if rt.maxFilePath:
        roots.append(str(rt.maxFilePath))
    try:
        proj = str(rt.pathConfig.getCurrentProjectFolder())
        roots += [proj, os.path.join(proj, "sceneassets", "images")]
    except (RuntimeError, AttributeError):
        pass
    try:
        for i in range(1, rt.mapPaths.count() + 1):
            roots.append(str(rt.mapPaths.get(i)))
    except (RuntimeError, AttributeError):
        pass
    return roots


def scene_tree_index(scene_dir, exclude=None, max_files: int = 100000):
    """One recursive walk of the scene folder (where the .max lives).
    Returns (rel_map, base_map): rel_map = {lower '/'-rel path: full path},
    base_map = {lower file name: full path} (first hit wins)."""
    rel_map: dict[str, str] = {}
    base_map: dict[str, str] = {}
    if not scene_dir or not os.path.isdir(scene_dir):
        return rel_map, base_map
    count = 0
    for dirpath, dirnames, filenames in os.walk(scene_dir):
        dirnames[:] = [d for d in dirnames if not is_excluded(os.path.join(dirpath, d), exclude)]
        for fn in filenames:
            full = os.path.join(dirpath, fn)
            if is_excluded(full, exclude):
                continue
            count += 1
            if count > max_files:
                return rel_map, base_map
            rel = os.path.relpath(full, scene_dir).replace("\\", "/").lower()
            rel_map.setdefault(rel, full)
            base_map.setdefault(fn.lower(), full)
    return rel_map, base_map


def user_search_roots() -> list[str]:
    """Ticked SEARCH FOLDERS from the config (Assets page) - also searched at scan time,
    so a file KStudio-style tools resolve from a search directory is 'found', not 'missing'.
    Deep (recursive) search stays in the Missing-tab action; this is a flat per-root check."""
    try:
        from .config import config
        dirs = config.get_list("Assets", "dirs")
        off = set(config.get_list("Assets", "dirsOff"))
        return [d for d in dirs if d and d not in off]
    except Exception:
        return []


def all_roots() -> list[str]:
    """search_roots() + ticked user search folders, de-duplicated, order preserved."""
    out: list[str] = []
    for r in search_roots() + user_search_roots():
        r = os.path.normpath(r)
        if r not in out:
            out.append(r)
    return out


def report_dict(result: "ScanResult", items=None) -> dict:
    """JSON-serializable scan report (used by the CLI and the UI export button)."""
    items = result.items if items is None else items
    return {
        "scene": result.scene,
        "scan_time": result.seconds,
        "mode": result.mode,
        "stage_times": result.timings,
        "created": result.created,
        "total_files": len(result.items),
        "used_files": len(result.used),
        "missing_files": len(result.missing),
        "effects": result.effects,
        "items": [
            {
                "path": it.path,
                "resolved": it.resolved,
                "ext": it.ext,
                "kind": it.kind,
                "size": it.size,
                "status": it.status,
                "relative": it.relative,
                "used": it.used,
                "refs": len(it.refs),
            }
            for it in items
        ],
    }


def write_csv(path: str, result: "ScanResult", items=None) -> None:
    """Write the scan report as CSV."""
    import csv

    items = result.items if items is None else items
    with open(path, "w", encoding="utf-8", newline="") as f:
        w = csv.writer(f)
        w.writerow(["Path", "Resolved", "Ext", "Kind", "Size", "Status", "Relative", "Used", "Refs"])
        for it in items:
            w.writerow([
                it.path, it.resolved or "", it.ext, it.kind, it.size,
                it.status, it.relative, it.used, len(it.refs),
            ])


@dataclass
class ScanResult:
    items: list[Item] = field(default_factory=list)
    effects: list[str] = field(default_factory=list)
    scene: str = ""
    seconds: float = 0.0
    created: float = 0.0
    timings: dict[str, float] = field(default_factory=dict)
    mode: str = "full"

    @property
    def missing(self) -> list[Item]:
        return [i for i in self.items if i.used and i.status == "missing"]

    @property
    def used(self) -> list[Item]:
        return [i for i in self.items if i.used]

    def recheck(self, exclude=None) -> None:
        roots = all_roots()
        check_files(self.items, roots, exclude)


class ScanCancelled(Exception):
    """A scan was cancelled; discard its incomplete result."""


def check_cancel(cancelled):
    if cancelled is not None and cancelled():
        raise ScanCancelled()


def check_files(items, roots, exclude=None, progress=None, cancelled=None):
    """Check plain path snapshots in a worker; only commit results on completion.

    A cancelled SMB request may finish later, but never holds Max wrappers,
    updates the UI, or mutates current/previous scan results.
    """
    check_cancel(cancelled)
    paths = [item.path for item in items]
    done, stop = threading.Event(), threading.Event()
    state = {'count': 0, 'error': None, 'path': ''}
    results = []
    def work():
        try:
            for index, path in enumerate(paths):
                if stop.is_set():
                    break
                state['path'] = path
                item = Item(path)
                item.check(roots, exclude)
                results.append((item.resolved, item.status, item.size, item.relative, item.ext))
                state['count'] = index + 1
        except Exception as error:
            state['error'] = error
        finally:
            done.set()
    threading.Thread(target=work, daemon=True).start()
    try:
        while not done.wait(0.05):
            check_cancel(cancelled)
            if progress:
                progress(0.5 + 0.45 * state['count'] / max(1, len(paths)),
                         'Checking files: %d/%d | %s' % (state['count'], len(paths), state['path']))
        check_cancel(cancelled)
        if state['error'] is not None:
            raise state['error']
        for item, values in zip(items, results):
            item.resolved, item.status, item.size, item.relative, item.ext = values
        if progress:
            progress(0.95, 'Checked %d input files' % len(items))
    finally:
        stop.set()


def scan(progress: Any | None = None, exclude=None, cancelled=None, quick=False) -> ScanResult:
    """Scan the current scene for all linked files. exclude: glob patterns to ignore."""
    t0 = time.time()
    r = ScanResult()
    r.scene = maxops.scene_file()
    r.mode = "quick" if quick else "full"
    if progress:
        progress(0.05, "Quick audit: Asset Tracker dependencies" if quick else "Reading texture maps")
    by_key: dict[str, Item] = {}
    print("[NSC] Scan stage: reading map references", flush=True)
    stage = time.perf_counter()
    check_cancel(cancelled)
    maps = [] if quick else maxops.scan_maps(progress, cancelled)
    r.timings["Map references"] = time.perf_counter() - stage
    print("[NSC] Map references: %.2fs" % r.timings["Map references"], flush=True)
    for owner, prop, path, used in maps:
        k = norm_key(path)
        it = by_key.get(k)
        if it is None:
            it = by_key[k] = Item(path, kind_of(os.path.splitext(path)[1].lower(), str(prop)))
            it.used = False
            r.items.append(it)
        it.refs.append((owner, prop))
        it.used = it.used or used
    if progress:
        progress(0.4, "Reading input dependencies (native Max call; Cancel applies when it returns)")
    check_cancel(cancelled)
    me = norm_key(r.scene)
    print("[NSC] Scan stage: Asset Tracking", flush=True)
    stage = time.perf_counter()
    files = maxops.ats_files()
    r.timings["Input dependencies"] = time.perf_counter() - stage
    print("[NSC] Asset Tracking: %.2fs" % r.timings["Input dependencies"], flush=True)
    for f in files:
        k = norm_key(f)
        if k != me and k not in by_key:
            it = by_key[k] = Item(f)
            r.items.append(it)
    check_cancel(cancelled)
    roots = all_roots()
    stage = time.perf_counter()
    print("[NSC] Scan stage: checking %d unique files (no recursive search)" % len(r.items), flush=True)
    check_files(r.items, roots, exclude, progress, cancelled)
    r.timings["Disk checks"] = time.perf_counter() - stage
    print("[NSC] Disk checks: %.2fs" % r.timings["Disk checks"], flush=True)
    check_cancel(cancelled)
    if progress:
        progress(0.98, "Reading render effects")
    check_cancel(cancelled)
    r.effects = maxops.effects()
    r.seconds = time.time() - t0
    r.created = time.time()
    return r
