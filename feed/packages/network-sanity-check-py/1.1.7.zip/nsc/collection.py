"""Prepare collected files on a worker. Only publish complete, verified destinations."""
import hashlib
import os
import tempfile
import time
from collections import Counter
from pathlib import Path
from .scan import is_excluded


# Session-local fingerprints for files verified or copied by this preview.
_fingerprints = {}


def signature(path):
    info = path.stat()
    return (info.st_dev, info.st_ino, info.st_size, info.st_mtime_ns, info.st_ctime_ns)


def remember(path, stamp, value):
    if stamp[1]:
        if len(_fingerprints) >= 16384:
            _fingerprints.clear()
        _fingerprints[path] = (stamp, value)


class Cancelled(Exception):
    pass


def check(job):
    if job.cancel:
        raise Cancelled()


def inventory(folder, exclude=None, cancelled=None):
    files = {}
    with os.scandir(folder) as entries:
        for entry in entries:
            if cancelled and cancelled():
                raise Cancelled()
            if entry.is_file() and not is_excluded(entry.path, exclude):
                files[entry.name.casefold()] = (entry.path, entry.stat().st_size)
    return files


def name_counts(paths):
    return Counter(path.name.casefold() for path in {Path(value) for value in paths})


def preferred(path, files, counts):
    name = Path(path).name.casefold()
    hit = files.get(name)
    if hit and (Path(hit[0]) == Path(path) or counts[name] == 1):
        return hit
    return None


def search_names(wanted, roots, recursive, exclude, checkpoint, progress, report):
    found = {name:set() for name in wanted}
    visited = set()
    if wanted:
        pending = list(roots)
        while pending:
            checkpoint()
            directory = Path(pending.pop())
            if directory in visited or is_excluded(str(directory), exclude):
                continue
            visited.add(directory)
            progress('Searching ' + str(directory))
            try:
                with os.scandir(directory) as entries:
                    for e in entries:
                        checkpoint()
                        if is_excluded(e.path, exclude):
                            continue
                        if recursive and e.is_dir(follow_symlinks=False) and not (e.stat(follow_symlinks=False).st_file_attributes & 1024):
                            pending.append(e.path)
                        elif e.name.lower() in wanted and e.is_file():
                            found[e.name.lower()].add(Path(e.path))
            except OSError as exc:
                report(str(exc))
    return found

def best_match(old, hits):
    if len(hits) == 1:
        return next(iter(hits))
    # A moved hierarchy retains its trailing directory names. Require at least
    # two matching directories to disambiguate common names such as "maps".
    scores = {}
    for hit in hits:
        depth = 0
        for left, right in zip(reversed(Path(old).parent.parts), reversed(hit.parent.parts)):
            if left.casefold() != right.casefold():
                break
            depth += 1
        scores[hit] = depth
    best = max(scores.values(), default=0)
    winners = [hit for hit, score in scores.items() if score == best]
    if best >= 2 and len(winners) == 1:
        return winners[0]
    return None


def prepare(job, paths, folder, roots, recursive, exclude, scene_paths=None):
    folder = Path(folder).absolute()
    folder.mkdir(parents=True, exist_ok=True)
    targets, errors, sources, missing = {}, {}, {}, {}
    copied = {}
    claims = {}
    stats = job.collection_stats = dict(files=0, listing=0., search=0., copying=0.)
    counts = name_counts(scene_paths if scene_paths is not None else (old for old, _ in paths))
    start = time.perf_counter()

    def digest(path):
        stamp = signature(path)
        previous = _fingerprints.get(path)
        if previous and previous[0] == stamp:
            return previous[1]
        job.text = 'Comparing existing file | ' + path.name
        h = hashlib.sha256()
        with path.open('rb') as stream:
            while True:
                check(job)
                block = stream.read(1024 * 1024)
                if not block:
                    break
                h.update(block)
        if signature(path) != stamp:
            raise OSError(f'File changed during comparison: {path}')
        value = h.digest()
        remember(path, stamp, value)
        return value

    def collect(src):
        if src in copied:
            return copied[src]
        if src.suffix.lower() == '.ifl':
            from .ops import ifl_frames
            frames = ifl_frames(str(src))
            if not frames:
                raise ValueError('Image sequence list has no readable frames')
            if src.parent == folder and all(Path(f).parent == folder and Path(f).is_file()
                                            and Path(f).suffix.lower() != '.ifl' for f, _, _ in frames):
                return src
            lines = []
            frame_sources = {}
            unresolved = set()
            for frame, _, _ in frames:
                f = Path(frame)
                if f.suffix.lower() == '.ifl':
                    raise ValueError('Nested image sequence requires review')
                if is_excluded(str(f), exclude):
                    raise ValueError(f'Excluded sequence frame: {f}')
                if f.is_file():
                    frame_sources[f] = f
                elif f.name.casefold() in index and counts[f.name.casefold()] <= 1:
                    frame_sources[f] = Path(index[f.name.casefold()][0])
                else:
                    unresolved.add(f.name.lower())
            matches = search(unresolved) if unresolved else {}
            for frame, _, hold in frames:
                frame = Path(frame)
                if frame not in frame_sources:
                    choices = matches.get(frame.name.lower(), set())
                    if len(choices) != 1:
                        raise ValueError(f'Missing or ambiguous sequence frame: {frame}')
                    frame_sources[frame] = next(iter(choices))
                frame = frame_sources[frame]
                lines.append((collect(frame).name + str(hold)).rstrip())
            payload = ('\n'.join(lines) + '\n').encode()
        else:
            payload = None
        n = 0
        while True:
            check(job)
            dest = folder / (src.name if not n else f'{src.stem}_{n}{src.suffix}')
            if (dest in claims and claims[dest] != src) or (n and dest.name.casefold() in counts):
                n += 1
                continue
            if (src == dest and payload is None) or (dest.is_file() and dest.stat().st_size == (len(payload) if payload is not None else src.stat().st_size) and digest(dest) == (hashlib.sha256(payload).digest() if payload is not None else digest(src))):
                break
            if not dest.exists():
                temp = None
                try:
                    with tempfile.NamedTemporaryFile(dir=folder, delete=False) as out:
                        temp = Path(out.name)
                        if payload is not None:
                            out.write(payload)
                        else:
                            stamp = signature(src)
                            with src.open('rb') as stream:
                                while True:
                                    check(job)
                                    block = stream.read(1024 * 1024)
                                    if not block:
                                        break
                                    out.write(block)
                            if signature(src) != stamp:
                                raise OSError(f'Source changed while copying: {src}')
                    check(job)
                    os.rename(temp, dest)  # Windows refuses to replace an existing file.
                    stats["files"] += 1
                    break
                except FileExistsError:
                    continue
                finally:
                    if temp is not None:
                        temp.unlink(missing_ok=True)
            n += 1
        claims[dest] = src
        copied[src] = dest
        return dest

    def search(wanted):
        return search_names(wanted, roots, recursive, exclude, lambda: check(job),
                            lambda text: setattr(job, 'text', text), job.say)

    try:
        index = inventory(folder, exclude, lambda: job.cancel)
        stats['listing'] = time.perf_counter() - start
        start = time.perf_counter()
        for old, resolved in paths:
            check(job)
            p = Path(old)
            hit = preferred(old, index, counts)
            if hit:
                if p.suffix.lower() == '.ifl':
                    sources[old] = Path(hit[0])
                else:
                    targets[old] = hit[0]
                    claims[Path(hit[0])] = Path(hit[0])
                continue
            if p.is_absolute() and not is_excluded(old, exclude) and p.is_file():
                sources[old] = p
            elif resolved and counts[p.name.casefold()] == 1 and not is_excluded(resolved, exclude) and Path(resolved).is_file():
                sources[old] = Path(resolved)
            else:
                hits = set()
                if not p.is_absolute() and p.parent != Path('.'):
                    hits = {Path(r)/p for r in roots if not is_excluded(str(Path(r)/p), exclude) and (Path(r)/p).is_file()}
                missing[old] = (p.name.lower(), hits)
        wanted = {name for name, _ in missing.values()}
        found = search(wanted)
        for old,(name,hits) in missing.items():
            hits |= found[name]
            if not hits:
                errors[old] = 'Source missing'
            elif best_match(old, hits) is None or (counts[Path(old).name.casefold()] > 1 and len(hits) == 1):
                errors[old] = 'Different files match this name'
            else:
                sources[old] = best_match(old, hits)
        stats['search'] = time.perf_counter() - start
        start = time.perf_counter()
        for i,(old,src) in enumerate(sources.items(),1):
            check(job)
            job.text = f'Collecting {i}/{len(sources)} | {src.name}'
            job.frac = (i - 1)/max(1,len(sources))
            try:
                targets[old] = str(collect(src))
            except (OSError,ValueError) as exc:
                errors[old] = str(exc)
        stats['copying'] = time.perf_counter() - start
    except Cancelled:
        pass
    return targets, errors

