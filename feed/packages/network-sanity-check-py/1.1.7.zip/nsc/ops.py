"""Operations: relink (main thread) and file work (safe to run in a background thread)."""
from __future__ import annotations

import os
import shutil
import subprocess
import threading
import zipfile
from dataclasses import dataclass, field
from typing import TYPE_CHECKING

from . import maxops
from .scan import Item, search_roots, all_roots, scene_tree_index, norm_key, is_excluded

if TYPE_CHECKING:
    from typing import Any, Callable

# ------------------------------------------------------------------------------------------
# Relink (main thread): maps directly, everything else through Asset Tracking
# ------------------------------------------------------------------------------------------


def relink(
    pairs: list[tuple[Item, str]],
    log: Callable[[str], None] | None = None,
    undo_log: list[tuple] | None = None,
) -> int:
    """pairs: [(Item, newPath)]. Updates the items in place. Returns the number relinked.
    undo_log: optional list collecting what is needed to put the scene back exactly."""
    n = 0
    ats_items: list[Item] = []
    ats_old: list[str] = []
    ats_new: list[str] = []
    for it, new in pairs:
        if it.refs:
            ok = False
            for owner, prop in it.refs:
                old = maxops.get_map_path(owner, prop)
                if maxops.set_map_path(owner, prop, new):
                    ok = True
                    if undo_log is not None:
                        undo_log.append(("map", owner, prop, old))
            if ok:
                n += 1
                it.path = new
            elif log:
                log(f"  Could not relink: {it.path}")
        else:
            ats_items.append(it)
            ats_old.append(it.path)
            ats_new.append(new)
    for it, old, new, done in zip(ats_items, ats_old, ats_new, maxops.retarget(ats_old, ats_new)):
        if done:
            n += 1
            it.path = new
            if undo_log is not None:
                undo_log.append(("ats", new, old))
        elif log:
            log(f"  Could not relink: {old}")
    roots = all_roots()
    idx = None
    for it, _ in pairs:
        it.check(roots, None)
        if not it.resolved and maxops.rt.maxFilePath:
            if idx is None:
                idx = scene_tree_index(str(maxops.rt.maxFilePath))
            it.check(roots, None, idx)
    return n


def relink_converted(pairs, log):
    """Change only matching map properties and restore a texture's links on failure."""
    count = 0
    for it, target in pairs:
        expected = norm_key(it.path)
        refs = [(owner, prop, maxops.get_map_path(owner, prop)) for owner, prop in it.refs]
        if not refs or not os.path.isfile(target) or any(norm_key(old) != expected for _, _, old in refs):
            log(f'Conversion link skipped. Stale references or missing PNG: {it.path}')
            continue
        updated = []
        for owner, prop, old in refs:
            updated.append((owner, prop, old))
            if not maxops.set_map_path(owner, prop, target) or norm_key(maxops.get_map_path(owner, prop)) != norm_key(target):
                break
        else:
            it.path = target
            it.check([], None)
            count += 1
            continue
        for owner, prop, old in reversed(updated):
            if not maxops.set_map_path(owner, prop, old) or norm_key(maxops.get_map_path(owner, prop)) != norm_key(old):
                log(f'Could not restore {old}. Use Undo and check the scene links.')
        log(f'Could not relink converted texture: {it.path}')
    return count


def undo_relink(undo_log: list[tuple]) -> None:
    """Restore paths from undo_log (produced by relink)."""
    olds: list[str] = []
    news: list[str] = []
    for e in reversed(undo_log):
        if e[0] == "map":
            maxops.set_map_path(e[1], e[2], e[3])
        else:
            olds.append(e[1])
            news.append(e[2])
    maxops.retarget(olds, news)


# ------------------------------------------------------------------------------------------
# File work (no Max calls: runs in a background thread)
# ------------------------------------------------------------------------------------------


@dataclass
class Job:
    """Progress + cancel flag shared between the worker thread and the UI."""
    frac: float = 0.0
    text: str = ""
    cancel: bool = False
    done: bool = False
    result: Any = None
    error: Exception | None = None
    messages: list[str] = field(default_factory=list)

    def say(self, msg: str) -> None:
        self.messages.append(msg)


def run_thread(job: Job, fn: Callable[..., Any], *args: Any) -> threading.Thread:
    """Run fn(job, *args) in a daemon thread; job.result / job.error / job.done are set."""

    def body() -> None:
        try:
            job.result = fn(job, *args)
        except Exception as e:  # reported by the UI
            job.error = e
        job.done = True

    t = threading.Thread(target=body)
    t.daemon = True
    t.start()
    return t


def index_folders(
    job: Job, dirs: list[str], recursive: bool, wanted: set[str], exclude=None
) -> dict[str, str]:
    """Find files by name. wanted: set of lower-case file names. Returns {name: fullpath}.
    Paths matching the exclude globs are skipped (not descended into, not returned)."""
    found: dict[str, str] = {}
    ex = list(exclude) if exclude else []
    stack = [d for d in dirs if os.path.isdir(d) and not is_excluded(d, ex)]
    visited = 0
    while stack and len(found) < len(wanted) and not job.cancel:
        d = stack.pop()
        visited += 1
        if visited % 20 == 0:
            job.text = f"Searching  {d}"
            job.frac = min(0.95, job.frac + 0.002)
        try:
            with os.scandir(d) as entries:
                for e in entries:
                    try:
                        if e.is_dir(follow_symlinks=False):
                            if recursive and not is_excluded(e.path, ex):
                                stack.append(e.path)
                        else:
                            n = e.name.lower()
                            if n in wanted and n not in found and not is_excluded(e.path, ex):
                                found[n] = e.path
                    except OSError:
                        pass
        except OSError:
            pass
    return found


def ifl_frames(path: str) -> list[tuple[str, str, str]]:
    """Parse .ifl (image sequence list) file. Returns [(fullpath, name, hold_str)]."""
    base = os.path.dirname(path)
    out: list[tuple[str, str, str]] = []
    try:
        with open(path, "r") as fh:
            for ln in fh:
                ln = ln.strip()
                if not ln or ln.startswith(";"):
                    continue
                name, hold = ln, ""
                parts = ln.rsplit(" ", 1)
                if len(parts) == 2 and parts[1].isdigit() and not os.path.isfile(os.path.join(base, ln)):
                    name, hold = parts[0].strip(), " " + parts[1]
                out.append(
                    (name if os.path.isabs(name) else os.path.join(base, name), os.path.basename(name), hold)
                )
    except (IOError, OSError):
        pass
    return out


def copy_asset(src: str, dest: str, say: Callable[[str], None] | None = None) -> bool:
    """Copy one file; an .ifl also copies its frames and is rewritten to list them by name."""
    if os.path.splitext(src)[1].lower() != ".ifl":
        if not os.path.isfile(dest):
            shutil.copyfile(src, dest)
        return True
    frames = ifl_frames(src)
    folder = os.path.dirname(dest)
    lost = 0
    lines: list[str] = []
    for full, name, hold in frames:
        target = os.path.join(folder, name)
        if os.path.isfile(full):
            if norm_key(full) != norm_key(target) and not os.path.isfile(target):
                shutil.copyfile(full, target)
        else:
            lost += 1
        lines.append(name + hold)
    with open(dest, "w") as fh:
        fh.write("\n".join(lines) + "\n")
    if say:
        say(
            f"  Image sequence {os.path.basename(src)}: {len(frames) - lost} frame(s)"
            + (f", {lost} not found" if lost else "")
        )
    return True


def unique_target(folder: str, name: str, src: str) -> str:
    """folder/name, or name_1.ext ... when a different file of that name is already there."""
    target = os.path.join(folder, name)
    base, ext = os.path.splitext(name)
    n = 1
    while os.path.isfile(target):
        try:
            if os.path.getsize(target) == os.path.getsize(src):
                return target
        except OSError:
            pass
        target = os.path.join(folder, f"{base}_{n}{ext}")
        n += 1
    return target


def copy_items(
    job: Job, items: list[Item], base: str, by_kind: bool
) -> list[tuple[Item, str]]:
    """Copy every resolved item under base (optionally base/<Kind>). Returns [(item, target)]."""
    pairs: list[tuple[Item, str]] = []
    todo = [it for it in items if it.resolved]
    for i, it in enumerate(todo):
        if job.cancel:
            job.say("  Cancelled")
            break
        job.frac = float(i) / max(1, len(todo))
        job.text = f"Copying {it.name}"
        folder = os.path.join(base, it.kind) if by_kind else base
        try:
            os.makedirs(folder, exist_ok=True)
            target = unique_target(folder, os.path.basename(it.resolved), it.resolved)
            if norm_key(target) != norm_key(it.resolved):
                copy_asset(it.resolved, target, job.say)
            pairs.append((it, target))
        except (IOError, OSError) as e:
            job.say(f"  Copy failed: {it.resolved}  ({e})")
    return pairs


# ------------------------------------------------------------------------------------------
# TX / TIF -> PNG
# ------------------------------------------------------------------------------------------

_CONV: tuple[str, str | None] | None = None


def converter() -> tuple[str, str | None]:
    """('magick', exe) | ('oiio', exe) | ('max', None)"""
    global _CONV
    if _CONV is None:
        from pymxs import runtime as rt

        root = str(rt.getDir(rt.Name("maxRoot")))
        extra = [
            os.path.join(root, "Plugins", "MAXtoA"),
            os.path.join(root, "Plugins", "MAXtoA", "bin"),
        ]
        pf = os.environ.get("ProgramFiles", r"C:\Program Files")
        try:
            extra += [
                os.path.join(pf, d)
                for d in os.listdir(pf)
                if d.lower().startswith("imagemagick")
            ]
        except OSError:
            pass
        path = os.environ.get("PATH", "") + os.pathsep + os.pathsep.join(extra)
        m = shutil.which("magick.exe", path=path)
        o = None if m else shutil.which("oiiotool.exe", path=path)
        _CONV = ("magick", m) if m else ("oiio", o) if o else ("max", None)
    return _CONV


def convert_file(src: str, dest: str, conv: tuple[str, str | None]) -> bool:
    """External converters only (thread safe). Returns True when dest exists."""
    flags = 0x08000000  # CREATE_NO_WINDOW
    if conv[0] == "magick":
        spec = ("TIFF:" if src.lower().endswith(".tx") else "") + src + "[0]"
        subprocess.call(
            [conv[1], spec, "-define", "png:compression-level=0", dest],
            creationflags=flags,
        )
    elif conv[0] == "oiio":
        subprocess.call(
            [
                conv[1],
                src,
                "--subimage",
                "0",
                "--attrib",
                "png:compressionLevel",
                "0",
                "-o",
                dest,
            ],
            creationflags=flags,
        )
    return os.path.isfile(dest)


# ------------------------------------------------------------------------------------------
# Archive (file work only; the scene part runs on the main thread in the UI)
# ------------------------------------------------------------------------------------------


def archive_copy(
    job: Job, items: list[Item], maps_dir: str, conv: tuple[str, str | None], convert_exts: set[str]
) -> list[tuple[Item, str, bool]] | None:
    """Copy items into maps_dir (flat). TX/TIF in convert_exts become PNG inside the archive only.
    Returns [(item, target, needs_max_convert)]. Source files are only read, never changed."""
    out: list[tuple[Item, str, bool]] = []
    os.makedirs(maps_dir, exist_ok=True)
    for i, it in enumerate(items):
        if job.cancel:
            job.say("  Cancelled")
            return None
        job.frac = 0.7 * i / max(1, len(items))
        job.text = f"Archive: copying {it.name}  ({i + 1} / {len(items)})"
        src = it.resolved
        try:
            if os.path.splitext(src)[1].lower() in convert_exts:
                base = os.path.splitext(os.path.basename(src))[0] + ".png"
                target = os.path.join(maps_dir, base)
                n = 1
                while os.path.isfile(target):
                    target = os.path.join(maps_dir, f"{os.path.splitext(base)[0]}_{n}.png")
                    n += 1
                if conv[0] != "max" and convert_file(src, target, conv):
                    out.append((it, target, False))
                elif conv[0] == "max":
                    out.append((it, target, True))
                else:
                    job.say(f"  PNG conversion failed, archived the original: {src}")
                    t = unique_target(maps_dir, os.path.basename(src), src)
                    copy_asset(src, t, job.say)
                    out.append((it, t, False))
            else:
                t = unique_target(maps_dir, os.path.basename(src), src)
                copy_asset(src, t, job.say)
                out.append((it, t, False))
        except (IOError, OSError) as e:
            job.say(f"  Copy failed: {src}  ({e})")
    return out


def zip_folder(job: Job, folder: str, zip_path: str, keep: bool) -> str | None:
    """Zip folder (its name becomes the top folder inside the zip). Removes folder after a good zip
    unless keep. Writes to a .part file first so a cancelled / failed zip never replaces a good one."""
    files: list[str] = []
    for d, _, names in os.walk(folder):
        for n in names:
            files.append(os.path.join(d, n))
    total = max(1, sum(os.path.getsize(f) for f in files))
    done = 0
    part = zip_path + ".part"
    top = os.path.dirname(folder)
    with zipfile.ZipFile(part, "w", zipfile.ZIP_DEFLATED, allowZip64=True) as z:
        for f in files:
            if job.cancel:
                break
            job.text = f"Zipping {os.path.basename(f)}"
            z.write(f, os.path.relpath(f, top))
            done += os.path.getsize(f)
            job.frac = 0.7 + 0.3 * done / total
    if job.cancel:
        os.remove(part)
        job.say("  Zip cancelled")
        return None
    with zipfile.ZipFile(part) as z:
        bad = z.testzip()
    if bad:
        raise IOError(f"zip check failed at {bad}")
    if os.path.isfile(zip_path):
        os.remove(zip_path)
    os.rename(part, zip_path)
    if not keep:
        shutil.rmtree(folder, ignore_errors=True)
    return zip_path
