-- Network Sanity Check - MAXScript Helpers
-- Loaded once by maxops.py via rt.execute()
-- Keep this file next to the nsc/ folder

global NSC_AssignedTextureSlots, NSC_ScanMaps, NSC_Retarget, NSC_SaveCopy, NSC_MaxToPng

fn NSC_ScanMaps classes:undefined wanted:undefined =
(
    -- used = the map is on a scene object, or under the environment / renderer / effects / atmospherics.
    -- Maps that only sit in Material Editor slots (or nowhere) are unused.
    local owners = #()
    local props  = #()
    local paths  = #()
    local used   = #()

    local roots = #(renderers.current)
    if environmentMap != undefined do append roots environmentMap
    for i = 1 to numEffects do append roots (getEffect i)
    for i = 1 to numAtmospherics do append roots (getAtmospheric i)

    if classes == undefined do classes = textureMap.classes
    -- Search renderer/effect roots only for file-bearing classes actually present.
    for c in classes do
    (
        local maps = try (getClassInstances c) catch (#())
        local candidates = #()
        for m in maps where (isProperty m #filename or isProperty m #HDRIMapName) do append candidates m
        if candidates.count > 0 do
        (
            local extra = #()
            if wanted == undefined do for r in roots do join extra (try (getClassInstances c target:r) catch (#()))
            if environmentMap != undefined do append extra environmentMap
            for m in candidates do
            (
                local u = if wanted != undefined then true else (try ((refs.dependentNodes m firstOnly:true) != undefined) catch (true)) or ((findItem extra m) > 0)
                for p in #(#filename, #HDRIMapName) where isProperty m p do
                (
                    local v = try (getProperty m p) catch (undefined)
                    if classOf v == String and v != "" and (wanted == undefined or (findItem wanted (toLower (substituteString v "/" "\\"))) > 0) do
                    (
                        append owners m
                        append props p
                        append paths v
                        append used u
                    )
                )
            )
        )
    )

    #(owners, props, paths, used)
)

fn NSC_AssignedTextureSlots =
(
    local pending = for m in sceneMaterials where m != undefined collect m
    -- File maps can also be assigned directly to modifiers, outside sceneMaterials.
    for cls in #(Bitmaptexture, CoronaBitmap, VRayBitmap, VRayHDRI) where cls != undefined do
        join pending (try (getClassInstances cls) catch (#()))

    local seen = #()
    local owners = #()
    local props = #()
    local paths = #()
    while pending.count > 0 do
    (
        local owner = pending[pending.count]
        deleteItem pending pending.count
        if owner != undefined and (findItem seen owner) == 0 do
        (
            append seen owner
            if superClassOf owner == textureMap do
            (
                for p in #(#filename, #HDRIMapName) where isProperty owner p do
                (
                    local v = try (getProperty owner p) catch (undefined)
                    if classOf v == String and v != "" do
                    (
                        append owners owner
                        append props p
                        append paths v
                    )
                )
            )
            if superClassOf owner != textureMap do
                for i = 1 to (try (getNumSubMtls owner) catch (0)) do append pending (getSubMtl owner i)
            for i = 1 to (try (getNumSubTexmaps owner) catch (0)) do append pending (getSubTexmap owner i)
        )
    )
    #(owners, props, paths)
)

fn NSC_Retarget olds news refreshAfter:true =
(
    local done = for o in olds collect false
    for i = 1 to olds.count do try
    (
        ATSOps.ClearSelection()
        ATSOps.SelectFiles #(olds[i])
        done[i] = (ATSOps.RetargetSelection news[i]) == true
        ATSOps.ClearSelection()
    )
    catch ()
    if refreshAfter do try (ATSOps.Refresh()) catch()
    done
)

fn NSC_SaveCopy f =
(
    saveMaxFile f useNewFile:false quiet:true
)

fn NSC_MaxToPng src dest =
(
    local b = try (openBitMap src) catch (undefined)
    if b == undefined do return false

    local ok2 = try
    (
        pngio.setType #true24
        pngio.setAlpha true
        local out = bitmap b.width b.height filename:dest
        copy b out
        save out
        close out
        true
    )
    catch (false)

    close b
    ok2 and doesFileExist dest
)
