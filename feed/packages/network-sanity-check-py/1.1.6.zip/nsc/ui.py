"""VR Asset Tracker - Qt window (Python version). Audit, Assets + Search & Collect, Archive, Log."""
import os
import shutil
import subprocess
import time
import tempfile

from . import __version__

from .qt import QtCore, QtGui, QtWidgets, Qt, QAction, max_main_window
from . import scan as scanmod
from . import ops
from . import maxops
from .config import config

ACCENT = '#a0acd6'
ACCENT_HI = '#b6c0e4'
BG = '#14161d'
SIDE = '#1a1d26'
CARD = '#1e222c'
CARD_HI = '#262b37'
TEXT = '#dfe3ee'
MUTED = '#8c93a6'
RED = '#e0707a'
AMBER = '#e0b870'

STYLE = """
QWidget#nscRoot { background: %(BG)s; color: %(TEXT)s; font-size: 9pt; }
QWidget#nscSide { background: %(SIDE)s; }
QFrame#card { background: %(CARD)s; border-radius: 6px; }
QLabel { color: %(TEXT)s; background: transparent; }
QLabel#muted, QLabel#section { color: %(MUTED)s; }
QLabel#section { font-weight: bold; font-size: 8pt; }
QLabel#title { font-size: 15pt; font-weight: bold; }
QPushButton { background: %(CARD_HI)s; color: %(TEXT)s; border: 0; padding: 6px 12px; border-radius: 4px; }
QPushButton:hover { background: #303646; }
QPushButton:disabled { color: #5a6070; background: %(CARD)s; }
QPushButton#accent { background: %(ACCENT)s; color: #181c28; font-weight: bold; }
QPushButton#accent:hover { background: %(ACCENT_HI)s; }
QPushButton#accent:disabled { background: %(CARD_HI)s; color: #5a6070; }
QPushButton#nav { background: transparent; text-align: left; padding: 10px 14px; font-size: 10pt; font-weight: bold; color: %(MUTED)s; }
QPushButton#nav:checked { background: %(CARD_HI)s; color: %(TEXT)s; }
QLineEdit { background: %(CARD_HI)s; color: %(TEXT)s; border: 0; padding: 5px; border-radius: 3px; }
QTableView, QListWidget, QPlainTextEdit { background: %(CARD)s; color: %(TEXT)s; border: 0;
    selection-background-color: #3a4462; selection-color: %(TEXT)s; alternate-background-color: #21252f; }
QHeaderView::section { background: %(CARD_HI)s; color: %(MUTED)s; border: 0; padding: 5px; font-weight: bold; }
QCheckBox, QRadioButton { color: %(TEXT)s; background: transparent; spacing: 7px; }
QCheckBox::indicator, QListWidget::indicator, QTableView::indicator { width: 14px; height: 14px;
    border: 1px solid #6a7288; border-radius: 3px; background: %(BG)s; }
QCheckBox::indicator:hover, QListWidget::indicator:hover, QTableView::indicator:hover { border-color: %(ACCENT)s; }
QCheckBox::indicator:checked, QListWidget::indicator:checked, QTableView::indicator:checked {
    background: %(ACCENT)s; border-color: %(ACCENT)s; image: url(%(TICK)s); }
QProgressBar { background: %(CARD_HI)s; border: 0; height: 6px; border-radius: 3px; text-align: center; color: transparent; }
QProgressBar::chunk { background: %(ACCENT)s; border-radius: 3px; }
""" % dict(BG=BG, SIDE=SIDE, CARD=CARD, CARD_HI=CARD_HI, TEXT=TEXT, MUTED=MUTED, ACCENT=ACCENT, ACCENT_HI=ACCENT_HI, TICK='@TICK@')

STATUS_TEXT = {'ok': 'Ok', 'found': 'Found', 'missing': 'Missing'}

# Survives closing the window: reopening in the same session shows the last scan at once
_CACHE = {'result': None, 'log': []}


def tick_image():
    """Dark tick mark PNG for checked boxes (drawn once, plus an @2x copy for high-DPI screens)."""
    import tempfile
    folder = os.path.join(tempfile.gettempdir(), 'nsc_ui')
    path = os.path.join(folder, 'tick.png')
    if not os.path.isfile(path):
        os.makedirs(folder, exist_ok=True)
        for scale, name in ((1, 'tick.png'), (2, 'tick@2x.png')):
            n = 14 * scale
            img = QtGui.QImage(n, n, QtGui.QImage.Format_ARGB32)
            img.fill(Qt.transparent)
            pa = QtGui.QPainter(img)
            pa.setRenderHint(QtGui.QPainter.Antialiasing)
            pen = QtGui.QPen(QtGui.QColor('#14161d'), 2.2 * scale)
            pen.setCapStyle(Qt.RoundCap)
            pen.setJoinStyle(Qt.RoundJoin)
            pa.setPen(pen)
            pa.drawPolyline(QtGui.QPolygonF([QtCore.QPointF(3.2 * scale, 7.4 * scale),
                                             QtCore.QPointF(5.9 * scale, 10.1 * scale),
                                             QtCore.QPointF(10.9 * scale, 4.0 * scale)]))
            pa.end()
            img.save(os.path.join(folder, name))
    return path.replace(os.sep, '/')


def fmt_size(b):
    if b >= 1 << 30:
        return '%.2f GB' % (b / float(1 << 30))
    if b >= 1 << 20:
        return '%.2f MB' % (b / float(1 << 20))
    return '%.1f kB' % (b / 1024.0)


def log(msg):
    line = '[%s]  %s' % (time.strftime('%H:%M:%S'), msg)
    _CACHE['log'].append(line)
    print('[NSC] ' + msg)
    w = NSCWindow.instance
    if w is not None:
        w.log_view.appendPlainText(line)


def label(text, name=None):
    l = QtWidgets.QLabel(text)
    if name:
        l.setObjectName(name)
    return l


def button(text, slot, accent=False, tip=''):
    b = QtWidgets.QPushButton(text)
    if accent:
        b.setObjectName('accent')
    if tip:
        b.setToolTip(tip)
    b.clicked.connect(lambda *_: slot())
    return b


def card():
    f = QtWidgets.QFrame()
    f.setObjectName('card')
    return f


def make_table(model, proxy):
    proxy.setSourceModel(model)
    tv = QtWidgets.QTableView()
    tv.setModel(proxy)
    tv.setSortingEnabled(True)
    tv.setSelectionBehavior(QtWidgets.QAbstractItemView.SelectRows)
    tv.setSelectionMode(QtWidgets.QAbstractItemView.ExtendedSelection)
    tv.setAlternatingRowColors(True)
    tv.setShowGrid(False)
    tv.setWordWrap(False)
    tv.verticalHeader().setVisible(False)
    tv.verticalHeader().setDefaultSectionSize(22)
    tv.horizontalHeader().setHighlightSections(False)
    return tv


class Proxy(QtCore.QSortFilterProxyModel):
    """Filters by a predicate on the source row object; sorts by Qt.UserRole."""
    def __init__(self, parent=None):
        super(Proxy, self).__init__(parent)
        self.accept = None
        self.setSortRole(Qt.UserRole)

    def refilter(self):
        if hasattr(self, 'invalidateRowsFilter'):
            self.invalidateRowsFilter()
        else:
            self.invalidateFilter()

    def filterAcceptsRow(self, row, parent):
        return self.accept is None or self.accept(self.sourceModel().rows[row])


# ------------------------------------------------------------------------------------------
# Assets model
# ------------------------------------------------------------------------------------------

class AssetModel(QtCore.QAbstractTableModel):
    COLUMNS = ['Name', 'Folder', 'Size', 'Status', 'Used', 'Refs', 'Type']

    def __init__(self, parent=None):
        super(AssetModel, self).__init__(parent)
        self.rows = []
        self._red = QtGui.QBrush(QtGui.QColor(RED))
        self._amber = QtGui.QBrush(QtGui.QColor(AMBER))
        self._muted = QtGui.QBrush(QtGui.QColor('#5f6577'))

    def set_rows(self, rows):
        self.beginResetModel()
        self.rows = list(rows)
        self.endResetModel()

    def refresh(self):
        if self.rows:
            self.dataChanged.emit(self.index(0, 0), self.index(len(self.rows) - 1, len(self.COLUMNS) - 1))

    def rowCount(self, parent=QtCore.QModelIndex()):
        return 0 if parent.isValid() else len(self.rows)

    def columnCount(self, parent=QtCore.QModelIndex()):
        return len(self.COLUMNS)

    def headerData(self, section, orientation, role=Qt.DisplayRole):
        if orientation == Qt.Horizontal and role == Qt.DisplayRole:
            return self.COLUMNS[section]
        return None

    def data(self, index, role=Qt.DisplayRole):
        it = self.rows[index.row()]
        c = index.column()
        folder = os.path.dirname(it.resolved) if it.resolved else it.folder
        if role == Qt.DisplayRole:
            return (it.name, folder, fmt_size(it.size) if it.resolved else '-',
                    STATUS_TEXT[it.status], 'Used' if it.used else 'Unused', len(it.refs), '%s  %s' % (it.kind, it.ext))[c]
        if role == Qt.UserRole:
            return (it.name.lower(), folder.lower(), it.size, it.status, int(it.used), len(it.refs), it.kind + it.ext)[c]
        if role == Qt.ForegroundRole:
            if not it.used:
                return self._muted
            if it.status == 'missing':
                return self._red
            if it.status == 'found' and c == 3:
                return self._amber
        if role == Qt.ToolTipRole:
            t = it.resolved or it.path
            return t if it.used else t + '\nUnused: only in the Material Editor or not assigned - never collected or archived'
        if role == Qt.TextAlignmentRole and c == 2:
            return int(Qt.AlignRight | Qt.AlignVCenter)
        return None


# ------------------------------------------------------------------------------------------
# Audit model: one row per problem, with a tick box. Only assets the scene really uses.
# ------------------------------------------------------------------------------------------

# New tabbed audit categories
AUDIT_TABS = (
    ('Effects', 'Render Effects', 'Remove'),
    ('Convert', 'TIFF / TX / TIF', 'Convert to PNG'),
)

# Keep CATS for backward compatibility with Prepare for render
CATS = (
    ('Relink', 'Relative / moved paths', 'Make absolute'),
    ('Missing', 'Missing files', 'Search && relink'),
    ('Convert', 'TX / TIF to convert', 'Convert to PNG'),
    ('Collect', 'Not in maps folder', 'Collect to maps'),
    ('Effects', 'Render effects', 'Remove effects'),
)


class ARow(object):
    __slots__ = ('cat', 'status', 'item', 'effect', 'ticked', 'label', 'note')

    def __init__(self, cat, status, item=None, effect=None, label_='', note=''):
        self.cat, self.status, self.item, self.effect = cat, status, item, effect
        self.ticked = False
        self.label, self.note = label_, note

    @property
    def path(self):
        return self.item.path if self.item else self.effect[1]

    @property
    def ext(self):
        return self.item.ext if self.item else ''

    def fixable(self):
        if self.cat == 'Relink':
            return self.status == 'found'
        if self.cat == 'Missing':
            return self.item.status == 'missing'
        if self.cat == 'Convert':
            return self.item.resolved is not None and bool(self.item.refs)
        if self.cat == 'Collect':
            return self.item.resolved is not None
        return True


def build_audit_rows(r, maps_dir):
    rows = []
    used = [it for it in r.items if it.used]
    # Tab 1: Render Effects
    for i, name in enumerate(r.effects):
        rows.append(ARow('Effects', 'effect', effect=(i + 1, name), label_='REMOVE', note='Render effect'))
    # Tab 2: Convert (TIFF/TX/TIF with refs)
    for it in used:
        if it.ext in scanmod.CONVERT_EXTS and (it.refs or r.mode == "quick"):
            rows.append(ARow('Convert', 'convert', it, label_='CONVERT',
                             note=('source missing' if not it.resolved else 'Find references and relink checked textures' if not it.refs else '->  maps\\%s.png' % os.path.splitext(it.name)[0])))
    # Tab 3: Relink (relative/moved paths)
    for it in used:
        if it.status == 'found':
            rows.append(ARow('Relink', 'found', it, label_='RELATIVE' if it.relative else 'MOVED',
                             note='->  ' + it.resolved))
    # Tab 4: Missing
    for it in used:
        if it.status == 'missing':
            rows.append(ARow('Missing', 'missing', it, label_='MISSING',
                             note='relative, cannot locate the file' if it.relative else 'file does not exist'))
    # Collect (keep for Prepare for render)
    if maps_dir:
        for it in used:
            if it.resolved and not it.in_folder(maps_dir) and not (it.ext in scanmod.CONVERT_EXTS and it.refs):
                rows.append(ARow('Collect', 'collect', it, label_='NOT IN MAPS', note='copy to  ' + maps_dir))
    return rows


class AuditModel(QtCore.QAbstractTableModel):
    COLUMNS = ['Status', 'Type', 'Ext', 'Path', 'Note']

    def __init__(self, parent=None):
        super(AuditModel, self).__init__(parent)
        self.rows = []
        self._cols = {'ok': QtGui.QBrush(QtGui.QColor(MUTED)), 'found': QtGui.QBrush(QtGui.QColor(AMBER)),
                      'missing': QtGui.QBrush(QtGui.QColor(RED)), 'convert': QtGui.QBrush(QtGui.QColor(ACCENT_HI)),
                      'effect': QtGui.QBrush(QtGui.QColor(AMBER)), 'collect': QtGui.QBrush(QtGui.QColor(ACCENT_HI))}

    def set_rows(self, rows):
        self.beginResetModel()
        self.rows = rows
        self.endResetModel()

    def rowCount(self, parent=QtCore.QModelIndex()):
        return 0 if parent.isValid() else len(self.rows)

    def columnCount(self, parent=QtCore.QModelIndex()):
        return len(self.COLUMNS)

    def headerData(self, section, orientation, role=Qt.DisplayRole):
        if orientation == Qt.Horizontal and role == Qt.DisplayRole:
            return self.COLUMNS[section]
        return None

    def flags(self, index):
        return Qt.ItemIsEnabled | Qt.ItemIsSelectable | (Qt.ItemIsUserCheckable if index.column() == 0 else Qt.NoItemFlags)

    def data(self, index, role=Qt.DisplayRole):
        r = self.rows[index.row()]
        c = index.column()
        if role == Qt.DisplayRole:
            kind = r.item.kind if r.item else 'Render effect'
            return (r.label, kind, r.ext, r.path, r.note)[c]
        if role == Qt.UserRole:
            return (r.label, r.cat, r.ext, r.path.lower(), r.note.lower())[c]
        if role == Qt.CheckStateRole and c == 0:
            return Qt.Checked if r.ticked else Qt.Unchecked
        if role == Qt.ForegroundRole and c == 0:
            return self._cols[r.status]
        if role == Qt.ToolTipRole:
            return r.path + ('\n' + r.note if r.note else '')
        return None

    def setData(self, index, value, role=Qt.EditRole):
        if role == Qt.CheckStateRole and index.column() == 0:
            try:
                value = Qt.CheckState(value)
            except Exception:
                pass
            self.rows[index.row()].ticked = value == Qt.Checked
            self.dataChanged.emit(index, index)
            self.ticks_changed()
            return True
        return False

    def ticks_changed(self):
        pass  # replaced by the window


class TickTable(QtWidgets.QTableView):
    """Space ticks / unticks the selected rows (Explorer-style multi-select is built in)."""
    space = QtCore.Signal() if hasattr(QtCore, 'Signal') else None

    def keyPressEvent(self, e):
        if e.key() == Qt.Key_Space and self.space is not None:
            self.space.emit()
            return
        super(TickTable, self).keyPressEvent(e)


class TickHeader(QtWidgets.QHeaderView):
    """Horizontal header with a tri-state master checkbox in section 0 (the tick column).
    Click the checkbox zone (left edge of section 0) to tick/untick every shown row."""
    toggled = QtCore.Signal(bool) if hasattr(QtCore, 'Signal') else None

    def __init__(self, parent=None):
        super(TickHeader, self).__init__(Qt.Horizontal, parent)
        self._check = Qt.Unchecked
        self.setSectionsClickable(True)

    def set_check_state(self, state):
        if state != self._check:
            self._check = state
            self.updateSection(0)

    def check_state(self):
        return self._check

    def paintSection(self, painter, rect, logicalIndex):
        painter.save()
        super(TickHeader, self).paintSection(painter, rect, logicalIndex)
        if logicalIndex == 0:
            opt = QtWidgets.QStyleOptionButton()
            opt.rect = QtCore.QRect(rect.left() + 5, rect.top() + (rect.height() - 14) // 2, 14, 14)
            if self._check == Qt.Checked:
                opt.state = opt.state | QtWidgets.QStyle.State_On
            elif self._check == Qt.PartiallyChecked:
                opt.state = opt.state | QtWidgets.QStyle.State_NoChange
            else:
                opt.state = opt.state | QtWidgets.QStyle.State_Off
            self.style().drawControl(QtWidgets.QStyle.CE_CheckBox, opt, painter, self)
        painter.restore()

    def mousePressEvent(self, e):
        btn = e.button()
        pos = e.position().toPoint() if hasattr(e, 'position') else e.pos()
        if btn == Qt.LeftButton and self.logicalIndexAt(pos) == 0:
            if pos.x() - self.sectionViewportPosition(0) <= 26:
                if self.toggled is not None:
                    self.toggled.emit(self._check != Qt.Checked)
                return
        super(TickHeader, self).mousePressEvent(e)


# ------------------------------------------------------------------------------------------
# Window
# ------------------------------------------------------------------------------------------

class NSCWindow(QtWidgets.QWidget):
    instance = None

    def __init__(self, parent=None):
        super(NSCWindow, self).__init__(parent)
        self.setWindowFlags(Qt.Window | Qt.WindowMinMaxButtonsHint | Qt.WindowCloseButtonHint)
        self.setWindowTitle('VR Asset Tracker')
        self.setObjectName('nscRoot')
        self.setAttribute(Qt.WA_DeleteOnClose)
        self.setStyleSheet(STYLE.replace('@TICK@', tick_image()))
        self.resize(1240, 820)
        self.result = None
        self.busy = False
        self.job = None
        self._scan_cancel = None
        self.action_buttons = []
        self.texture_context_handlers = {}
        self._build()

    # ---- shell ---------------------------------------------------------------------------
    def _build(self):
        root = QtWidgets.QHBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        side = QtWidgets.QWidget()
        side.setObjectName('nscSide')
        side.setFixedWidth(220)
        sl = QtWidgets.QVBoxLayout(side)
        sl.setContentsMargins(14, 20, 14, 16)
        brand = label('VR Asset Tracker', 'title')
        brand.setStyleSheet('font-size: 13pt;')
        sl.addWidget(brand)
        sl.addWidget(label('Network render preflight', 'muted'))
        sl.addSpacing(24)
        self.nav = QtWidgets.QButtonGroup(self)
        self.stack = QtWidgets.QStackedWidget()
        pages = [('Audit', self._page_audit()), ('Assets', self._page_assets()),
                 ('Archive', self._page_archive()), ('Log', self._page_log())]
        for i, (name, page) in enumerate(pages):
            b = QtWidgets.QPushButton(name)
            b.setObjectName('nav')
            b.setCheckable(True)
            self.nav.addButton(b, i)
            sl.addWidget(b)
            self.stack.addWidget(page)
        self.nav.buttonClicked.connect(lambda b: self.stack.setCurrentIndex(self.nav.id(b)))
        sl.addStretch(1)
        quick_btn = button('Quick audit', lambda: self.run_scan(quick=True), accent=True)
        quick_btn.setToolTip('Asset Tracker inputs and render effects; skips map-owner/usage inspection.')
        self.action_buttons.append(quick_btn)
        sl.addWidget(quick_btn)
        scan_btn = button('Full scan', self.run_scan)
        scan_btn.setToolTip('Inspect map owners and usage as well; required for image conversion.')
        self.action_buttons.append(scan_btn)
        sl.addWidget(scan_btn)
        release = 'v' + __version__ if __version__ else 'Development'
        sl.addWidget(label(f'{release} (Python)  |  VR_tools', 'muted'))
        root.addWidget(side)

        main = QtWidgets.QVBoxLayout()
        main.setContentsMargins(24, 16, 24, 16)
        top = QtWidgets.QHBoxLayout()
        self.title = label('Audit', 'title')
        top.addWidget(self.title)
        top.addStretch(1)
        self.status = label('Ready', 'muted')
        self.status.setWordWrap(True)
        self.status.setFixedHeight(48)
        self.status.setMinimumWidth(0)
        self.status.setMaximumWidth(680)
        self.status.setSizePolicy(QtWidgets.QSizePolicy.Ignored, QtWidgets.QSizePolicy.Fixed)
        top.addWidget(self.status)
        self.cancel_btn = button('Cancel', self.cancel)
        self.cancel_btn.setFixedWidth(110)
        policy = self.cancel_btn.sizePolicy()
        policy.setRetainSizeWhenHidden(True)
        self.cancel_btn.setSizePolicy(policy)
        self.cancel_btn.setVisible(False)
        top.addWidget(self.cancel_btn)
        main.addLayout(top)
        self.bar = QtWidgets.QProgressBar()
        self.bar.setFixedHeight(19)
        self.bar.setAlignment(Qt.AlignCenter)
        self.bar.setStyleSheet("QProgressBar { background: #252938; color: white; border: 1px solid #505773; border-radius: 4px; } QProgressBar::chunk { background: #526aa4; }")
        self.bar.setRange(0, 1000)
        policy = self.bar.sizePolicy()
        policy.setRetainSizeWhenHidden(True)
        self.bar.setSizePolicy(policy)
        self.bar.setVisible(False)
        main.addWidget(self.bar)
        self.step_bar = QtWidgets.QProgressBar()
        self.step_bar.setFixedHeight(19)
        self.step_bar.setAlignment(Qt.AlignCenter)
        self.step_bar.setSizePolicy(policy)
        self.step_bar.setStyleSheet(self.bar.styleSheet().replace('#526aa4', '#367765'))
        self.step_bar.hide()
        main.addWidget(self.step_bar)
        main.addWidget(self.stack, 1)
        root.addLayout(main, 1)
        self.stack.currentChanged.connect(lambda i: (self.title.setText(self.nav.button(i).text()),
                                                     self.nav.button(i).setChecked(True)))
        self.nav.button(0).setChecked(True)
        self.stack.setCurrentIndex(0)

    def _page_soon(self, text):
        w = QtWidgets.QWidget()
        l = QtWidgets.QVBoxLayout(w)
        l.addWidget(label(text + '\nThe MAXScript version (NetworkSanityCheck.ms) still has it meanwhile.', 'muted'))
        l.addStretch(1)
        return w

    def _page_log(self):
        w = QtWidgets.QWidget()
        l = QtWidgets.QVBoxLayout(w)
        self.log_view = QtWidgets.QPlainTextEdit()
        self.log_view.setReadOnly(True)
        self.log_view.setFont(QtGui.QFont('Consolas', 9))
        self.log_view.setPlainText('\n'.join(_CACHE['log']))
        l.addWidget(self.log_view)
        l.addWidget(button('Clear log', lambda: (_CACHE['log'].clear(), self.log_view.clear())))
        l.addWidget(button('Save log...', self._save_log, tip='Write the log to a text file'), 0, Qt.AlignLeft)
        return w

    def _save_log(self):
        p, _flt = QtWidgets.QFileDialog.getSaveFileName(self, 'Save log', 'nsc_log.txt', 'Text (*.txt)')
        if not p:
            return
        try:
            with open(p, 'w', encoding='utf-8') as f:
                f.write(chr(10).join(_CACHE['log']) + chr(10))
            log('Log saved: ' + p)
        except OSError as e:
            QtWidgets.QMessageBox.warning(self, 'Save log', str(e))

    # ---- Audit page ----------------------------------------------------------------------
    def _page_audit(self):
        w = QtWidgets.QWidget()
        outer = QtWidgets.QVBoxLayout(w)
        outer.setContentsMargins(0, 8, 0, 0)
        
        # Tabbed audit tables
        self.aud_tabs = QtWidgets.QTabWidget()
        self.aud_tab_widgets = {}
        self.aud_tab_models = {}
        self.aud_tab_proxies = {}
        self.aud_tab_tables = {}
        self.aud_tab_searches = {}
        self.aud_tab_fix_btns = {}
        self.aud_tab_headers = {}
        
        for cat_key, cat_label, btn_text in AUDIT_TABS:
            tab_widget = self._create_audit_tab(cat_key, cat_label, btn_text)
            self.aud_tabs.addTab(tab_widget, cat_label)
            self.aud_tab_widgets[cat_key] = tab_widget
        
        outer.addWidget(self.aud_tabs, 1)
        
        # Converter info label
        self.conv_label = label('', 'muted')
        self.conv_label.setWordWrap(True)
        outer.addWidget(self.conv_label)
        
        # Rescan button at bottom
        rb = button('Rescan', self.run_scan)
        self.action_buttons.append(rb)
        outer.addWidget(rb, 0, Qt.AlignLeft)
        
        # Prepare for render button
        prep = button('Prepare for render', self._prepare, accent=True,
                      tip='Runs every fix in order: make absolute, search missing, convert, collect to maps, remove effects')
        prep.setMinimumHeight(40)
        self.action_buttons.append(prep)
        self.prep_btn = prep
        outer.addWidget(prep, 0, Qt.AlignLeft)
        
        return w

    def _create_audit_tab(self, cat_key, cat_label, btn_text):
        """Create a single audit tab with table, search, and action button."""
        tab = QtWidgets.QWidget()
        layout = QtWidgets.QVBoxLayout(tab)
        layout.setContentsMargins(0, 8, 0, 0)
        
        # Search box
        search = QtWidgets.QLineEdit()
        search.setPlaceholderText(f'Search {cat_label.lower()}...')
        search.textChanged.connect(lambda *_, k=cat_key: self._aud_tab_refilter(k))
        layout.addWidget(search)
        self.aud_tab_searches[cat_key] = search
        
        # Highlighting rows does not tick them: expose explicit bulk controls.
        bulk = QtWidgets.QHBoxLayout()
        for text, on in (('Select all listed', True), ('Clear selection', False)):
            control = button(text, lambda k=cat_key, value=on: self._aud_tab_tick_all(k, value))
            self.action_buttons.append(control)
            bulk.addWidget(control)
        bulk.addStretch(1)
        layout.addLayout(bulk)

        # Table
        model = AuditModel(self)
        model.ticks_changed = self._aud_counts
        proxy = Proxy(self)
        tv = TickTable()
        proxy.setSourceModel(model)
        tv.setModel(proxy)
        tv.setSortingEnabled(True)
        tv.setSelectionBehavior(QtWidgets.QAbstractItemView.SelectRows)
        tv.setSelectionMode(QtWidgets.QAbstractItemView.ExtendedSelection)
        tv.setAlternatingRowColors(True)
        tv.setShowGrid(False)
        tv.setWordWrap(False)
        tv.verticalHeader().setVisible(False)
        tv.verticalHeader().setDefaultSectionSize(22)
        if tv.space is not None:
            tv.space.connect(lambda k=cat_key: self._aud_tab_space(k))
        
        # Master tick-all checkbox in the header of column 0
        hdr = TickHeader(tv)
        tv.setHorizontalHeader(hdr)
        hdr.setSectionResizeMode(3, QtWidgets.QHeaderView.Stretch)
        hdr.setSectionResizeMode(0, QtWidgets.QHeaderView.Interactive)
        for col, wd in ((0, 170), (1, 90), (2, 55), (4, 300)):
            hdr.resizeSection(col, wd)
        hdr.toggled.connect(lambda on, k=cat_key: self._aud_tab_tick_all(k, on))
        self.aud_tab_headers[cat_key] = hdr
        
        self.aud_tab_models[cat_key] = model
        self.aud_tab_proxies[cat_key] = proxy
        self.aud_tab_tables[cat_key] = tv
        if cat_key != 'Effects':
            self._bind_texture_menu(tv, lambda pos, key=cat_key: self._audit_asset_menu(key, pos))
        layout.addWidget(tv, 1)
        
        # Meta label
        meta = label('', 'muted')
        layout.addWidget(meta)
        setattr(self, f'aud_meta_{cat_key}', meta)
        
        # Fix button
        fix_btn = button(btn_text, lambda k=cat_key: self._aud_tab_fix(k), accent=True)
        fix_btn.setStyleSheet('padding: 6px 8px;')
        fix_btn.setMinimumWidth(fix_btn.fontMetrics().boundingRect(btn_text + '  (9999)').width() + 24)
        self.action_buttons.append(fix_btn)
        self.aud_tab_fix_btns[cat_key] = (fix_btn, btn_text)
        layout.addWidget(fix_btn, 0, Qt.AlignLeft)
        
        return tab

    def _aud_tab_accept(self, cat_key, row):
        """Filter function for a specific tab."""
        search = self.aud_tab_searches[cat_key].text().strip().lower()
        if search and search not in row.path.lower():
            return False
        # Only show rows matching this tab's category
        return row.cat == cat_key

    def _aud_tab_refilter(self, cat_key):
        proxy = self.aud_tab_proxies[cat_key]
        proxy.accept = lambda r: self._aud_tab_accept(cat_key, r)
        proxy.refilter()
        self._aud_tab_update_counts(cat_key)

    def _aud_tab_update_counts(self, cat_key):
        proxy = self.aud_tab_proxies[cat_key]
        model = self.aud_tab_models[cat_key]
        shown = [model.rows[proxy.mapToSource(proxy.index(i, 0)).row()] for i in range(proxy.rowCount())]
        fix_btn, btn_text = self.aud_tab_fix_btns[cat_key]
        quick_convert = cat_key == 'Convert' and self.result is not None and self.result.mode == 'quick'
        n = sum(r.ticked and (bool(r.item.resolved) if quick_convert else r.fixable()) for r in shown)
        fix_btn.setText(f'{btn_text}  ({n})')
        fix_btn.setEnabled(not self.busy and n > 0)
        meta = getattr(self, f'aud_meta_{cat_key}')
        ticked = len([r for r in shown if r.ticked])
        meta.setText(f'{ticked} ticked   |   {len(shown)} of {len(model.rows)} rows shown')
        # Master header checkbox: checked / partial / unchecked
        hdr = self.aud_tab_headers.get(cat_key)
        if hdr is not None:
            if shown and ticked == len(shown):
                hdr.set_check_state(Qt.Checked)
            elif ticked > 0:
                hdr.set_check_state(Qt.PartiallyChecked)
            else:
                hdr.set_check_state(Qt.Unchecked)

    def _aud_tab_tick_all(self, cat_key, on):
        """Tick / untick every shown row in a tab (header master checkbox)."""
        model = self.aud_tab_models[cat_key]
        for r in self._aud_shown_tab(cat_key):
            r.ticked = on
        model.layoutChanged.emit()
        self._aud_tab_update_counts(cat_key)
        self._aud_counts()

    def _aud_tab_fix(self, cat_key):
        """Run the fix for a specific tab."""
        if self.busy:
            return
        proxy = self.aud_tab_proxies[cat_key]
        model = self.aud_tab_models[cat_key]
        shown = [model.rows[proxy.mapToSource(proxy.index(i, 0)).row()] for i in range(proxy.rowCount())]
        if cat_key == 'Convert' and self.result.mode == 'quick':
            self._convert_items([r.item for r in shown if r.ticked and r.item.resolved], self.after_change)
            return
        rows = [r for r in shown if r.ticked and r.fixable()]
        if not rows:
            return
        self._aud_fix(cat_key, rows)

    def _aud_tab_space(self, cat_key):
        """Space key toggles ticks in a specific tab."""
        table = self.aud_tab_tables[cat_key]
        proxy = self.aud_tab_proxies[cat_key]
        model = self.aud_tab_models[cat_key]
        rows = [model.rows[proxy.mapToSource(i).row()] for i in table.selectionModel().selectedRows()]
        if not rows:
            return
        on = not all(r.ticked for r in rows)
        for r in rows:
            r.ticked = on
        table.viewport().update()
        self._aud_tab_update_counts(cat_key)

    def _aud_counts(self):
        """Update counts for all tabs."""
        for cat_key in self.aud_tab_models:
            self._aud_tab_update_counts(cat_key)
        # Also update Prepare button state
        total_fixable = sum(
            len([r for r in self._aud_shown_tab(k) if r.ticked and r.fixable()])
            for k in self.aud_tab_models
        )
        pb = getattr(self, 'prep_btn', None)
        if pb is not None:
            pb.setEnabled((total_fixable > 0 or any(r.fixable() for r in getattr(self, "_prepare_path_rows", ()))) and not self.busy and self.result is not None and self.result.mode != "quick")
            pb.setToolTip("Run Full scan before Prepare for render" if self.result is not None and self.result.mode == "quick" else "Prepare for render")

    def _aud_shown_tab(self, cat_key):
        proxy = self.aud_tab_proxies[cat_key]
        model = self.aud_tab_models[cat_key]
        return [model.rows[proxy.mapToSource(proxy.index(i, 0)).row()] for i in range(proxy.rowCount())]

    def _folders_panel(self):
        panel = card()
        g = QtWidgets.QGridLayout(panel)
        g.setContentsMargins(12, 8, 12, 8)
        g.setHorizontalSpacing(12)
        g.setVerticalSpacing(4)
        # --- left column: maps folder on top, search folders below it
        ml = label('MAPS FOLDER  (collected files and converted PNGs go here)', 'section')
        ml.setToolTip('Paths are written absolute, e.g. Z:\\project\\maps\\wood.png')
        g.addWidget(ml, 0, 0)
        mh = QtWidgets.QHBoxLayout()
        self.maps_edit = QtWidgets.QLineEdit()
        self.maps_edit.setPlaceholderText('Save the scene first')
        self.maps_edit.editingFinished.connect(self._maps_edited)
        mh.addWidget(self.maps_edit, 1)
        mh.addWidget(button('...', self._browse_maps, tip='Choose the maps folder'))
        g.addLayout(mh, 1, 0)
        g.addWidget(label('SEARCH FOLDERS  for missing files (ticked ones are searched)', 'section'), 2, 0)
        dh = QtWidgets.QHBoxLayout()
        self.dirs = QtWidgets.QListWidget()
        self.dirs.setMinimumHeight(46)
        self.dirs.setMaximumHeight(64)
        self.dirs.setTextElideMode(Qt.ElideMiddle)
        self.dirs.itemChanged.connect(lambda *_: self._save_dirs())
        self.dirs.itemDoubleClicked.connect(self._edit_dir)
        dh.addWidget(self.dirs, 1)
        db = QtWidgets.QVBoxLayout()
        db.setSpacing(2)
        db.addWidget(button('+', self._add_dir, tip='Add a search folder'))
        db.addWidget(button('-', self._remove_dir, tip='Remove the selected folder'))
        db.addStretch(1)
        dh.addLayout(db)
        g.addLayout(dh, 3, 0)
        self.col_recursive = QtWidgets.QCheckBox('Search subfolders too')
        self.col_recursive.setChecked(maxops.ini_get('Assets', 'recursive') != 'false')
        self.col_recursive.toggled.connect(
            lambda on: maxops.ini_set('Assets', 'recursive', 'true' if on else 'false'))
        g.addWidget(self.col_recursive, 4, 0)
        # --- right column: operations + START
        self.op_scope = QtWidgets.QComboBox()
        self.op_scope.addItems(['All shown rows', 'Selected rows only'])
        g.addWidget(self.op_scope, 0, 1)
        opl = QtWidgets.QVBoxLayout()
        opl.setSpacing(2)
        self.op_search = QtWidgets.QCheckBox('Search && Relink  (find missing files)')
        self.op_relocate = QtWidgets.QCheckBox('Relocate Links  (make paths absolute)')
        self.op_collect = QtWidgets.QCheckBox('Collect  (copy into maps folder)')
        self.op_search.setChecked(True)
        self.op_collect.setChecked(True)
        self.op_relocate.setChecked(True)
        for cb in (self.op_search, self.op_relocate, self.op_collect):
            opl.addWidget(cb)
        start = button('START', self._start_ops, accent=True,
                       tip='Process the chosen scope. Collect verifies absolute scene links in the maps folder.')
        start.setMinimumHeight(30)
        self.action_buttons.append(start)
        opl.addWidget(start)
        g.addLayout(opl, 1, 1, 4, 1)
        g.setColumnStretch(0, 1)
        g.setColumnStretch(1, 0)
        panel.setMaximumHeight(150)
        self._maps_auto = True
        self._scene_seen = None
        self._load_dirs()
        return panel

    def _aud_rows(self, cat, ticked=True):
        """Rows a fix works on: the ticked, shown ones - or (Prepare for render) every row of the category."""
        if ticked:
            # Get shown rows from the relevant tab
            if cat in self.aud_tab_models:
                return self._aud_shown_tab(cat)
            return []
        else:
            # Get ALL rows of this category across all tabs (for Prepare for render)
            all_rows = list(self._prepare_path_rows)
            for model in self.aud_tab_models.values():
                all_rows.extend(model.rows)
            return [r for r in all_rows if r.cat == cat and r.fixable()]

    # ---- fixes: each updates the list in place when done (no rescan) -----------------------
    def _aud_fix(self, cat, rows=None, then=None):
        """then: next step of "Prepare for render" (no questions asked inside the chain)."""
        if self.busy:
            return
        rows = self._aud_rows(cat) if rows is None else rows
        if not rows:
            if then:
                then()
            return
        ask = then is None

        def done(msg):
            self.after_change(msg)
            if then:
                then()

        if cat == 'Relink':
            pairs = [(r.item, r.item.resolved) for r in rows]
            with maxops.undo('NSC Make paths absolute'):
                n = ops.relink(pairs, log)
            log('Made %d of %d path(s) absolute' % (n, len(pairs)))
            done('Made %d path(s) absolute' % n)
        elif cat == 'Missing':
            self._search_missing([r.item for r in rows], ask, done)
        elif cat == 'Convert':
            self._convert_items([r.item for r in rows], done)
        elif cat == 'Collect':
            self._copy_to_maps([r.item for r in rows], False, ask, done)
        elif cat == 'Effects':
            if ask and QtWidgets.QMessageBox.question(self, 'Remove effects', 'Remove %d render effect(s)?' % len(rows)) \
                    != QtWidgets.QMessageBox.Yes:
                return
            n = maxops.delete_effects([r.effect[0] for r in rows])
            log('Removed %d render effect(s)' % n)
            self.result.effects = maxops.effects()
            done('Removed %d effect(s)' % n)

    def _search_dirs(self):
        dirs = [p for p, on in self._user_dirs() if on]
        if self.dirs.item(0).checkState() == Qt.Checked and maxops.rt.maxFilePath:
            dirs.insert(0, str(maxops.rt.maxFilePath))
        return dirs

    def _shown_items(self):
        p = self.proxy
        return [self.model.rows[p.mapToSource(p.index(i, 0)).row()] for i in range(p.rowCount())]

    def _start_ops(self):
        """START: run the ticked operations on the selected rows (or all shown if none selected)."""
        if self.busy or self.result is None:
            return
        order = [k for k, cb in (('search', self.op_search), ('relocate', self.op_relocate),
                                 ('collect', self.op_collect)) if cb.isChecked()]
        if not order:
            QtWidgets.QMessageBox.information(self, 'START', 'Tick at least one operation above START.')
            return
        selected_only = self.op_scope.currentIndex() == 1
        sel = self.selected_items() if selected_only else []
        items = sel if selected_only else self._shown_items()
        if not items:
            QtWidgets.QMessageBox.information(self, 'START', 'Nothing to process - no rows selected or shown.')
            return
        if 'collect' in order:
            folder = self.maps_folder()
            if not folder or not os.path.isabs(folder):
                QtWidgets.QMessageBox.warning(self, 'Collect', 'Choose an absolute maps folder first.')
                return
            scope = self.op_scope.currentText()
            if QtWidgets.QMessageBox.question(self, 'Collect and verify',
                    f'{scope} ({len(items)} files)\n\nCollect into {folder} and verify absolute scene links?') == QtWidgets.QMessageBox.Yes:
                self._collect_verified(items, folder, 'search' in order)
            return
        n_miss = len([i for i in items if i.status == 'missing'])
        n_found = len([i for i in items if i.status == 'found' and i.resolved])
        n_coll = len([i for i in items if i.status in ('ok', 'found') and i.resolved])
        lines = ['Run on %d file(s)%s:' % (len(items), ' (selected)' if sel else ' (all shown rows)'), '']
        for k in order:
            if k == 'search':
                lines.append('  Search & Relink:  %d missing file(s)' % n_miss)
            elif k == 'relocate':
                lines.append('  Relocate Links:   %d found file(s) -> absolute' % n_found)
            elif k == 'collect':
                lines.append('  Collect:          %d file(s) -> %s' % (n_coll, self.maps_folder() or '(no maps folder)'))
        lines += ['', 'Original files are not changed. Ctrl+Z undoes each step.']
        if QtWidgets.QMessageBox.question(self, 'START', '\n'.join(lines)) != QtWidgets.QMessageBox.Yes:
            return
        log('START: ' + ', '.join(order) + ' on %d file(s)' % len(items))

        def step(i):
            if i >= len(order):
                log('START finished')
                self.status.setText('START finished  -  %s' % time.strftime('%H:%M:%S'))
                return
            k = order[i]

            def done(msg):
                self.after_change(msg)
                step(i + 1)

            if k == 'search':
                t = [x for x in items if x.status == 'missing']
                if t:
                    self._search_missing(t, False, done)
                else:
                    done('Search & relink: nothing missing')
            elif k == 'relocate':
                pairs = [(x, x.resolved) for x in items if x.status == 'found' and x.resolved]
                if pairs:
                    with maxops.undo('NSC Relocate links'):
                        n = ops.relink(pairs, log)
                    log('Relocated %d of %d link(s) to absolute paths' % (n, len(pairs)))
                    done('Relocated %d link(s)' % n)
                else:
                    done('Relocate links: nothing to do')
            elif k == 'collect':
                t = [x for x in items if x.status in ('ok', 'found') and x.resolved]
                if t:
                    self._copy_to_maps(t, False, False, done)
                else:
                    done('Collect: nothing to copy')
        step(0)

    def _collect_verified(self, items, folder, search):
        from . import collection
        self.bar.setFormat('Overall collection  %p%')
        self._collection_progress(None, 'Resolving scene maps')
        records = {it.path: it for it in items}
        key = scanmod.norm_key
        scene = maxops.scene_file()
        roots = self._search_dirs() if search else []
        paths = [(it.path, it.max_resolved) for it in items]
        def finish(job):
            if job.cancel:
                self.after_change('Collection cancelled before relinking')
                return
            targets, errors = job.result
            stats = job.collection_stats
            updating = time.perf_counter()
            read_seconds = 0.
            self.job = job
            self.cancel_btn.setText('Cancel')
            def steps():
                def tracker():
                    nonlocal read_seconds
                    start = time.perf_counter()
                    paths = {key(path) for path in maxops.ats_files()}
                    read_seconds += time.perf_counter() - start
                    return paths
                yield 0.45, None, 'Reading scene links'
                owners = {old:list(records[old].refs or records[old].inspection_refs) for old in targets}
                pairs = [(old, target) for old, target in targets.items() if key(old) != key(target)]
                bulk = [old for old, target in pairs
                        if key(os.path.dirname(target)) == key(folder)
                        and key(os.path.basename(old)) == key(os.path.basename(target))]
                ats = maxops.rt.ATSOps
                for start in range(0, len(bulk), 32):
                    group = bulk[start:start + 32]
                    yield 0.45 + 0.27 * start / len(bulk), start / len(bulk), f'Updating folder for entries {start + 1}-{start + len(group)}/{len(bulk)}'
                    try:
                        with maxops.undo('NSC Update collected asset folder'):
                            ats.ClearSelection()
                            ats.SelectFiles(maxops.rt.Array(*group), useResolvedFileNames=False)
                            if ats.NumFilesSelected():
                                ats.SetPathOnSelection(folder)
                    except RuntimeError as exc:
                        log(f'Batch folder update: {exc}')
                    finally:
                        ats.ClearSelection()
                yield 0.73, None, 'Checking stored scene paths'
                current = tracker()
                # Some plug-ins expose writable slots that Asset Tracking cannot retarget.
                direct = [(old, target) for old, target in pairs if owners[old] and
                          (key(old) in current or any(key(maxops.get_map_path(o, p)) == key(old)
                                                      for o, p in owners[old]))]
                for start in range(0, len(direct), 8):
                    group = direct[start:start + 8]
                    yield 0.74, start / len(direct), f'Updating remaining texture slots {start + 1}-{start + len(group)}/{len(direct)}'
                    with maxops.undo('NSC Collect links'):
                        for old, target in group:
                            for owner, prop in owners[old]:
                                if key(maxops.get_map_path(owner, prop)) == key(old):
                                    maxops.set_map_path(owner, prop, target)
                if direct:
                    current = tracker()
                remaining = [(old, target) for old, target in pairs if key(old) in current]
                for start in range(0, len(remaining), 8):
                    group = remaining[start:start + 8]
                    yield 0.75, start / len(remaining), f'Relinking remaining Asset Tracker entries {start + 1}-{start + len(group)}/{len(remaining)}'
                    with maxops.undo('NSC Collect Asset Tracker links'):
                        maxops.retarget([old for old, _ in group], [target for _, target in group], refresh=False)
                if remaining:
                    current = tracker()
                pending = {key(old):old for old,target in targets.items()
                           if key(old) in current and key(old) != key(target) or (key(target) not in current and not owners[old])}
                if pending:
                    maxops._ensure()
                    classes = list(maxops.rt.textureMap.classes)
                    wanted = maxops.rt.Array(*(old.lower().replace("/", chr(92)) for old in pending.values()))
                    for i,cls in enumerate(classes,1):
                        yield 0.75 + 0.10 * (i-1)/len(classes), (i-1)/len(classes), f'Checking unresolved map owners | {i}/{len(classes)}'
                        objs,props,values,_ = maxops.rt.NSC_ScanMaps(classes=maxops.rt.Array(cls), wanted=wanted)
                        with maxops.undo('NSC Collect remaining links'):
                            for obj,prop,value in zip(objs,props,values):
                                old = pending.get(key(str(value)))
                                if old:
                                    owners[old].append((obj,str(prop)))
                                    maxops.set_map_path(obj,str(prop),targets[old])
                    yield 0.85, None, 'Verifying Asset Tracker links'
                    current = tracker()
                update_seconds = time.perf_counter() - updating - read_seconds
                verification = time.perf_counter()
                candidates = []
                to_verify = []
                for old, target in targets.items():
                    if key(old) == key(target) and key(target) in current:
                        candidates.append((old, target))
                    else:
                        to_verify.append((old, target))
                for i, (old,target) in enumerate(to_verify):
                    if i % 32 == 0:
                        yield 0.85 + 0.10 * i / len(to_verify), i / len(to_verify), f'Verifying scene links {i+1}/{len(to_verify)} | {os.path.basename(old)}'
                    refs = owners[old]
                    owners_ok = all(key(maxops.get_map_path(o,p) or '') == key(target) for o,p in refs)
                    stale = key(old) != key(target) and key(old) in current
                    if owners_ok and not stale and (key(target) in current or refs):
                        candidates.append((old,target))
                    else:
                        errors[old] = 'Scene link could not be verified'
                def verify_files(worker):
                    verified = {}
                    if worker.cancel:
                        return verified
                    try:
                        listing = collection.inventory(folder, cancelled=lambda: worker.cancel)
                    except collection.Cancelled:
                        return verified
                    for i, (old,target) in enumerate(candidates):
                        worker.frac = i / len(candidates)
                        if worker.cancel:
                            break
                        worker.text = 'Verifying collected file | ' + target
                        try:
                            verified[old] = listing[os.path.basename(target).casefold()][1]
                        except (OSError, KeyError) as exc:
                            errors[old] = str(exc)
                    return verified
                def report(worker):
                    for old,size in worker.result.items():
                        it = records[old]
                        it.path = it.resolved = targets[old]
                        it.inspection_refs = owners[old]
                        it.size, it.relative, it.status = size, False, 'ok'
                    for old,reason in errors.items():
                        log(f'{old} | {reason}')
                    verified = len(worker.result)
                    message = f'{verified}/{len(items)} verified in maps folder'
                    correct = sum(key(old) == key(targets[old]) for old in worker.result)
                    message += (f" | Already correct {correct} | Path updates {verified - correct}"
                                f" | Files copied {stats['files']} | Need attention {len(errors)}")
                    log(f"Seconds: list {stats['listing']:.2f}, resolve/search {stats['search']:.2f}, "
                        f"copy {stats['copying']:.2f}, read Max links {read_seconds:.2f}, "
                        f"update Max {update_seconds:.2f}, verify {time.perf_counter() - verification:.2f}")
                    if worker.cancel:
                        message += ' (cancelled)'
                    if errors:
                        message += f' | {len(errors)} need attention (see Log)'
                    log(message)
                    self.after_change(message)
                self.start_job('Verifying collected files...', verify_files, (), report, progress_range=(0.95, 1.0))
            work = steps()
            def tick():
                try:
                    if job.cancel or maxops.scene_file() != scene:
                        self.job = None
                        self.after_change('Stopped. Previously applied links were kept. Rescan to refresh.')
                        return
                    fraction, step, message = next(work)
                    self._collection_progress(step, message)
                    self.progress(fraction, message, pump=False)
                    QtCore.QTimer.singleShot(1, tick)
                except StopIteration:
                    pass
                except Exception as exc:
                    self.job = None
                    log(str(exc))
                    self.after_change('Collection failed. See Log.')
            tick()
        self.start_job('Resolving scene maps...', collection.prepare,
                       (paths, folder, roots, self.col_recursive.isChecked(), self._exclude_patterns(), [it.path for it in self.result.items]), finish, progress_range=(0.0, 0.45), indeterminate=True)

    def _search_missing(self, items, ask, done):
        dirs = self._search_dirs()
        if not dirs:
            if ask:
                QtWidgets.QMessageBox.warning(self, 'Search', 'Tick the scene folder or add a search folder '
                                                              '(Assets page, panel below the list).')
            else:
                log('  Search skipped: no search folders')
            return done('Search skipped')
        wanted = {i.name.lower() for i in items}
        log('Searching %d folder(s) for %d missing file(s)' % (len(dirs), len(items)))

        def finish(job):
            found = job.result or {}
            pairs = [(i, found[i.name.lower()]) for i in items if i.name.lower() in found]
            with maxops.undo('NSC Search & relink'):
                n = ops.relink(pairs, log) if pairs else 0
            for i, p in pairs:
                log('  Found %s  ->  %s' % (i.name, p))
            log('  Search: relinked %d,  %d still missing' % (n, len(items) - n))
            done('Found %d of %d missing' % (n, len(items)))
        self.start_job('Searching for missing files...', ops.index_folders,
                       (dirs, self.col_recursive.isChecked(), wanted, self._exclude_patterns()), finish)

    def _convert_items(self, items, done):
        verified = []
        for it in items:
            refs = it.refs or it.inspection_refs
            if refs and all(scanmod.norm_key(maxops.get_map_path(owner, prop)) == it.key
                            for owner, prop in refs):
                it.refs = list(refs)
                verified.append(it)
            else:
                log(f'Conversion skipped. No current audited links for {it.path}')
        if not verified:
            return done('No selected textures have current links. Rescan if the scene changed.')
        self._copy_to_maps(verified, True, False, done)

    def _copy_to_maps(self, items, convert, ask, done):
        maps = self.maps_folder()
        if not maps:
            if ask:
                QtWidgets.QMessageBox.warning(self, 'Maps folder', 'Save the scene first, or set the maps folder '
                                                                   '(Assets page, panel below the list).')
            else:
                log('  Skipped: no maps folder set')
            return done('No maps folder - skipped')
        what = 'Convert' if convert else 'Collect'
        if ask:
            q = ('Convert %d texture(s) to uncompressed PNG in\n%s\nand relink the scene?' if convert else
                 'Copy %d file(s) into\n%s\nand relink the scene?') % (len(items), maps)
            if QtWidgets.QMessageBox.question(self, what, q + '\n\nThe original files are not changed.') \
                    != QtWidgets.QMessageBox.Yes:
                return
        scene = maxops.scene_file()
        conv = ops.converter()
        exts = scanmod.CONVERT_EXTS if convert else set()
        log('%s: %d file(s) -> %s' % (what, len(items), maps))

        def finish(job):
            copied = job.result
            if job.cancel or copied is None:
                return done('Cancelled')
            if convert and scene != maxops.scene_file():
                return done('Scene changed. Texture links were not updated.')
            pairs = []
            for it, target, need_max in copied:
                if convert and not target.lower().endswith('.png'):
                    continue
                if need_max and not maxops.max_to_png(it.resolved, target):
                    log('  PNG conversion failed: ' + it.resolved)
                    continue
                pairs.append((it, target))
            with maxops.undo('NSC ' + what):
                n = ops.relink_converted(pairs, log) if convert else ops.relink(pairs, log)
            log('  %s: %d file(s) now linked from the maps folder' % (what, n))
            done('%s: %d file(s) in maps' % (what, n))
        self.start_job(('Converting' if convert else 'Collecting') + ' into maps...', ops.archive_copy,
                       (items, maps, conv, exts), finish)

    def _prepare(self):
        if self.result is not None and self.result.mode == 'quick':
            QtWidgets.QMessageBox.information(self, 'Full scan required', 'Run Full scan before Prepare for render; Quick audit does not classify map usage.')
            return
        if self.busy or self.result is None:
            return
        # Use tab order for Prepare: Effects, Convert, Relink, Missing, Collect
        prepare_order = ['Effects', 'Convert', 'Relink', 'Missing', 'Collect']
        counts = [(cat, text, len(self._aud_rows(cat, ticked=False))) for cat, text, _ in CATS]
        # Reorder to match prepare_order
        cat_to_text = {cat: text for cat, text, _ in CATS}
        todo = [(cat, cat_to_text[cat], len(self._aud_rows(cat, ticked=False))) for cat in prepare_order if cat in cat_to_text]
        todo = [(cat, text, n) for cat, text, n in todo if n]
        if not todo:
            QtWidgets.QMessageBox.information(self, 'Prepare for render', 'Nothing to fix - the scene is ready.')
            return
        q = 'Run these fixes, in this order?\n\n' + '\n'.join('  %s:  %d' % (t, n) for _, t, n in todo)
        q += '\n\nMaps folder:  %s\nOriginal files are not changed. Ctrl+Z undoes each step.' % (self.maps_folder() or '-')
        if QtWidgets.QMessageBox.question(self, 'Prepare for render', q) != QtWidgets.QMessageBox.Yes:
            return
        order = [cat for cat, _, _ in todo]
        log('Prepare for render: ' + ', '.join(order))

        def step(i):
            if i >= len(order):
                return self._prepare_done()
            self._aud_fix(order[i], self._aud_rows(order[i], ticked=False), then=lambda: step(i + 1))
        step(0)

    def _prepare_done(self):
        cat_to_text = {cat: text for cat, text, _ in CATS}
        left = [(cat_to_text[cat], len(self._aud_rows(cat, ticked=False))) for cat in ['Effects', 'Convert', 'Relink', 'Missing', 'Collect'] if cat in cat_to_text]
        left = [(t, n) for t, n in left if n]
        msg = 'Scene is ready for rendering.' if not left else \
            'Still to check:\n' + '\n'.join('  %s:  %d' % x for x in left)
        log('Prepare for render finished. ' + msg.replace('\n', ' '))
        QtWidgets.QMessageBox.information(self, 'Prepare for render', msg + '\n\nSave the scene to keep the new paths.')

    # ---- Assets page (viewer) --------------------------------------------------------------
    def _page_assets(self):
        w = QtWidgets.QWidget()
        outer = QtWidgets.QVBoxLayout(w)
        outer.setContentsMargins(0, 8, 0, 0)
        split = QtWidgets.QSplitter(Qt.Vertical)
        split.setChildrenCollapsible(False)
        outer.addWidget(split, 1)
        top = QtWidgets.QWidget()
        h = QtWidgets.QHBoxLayout(top)
        h.setContentsMargins(0, 0, 0, 0)
        split.addWidget(top)
        left = QtWidgets.QVBoxLayout()
        self.search = QtWidgets.QLineEdit()
        self.search.setPlaceholderText('Search name or folder...')
        self.search.textChanged.connect(lambda *_: self._as_refilter())
        left.addWidget(self.search)
        self.model = AssetModel(self)
        self.proxy = Proxy(self)
        tv = make_table(self.model, self.proxy)
        tv.horizontalHeader().setSectionResizeMode(1, QtWidgets.QHeaderView.Stretch)
        for c, wd in ((0, 240), (2, 80), (3, 75), (4, 65), (5, 45), (6, 120)):
            tv.setColumnWidth(c, wd)
        _QShortcut = getattr(QtWidgets, 'QShortcut', None) or QtGui.QShortcut  # Qt6: QtGui, Qt5: QtWidgets
        sc = _QShortcut(QtGui.QKeySequence('Ctrl+A'), tv)
        sc.setContext(Qt.WidgetWithChildrenShortcut)
        sc.activated.connect(tv.selectAll)
        self._bind_texture_menu(tv, self._menu)
        tv.doubleClicked.connect(lambda *_: self._explore())
        self.table = tv
        left.addWidget(tv, 1)
        self.meta = label('', 'muted')
        left.addWidget(self.meta)
        h.addLayout(left, 1)

        panel = card()
        panel.setFixedWidth(240)
        pl = QtWidgets.QVBoxLayout(panel)
        pl.setContentsMargins(14, 12, 14, 12)
        rb = button('Rescan', self.run_scan)
        self.action_buttons.append(rb)
        pl.addWidget(rb)
        pl.addWidget(button('Export report...', self._export_report,
                            tip='Save the current scan as JSON or CSV (the file extension decides)'))
        pl.addSpacing(6)
        pl.addWidget(label('STATUS', 'section'))
        self.status_checks = {}
        for key in ('ok', 'found', 'missing'):
            cb = QtWidgets.QCheckBox(STATUS_TEXT[key])
            cb.setChecked(True)
            cb.toggled.connect(lambda *_: self._as_refilter())
            self.status_checks[key] = cb
            pl.addWidget(cb)
        self.show_unused = QtWidgets.QCheckBox('Show unused assets')
        self.show_unused.setToolTip('Maps only in the Material Editor or not assigned to anything.\n'
                                    'They are never converted, collected or archived.')
        self.show_unused.toggled.connect(lambda *_: self._as_refilter())
        pl.addWidget(self.show_unused)
        pl.addSpacing(6)
        eh = QtWidgets.QHBoxLayout()
        eh.addWidget(label('EXT', 'section'), 1)
        for txt, val in (('All', True), ('None', False)):
            b = button(txt, lambda v=val: self._ext_all(v))
            b.setFixedWidth(52)
            b.setStyleSheet('padding: 4px 2px;')
            eh.addWidget(b)
        pl.addLayout(eh)
        self.ext_list = QtWidgets.QListWidget()
        self.ext_list.itemChanged.connect(lambda *_: self._as_refilter())
        pl.addWidget(self.ext_list, 1)
        pl.addSpacing(6)
        pl.addWidget(label('EXCLUDE  (skipped in scan and search)', 'section'))
        exb = QtWidgets.QHBoxLayout()
        exb.addWidget(button('+', self._add_exclude, tip='Add a glob pattern, e.g.  *.tmp   or   thumbs.db   or   .svn'))
        exb.addWidget(button('-', self._remove_exclude, tip='Remove the selected pattern'))
        pl.addLayout(exb)
        self.exclude_list = QtWidgets.QListWidget()
        self.exclude_list.setMaximumHeight(64)
        self.exclude_list.itemChanged.connect(lambda *_: self._save_exclude())
        pl.addWidget(self.exclude_list)
        self._load_exclude()
        h.addWidget(panel)
        # Maps folder / operations / search folders (below the list, draggable splitter)
        split.addWidget(self._folders_panel())
        split.setStretchFactor(0, 1)
        split.setStretchFactor(1, 0)
        return w

    def _export_report(self):
        if self.result is None:
            QtWidgets.QMessageBox.information(self, 'Export', 'Run a scan first.')
            return
        p, _flt = QtWidgets.QFileDialog.getSaveFileName(
            self, 'Export scan report', 'nsc_report.json', 'JSON (*.json);;CSV (*.csv)')
        if not p:
            return
        try:
            if p.lower().endswith('.csv'):
                scanmod.write_csv(p, self.result)
            else:
                import json
                with open(p, 'w', encoding='utf-8') as f:
                    json.dump(scanmod.report_dict(self.result), f, indent=2)
            log('Exported report: ' + p)
        except OSError as e:
            QtWidgets.QMessageBox.warning(self, 'Export', 'Could not write:\n%s\n\n%s' % (p, e))

    # ---- search folders (same INI keys as the MAXScript version) ---------------------------
    def _load_dirs(self):
        self.dirs.blockSignals(True)
        self.dirs.clear()
        scene_dir = str(maxops.rt.maxFilePath)
        li = QtWidgets.QListWidgetItem('Scene folder:  ' + (scene_dir or '(scene not saved yet)'))
        li.setFlags(li.flags() | Qt.ItemIsUserCheckable)
        li.setCheckState(Qt.Unchecked if maxops.ini_get('Assets', 'sceneDirOn') == 'false' else Qt.Checked)
        li.setForeground(QtGui.QBrush(QtGui.QColor(MUTED)))
        li.setToolTip('Always searched first while ticked - follows the open scene, cannot be removed')
        self.dirs.addItem(li)
        raw = maxops.ini_get('Assets', 'dirs')
        off = set(maxops.ini_get('Assets', 'dirsOff').split('|'))
        for d in [x for x in raw.split('|') if x]:
            li = QtWidgets.QListWidgetItem(d)
            li.setFlags(li.flags() | Qt.ItemIsUserCheckable)
            li.setCheckState(Qt.Unchecked if d in off else Qt.Checked)
            li.setToolTip(d)
            self.dirs.addItem(li)
        self.dirs.blockSignals(False)

    def _user_dirs(self):
        return [(self.dirs.item(i).text(), self.dirs.item(i).checkState() == Qt.Checked)
                for i in range(1, self.dirs.count())]

    def _save_dirs(self):
        d = self._user_dirs()
        maxops.ini_set('Assets', 'dirs', '|'.join(p for p, _ in d))
        maxops.ini_set('Assets', 'dirsOff', '|'.join(p for p, on in d if not on))
        maxops.ini_set('Assets', 'sceneDirOn', 'true' if self.dirs.item(0).checkState() == Qt.Checked else 'false')

    def _add_dir(self):
        p = QtWidgets.QFileDialog.getExistingDirectory(self, 'Add a folder to search for missing files')
        if not p:
            return
        p = os.path.normpath(p)
        if p in [x for x, _ in self._user_dirs()]:
            return
        li = QtWidgets.QListWidgetItem(p)
        li.setFlags(li.flags() | Qt.ItemIsUserCheckable)
        li.setCheckState(Qt.Checked)
        li.setToolTip(p)
        self.dirs.addItem(li)
        self._save_dirs()

    def _remove_dir(self):
        row = self.dirs.currentRow()
        if row == 0:
            QtWidgets.QMessageBox.information(self, 'Search folders', 'The scene folder is always listed. Untick it to skip it.')
        elif row > 0:
            self.dirs.takeItem(row)
            self._save_dirs()

    def _edit_dir(self, li):
        if self.dirs.row(li) == 0:
            return
        p = QtWidgets.QFileDialog.getExistingDirectory(self, 'Change search folder', li.text())
        if p:
            li.setText(os.path.normpath(p))
            li.setToolTip(li.text())
            self._save_dirs()

    # ---- maps folder ------------------------------------------------------------------------
    def maps_folder(self):
        return os.path.normpath(self.maps_edit.text().strip()) if self.maps_edit.text().strip() else ''

    def _browse_maps(self):
        p = QtWidgets.QFileDialog.getExistingDirectory(self, 'Maps folder', self.maps_edit.text())
        if p:
            self.maps_edit.setText(os.path.normpath(p))
            self._maps_edited()

    def _maps_edited(self):
        d = str(maxops.rt.maxFilePath)
        self._maps_auto = not d or self.maps_folder() == os.path.normpath(os.path.join(d, 'maps'))
        if self.result is not None and not self.busy:
            import threading
            self._scan_cancel = threading.Event()
            self._scan_started = time.perf_counter()
            self.set_busy(True)
            try:
                scanmod.check_files(self.result.items, scanmod.all_roots(), self._exclude_patterns(),
                                    self.progress, self._scan_cancel.is_set, self.maps_folder(), deep=False, search_dirs=self._search_dirs(), recursive=self.col_recursive.isChecked())
                self.show_result(self.result, keep_ticks=True)
                self.status.setText('Destination folder checked.')
            except scanmod.ScanCancelled:
                self.status.setText('Destination check cancelled.')
            except OSError as exc:
                log(f'Destination check failed: {exc}')
                self.status.setText('Could not check destination folder. See Log.')
            finally:
                self._scan_cancel = None
                self.set_busy(False)

    def _scene_defaults(self):
        """A different scene is open: follow it (maps folder, archive name, scene search folder)."""
        scene = maxops.scene_file()
        if scene == self._scene_seen:
            return
        self._scene_seen = scene
        d = str(maxops.rt.maxFilePath)
        if self._maps_auto:
            self.maps_edit.setText(os.path.normpath(os.path.join(d, 'maps')) if d else '')
        self._arc_defaults()
        self._load_dirs()

    # ---- Archive page ----------------------------------------------------------------------
    def _page_archive(self):
        w = QtWidgets.QWidget()
        v = QtWidgets.QVBoxLayout(w)
        v.setContentsMargins(0, 8, 0, 0)
        c = card()
        g = QtWidgets.QGridLayout(c)
        g.setContentsMargins(16, 12, 16, 16)
        g.setHorizontalSpacing(12)
        g.setVerticalSpacing(8)
        g.addWidget(label('ARCHIVE PROJECT', 'section'), 0, 0, 1, 3)
        g.addWidget(label('Makes a zip with a copy of the scene and every linked file in a "maps" folder, with '
                          'relative paths so it opens on any PC.\nThe open scene and the original files are not '
                          'changed.', 'muted'), 1, 0, 1, 3)
        g.addWidget(label('Archive folder', 'muted'), 2, 0)
        self.arc_folder = QtWidgets.QLineEdit()
        g.addWidget(self.arc_folder, 2, 1)
        g.addWidget(button('...', self._arc_browse, tip='Choose where the zip is written'), 2, 2)
        g.addWidget(label('Name', 'muted'), 3, 0)
        self.arc_name = QtWidgets.QLineEdit()
        g.addWidget(self.arc_name, 3, 1)
        self.arc_convert = QtWidgets.QCheckBox('Convert TX / TIF / TIFF to PNG inside the archive (originals untouched)')
        self.arc_xrefs = QtWidgets.QCheckBox('Include XRef scenes (.max)')
        self.arc_keep = QtWidgets.QCheckBox('Keep the unzipped folder')
        self.arc_folder.editingFinished.connect(self._arc_edited)
        for i, (cb, key, dflt) in enumerate(((self.arc_convert, 'convert', 'false'), (self.arc_xrefs, 'xrefs', 'true'),
                                             (self.arc_keep, 'keep', 'false'))):
            val = maxops.ini_get('Archive', key) or dflt
            cb.setChecked(val == 'true')
            cb.toggled.connect(lambda on, k=key: (maxops.ini_set('Archive', k, 'true' if on else 'false'),
                                                  self._arc_summary()))
            g.addWidget(cb, 4 + i, 1)
        self.arc_info = label('', 'muted')
        self.arc_info.setWordWrap(True)
        g.addWidget(self.arc_info, 7, 1)
        self.arc_btn = button('Create archive', self._archive, accent=True)
        self.arc_btn.setMinimumHeight(36)
        self.arc_btn.setMinimumWidth(180)
        self.action_buttons.append(self.arc_btn)
        g.addWidget(self.arc_btn, 8, 1, Qt.AlignLeft)
        g.setColumnStretch(1, 1)
        v.addWidget(c)
        v.addStretch(1)
        self._arc_auto = True   # follow the scene until the user picks a folder by hand
        self._arc_defaults()
        return w

    def _arc_defaults(self):
        d = str(maxops.rt.maxFilePath)
        if self._arc_auto:
            saved = maxops.ini_get('Archive', 'folder')
            self.arc_folder.setText(saved if saved and not d else (os.path.join(d, 'archives') if d else ''))
        self.arc_name.setText(os.path.splitext(str(maxops.rt.maxFileName))[0])

    def _arc_edited(self):
        self._arc_auto = False
        maxops.ini_set('Archive', 'folder', self.arc_folder.text().strip().rstrip('\\\\/'))

    def _arc_browse(self):
        p = QtWidgets.QFileDialog.getExistingDirectory(self, 'Archive folder', self.arc_folder.text())
        if p:
            self._arc_auto = False
            p = os.path.normpath(p)
            self.arc_folder.setText(p)
            maxops.ini_set('Archive', 'folder', p)

    def _arc_items(self):
        if self.result is None:
            return [], []
        items = [i for i in self.result.items if i.used and (self.arc_xrefs.isChecked() or i.kind != 'XRefs')]
        return [i for i in items if i.resolved], [i for i in items if not i.resolved]

    def _arc_summary(self):
        if not hasattr(self, 'arc_info'):
            return
        if self.result is None:
            self.arc_info.setText('Run a scan first.')
            return
        good, missing = self._arc_items()
        conv = len([i for i in good if i.ext in scanmod.CONVERT_EXTS]) if self.arc_convert.isChecked() else 0
        t = '%d file(s), %s will be archived.' % (len(good), fmt_size(sum(i.size for i in good)))
        if conv:
            t += '  %d converted to PNG.' % conv
        if missing:
            t += '  %d missing file(s) cannot be included (see Assets).' % len(missing)
        self.arc_info.setText(t)

    def _archive(self):
        if self.busy:
            return
        if not maxops.rt.maxFileName:
            QtWidgets.QMessageBox.warning(self, 'Archive', 'Save the scene first.')
            return
        if self.result is None:
            self.run_scan()
            if self.result is None:
                return
        self.result.recheck()
        self._arc_summary()
        folder = self.arc_folder.text().strip().rstrip('\\/')
        name = self.arc_name.text().strip()
        if not folder or not name or any(ch in name for ch in '\\/:*?"<>|'):
            QtWidgets.QMessageBox.warning(self, 'Archive', 'Enter an archive folder and a valid name.')
            return
        work = os.path.join(folder, name)
        zip_path = work + '.zip'
        good, missing = self._arc_items()
        q = 'Archive %d file(s) (%s) to\n%s ?' % (len(good), fmt_size(sum(i.size for i in good)), zip_path)
        if missing:
            q += '\n\n%d missing file(s) will not be included.' % len(missing)
        if os.path.isfile(zip_path):
            q += '\n\nThis zip already exists and will be REPLACED.'
        if QtWidgets.QMessageBox.question(self, 'Archive', q) != QtWidgets.QMessageBox.Yes:
            return
        if os.path.isdir(work):
            if QtWidgets.QMessageBox.question(self, 'Archive', 'The folder\n%s\nalready exists. Delete it and '
                                              'build the archive there?' % work) != QtWidgets.QMessageBox.Yes:
                return
            shutil.rmtree(work, ignore_errors=True)
        maxops.ini_set('Archive', 'folder', folder)
        keep = self.arc_keep.isChecked()
        conv = ops.converter()
        exts = scanmod.CONVERT_EXTS if self.arc_convert.isChecked() else set()
        maps_dir = os.path.join(work, 'maps')
        scene_name = str(maxops.rt.maxFileName)
        log('Archive: %d file(s) -> %s' % (len(good), zip_path))
        for i in missing:
            log('  Missing, not archived: ' + i.path)

        def finish_copy(job):
            copied = job.result
            if copied is None:
                shutil.rmtree(work, ignore_errors=True)
                self.after_change('Archive cancelled')
                return
            pairs = []
            for it, target, need_max in copied:
                if need_max and not maxops.max_to_png(it.resolved, target):
                    log('  PNG conversion failed, archived the original: ' + it.resolved)
                    target = ops.unique_target(maps_dir, os.path.basename(it.resolved), it.resolved)
                    ops.copy_asset(it.resolved, target)
                pairs.append((it, 'maps\\' + os.path.basename(target)))
            # point the scene at the archive copies, save a copy, then put everything back exactly
            snap = [(it, it.path, it.resolved, it.ext, it.status, it.size, it.relative) for it in self.result.items]
            dirty = maxops.save_required()
            undo_log = []
            saved = False
            try:
                with maxops.no_undo():
                    ops.relink(pairs, log, undo_log)
                    saved = maxops.save_copy(os.path.join(work, scene_name))
            finally:
                with maxops.no_undo():
                    ops.undo_relink(undo_log)
                for it, p, res, ext, st, size, rel in snap:
                    it.path, it.resolved, it.ext, it.status, it.size, it.relative = p, res, ext, st, size, rel
                maxops.set_save_required(dirty)
            if not saved:
                log('  Could not save the scene copy - archive stopped')
                self.after_change('Archive failed - see Log')
                return
            log('  Scene copy saved with %d relative path(s)' % len(pairs))

            def finish_zip(job2):
                if job2.result is None:
                    self.after_change('Archive cancelled')
                    return
                log('Archive done: %s  (%s)' % (zip_path, fmt_size(os.path.getsize(zip_path))))
                self.after_change('Archive created')
                QtWidgets.QMessageBox.information(self, 'Archive', 'Archive created:\n%s\n\n%d file(s) + scene%s' % (
                    zip_path, len(pairs), '\n%d missing file(s) not included' % len(missing) if missing else ''))
            self.start_job('Zipping...', ops.zip_folder, (work, zip_path, keep), finish_zip)

        self.start_job('Archive: copying files...', ops.archive_copy, (good, maps_dir, conv, exts), finish_copy)

    # ---- background jobs ------------------------------------------------------------------
    def start_job(self, text, fn, args, finish, *, progress_range=(0.0, 1.0), indeterminate=False):
        """Run fn(job, *args) in a thread; finish(job) then runs here, on Max's main thread."""
        self.set_busy(True)
        low, high = progress_range
        collecting = not self.step_bar.isHidden()
        if collecting:
            self._collection_progress(None, text)
        self.progress(None if indeterminate and not collecting else low, text)
        job = ops.Job()
        if indeterminate:
            job.frac = None
        self.job = job
        ops.run_thread(job, fn, *args)
        timer = QtCore.QTimer(self)

        def tick():
            while job.messages:
                log(job.messages.pop(0))
            if not job.cancel:
                fraction = job.frac
                if collecting:
                    self._collection_progress(fraction, job.text or text)
                self.progress((low if collecting else None) if fraction is None else low + (high-low)*fraction,
                              job.text or text, pump=False)
            if job.done:
                timer.stop()
                timer.deleteLater()
                self.job = None
                if job.error is not None:
                    log('Error: %s' % job.error)
                    self.set_busy(False)
                    self.status.setText('Failed - see Log')
                    return
                try:
                    finish(job)
                except Exception as e:
                    log('Error: %s' % e)
                    self.set_busy(False)
        timer.timeout.connect(tick)
        timer.start(100)

    def cancel(self):
        if self._scan_cancel is not None:
            log('Scan cancel requested: ' + self.status.text())
            self._scan_cancel.set()
            self.cancel_btn.setEnabled(False)
            self.status.setText('Cancelling scan... waiting for current native Max call if necessary')
            return
        if self.job is not None:
            self.job.cancel = True
            self.status.setText('Cancelling...')

    def set_busy(self, busy):
        self.busy = busy
        for b in self.action_buttons:
            b.setEnabled(not busy)
        self.cancel_btn.setVisible(busy)
        if not busy:
            self.cancel_btn.setText('Cancel')
            self.cancel_btn.setEnabled(True)
        if not busy:
            self.bar.setVisible(False)
            self.bar.setFormat('%p%')
            self.step_bar.hide()
            self._aud_counts()

    def after_change(self, msg):
        """Data was changed in place (no rescan): refresh both lists."""
        self.show_result(self.result, keep_ticks=True)
        self.set_busy(False)
        self.status.setText('%s  -  %s' % (msg, time.strftime('%H:%M:%S')))

    # ---- scan ----------------------------------------------------------------------------
    def _collection_progress(self, fraction, message):
        stage = message.split(' | ', 1)[0]
        if stage.startswith('Searching '):
            stage = 'Searching folders'
        self.step_bar.setRange(0, 0 if fraction is None else 1000)
        if fraction is not None:
            self.step_bar.setValue(round(1000 * fraction))
        self.step_bar.setFormat(stage)
        self.step_bar.setToolTip(message)
        self.step_bar.show()

    def progress(self, frac, text, pump=True):
        self.bar.setVisible(True)
        self.bar.setRange(0, 0 if frac is None else 1000)
        if frac is not None:
            self.bar.setValue(int(frac * 1000))
        if self._scan_cancel is not None:
            self.status.setText('%d%%  |  %s  |  %.1fs elapsed' % (int(frac * 100), text, time.perf_counter() - self._scan_started))
            self.status.setToolTip(text)
        else:
            self.status.setText(text)
        if pump:
            QtWidgets.QApplication.processEvents(QtCore.QEventLoop.AllEvents if self._scan_cancel is not None else QtCore.QEventLoop.ExcludeUserInputEvents)

    def run_scan(self, quick=False, keep_ticks=False, deep=True):
        if self.busy:
            return
        self._scene_defaults()
        import threading
        self._scan_cancel = threading.Event()
        self._scan_started = time.perf_counter()
        self.cancel_btn.setText('Cancel scan')
        self.cancel_btn.setEnabled(True)
        self.set_busy(True)
        self.progress(0.0, 'Scanning input assets...')
        try:
            r = scanmod.scan(self.progress, exclude=self._exclude_patterns(), cancelled=self._scan_cancel.is_set, quick=quick, destination=self.maps_folder(), deep=deep, search_dirs=self._search_dirs(), recursive=self.col_recursive.isChecked())
        except scanmod.ScanCancelled:
            self._scan_cancel = None
            self.set_busy(False)
            self.status.setText('Scan cancelled - previous results kept')
            return
        except Exception as e:
            self._scan_cancel = None
            log('Scan error: %s' % e)
            self.set_busy(False)
            self.status.setText('Scan failed - see Log')
            return
        self._scan_cancel = None
        _CACHE['result'] = r
        log('Scan: %d file(s), %d missing, %d effect(s)  (%.2fs)' % (len(r.items), len(r.missing), len(r.effects), r.seconds))
        for stage, seconds in r.timings.items():
            log('  %s: %.2fs' % (stage, seconds))
        self.show_result(r, keep_ticks=keep_ticks)
        self.set_busy(False)
        self.status.setText(('Quick audit complete - %d missing. Full scan required for map usage/conversion.' % len(r.missing)) if quick else ('Full scan complete %s - %d missing' % (time.strftime('%H:%M:%S'), len(r.missing))))

    def show_result(self, r, keep_ticks=False):
        self.result = r
        # Assets
        self.model.set_rows(r.items)
        counts = {}
        for it in r.items:
            counts[it.ext] = counts.get(it.ext, 0) + 1
        hidden = {self.ext_list.item(i).data(Qt.UserRole) for i in range(self.ext_list.count())
                  if self.ext_list.item(i).checkState() != Qt.Checked}
        self.ext_list.blockSignals(True)
        self.ext_list.clear()
        for ext in sorted(counts):
            li = QtWidgets.QListWidgetItem('%s  (%d)' % (ext or '(none)', counts[ext]))
            li.setData(Qt.UserRole, ext)
            li.setFlags(li.flags() | Qt.ItemIsUserCheckable)
            li.setCheckState(Qt.Unchecked if ext in hidden else Qt.Checked)
            self.ext_list.addItem(li)
        self.ext_list.blockSignals(False)
        st = {}
        for it in r.items:
            if it.used:
                st[it.status] = st.get(it.status, 0) + 1
        for key, cb in self.status_checks.items():
            cb.setText('%s: %d' % (STATUS_TEXT[key], st.get(key, 0)))
        self._as_refilter()
        # Audit (tabbed)
        old = {}
        if keep_ticks:
            for cat_key, model in self.aud_tab_models.items():
                for r_ in model.rows:
                    old[(r_.cat, scanmod.norm_key(r_.item.path) if r_.item else None, r_.effect)] = r_.ticked
        rows = build_audit_rows(r, self.maps_folder())
        self._prepare_path_rows = [row for row in rows if row.cat in ('Relink', 'Missing')]
        # Distribute rows to tab models
        for cat_key, model in self.aud_tab_models.items():
            cat_rows = [row for row in rows if row.cat == cat_key]
            for row in cat_rows:
                row.ticked = old.get((row.cat, scanmod.norm_key(row.item.path) if row.item else None, row.effect), False)
            model.set_rows(cat_rows)
        # Refresh all tabs
        for cat_key in self.aud_tab_models:
            self._aud_tab_refilter(cat_key)
        self._aud_counts()
        self._arc_summary()
        conv = ops.converter()
        if hasattr(self, 'conv_label'):
            self.conv_label.setText({'magick': 'Converter: ImageMagick (uncompressed PNG)',
                                 'oiio': 'Converter: OpenImageIO (uncompressed PNG)'}.get(
            conv[0], 'Converter: 3ds Max loader. Install ImageMagick for uncompressed PNG and .tx support.'))

    # ---- Assets filters ------------------------------------------------------------------
    def _as_accept(self, it):
        if not it.used and not self.show_unused.isChecked():
            return False
        if not self.status_checks[it.status].isChecked():
            return False
        if self._exts is not None and it.ext not in self._exts:
            return False
        t = self._text
        return not t or t in it.path.lower()

    def _as_refilter(self):
        exts = {self.ext_list.item(i).data(Qt.UserRole) for i in range(self.ext_list.count())
                if self.ext_list.item(i).checkState() == Qt.Checked}
        self._exts = None if len(exts) == self.ext_list.count() else exts
        self._text = self.search.text().strip().lower()
        self.proxy.accept = self._as_accept
        self.proxy.refilter()
        shown = self.proxy.rowCount()
        rows = self.model.rows
        used = [i for i in rows if i.used]
        self.meta.setText('%d of %d files shown   |   %d used by the scene (%s)   |   %d unused' % (
            shown, len(rows), len(used), fmt_size(sum(i.size for i in used)), len(rows) - len(used)))

    def _exclude_patterns(self):
        return [self.exclude_list.item(i).text().strip()
                for i in range(self.exclude_list.count())
                if self.exclude_list.item(i).text().strip()]

    def _load_exclude(self):
        self.exclude_list.blockSignals(True)
        self.exclude_list.clear()
        for pat in config.get_list('Assets', 'exclude'):
            self.exclude_list.addItem(pat)
        self.exclude_list.blockSignals(False)

    def _save_exclude(self):
        config.set_list('Assets', 'exclude', self._exclude_patterns())

    def _add_exclude(self):
        text, ok = QtWidgets.QInputDialog.getText(
            self, 'Exclude pattern',
            'Glob pattern, matched against file name and full path.\n'
            'Examples:   *.tmp    thumbs.db    .svn    *_backup*')
        if ok and text.strip():
            self.exclude_list.addItem(text.strip())
            self._save_exclude()

    def _remove_exclude(self):
        for it in self.exclude_list.selectedItems():
            self.exclude_list.takeItem(self.exclude_list.row(it))
        self._save_exclude()

    def _ext_all(self, on):
        self.ext_list.blockSignals(True)
        for i in range(self.ext_list.count()):
            self.ext_list.item(i).setCheckState(Qt.Checked if on else Qt.Unchecked)
        self.ext_list.blockSignals(False)
        self._as_refilter()

    # ---- right-click ---------------------------------------------------------------------
    def selected_items(self):
        rows = sorted({self.proxy.mapToSource(i).row() for i in self.table.selectionModel().selectedRows()})
        return [self.model.rows[r] for r in rows]

    def _menu(self, pos):
        # Keep multi-selection when the clicked row is already selected.
        index = self.table.indexAt(pos)
        if index.isValid() and not self.table.selectionModel().isRowSelected(index.row(), index.parent()):
            self.table.selectRow(index.row())
        items = self.selected_items()
        if not items:
            return
        m = QtWidgets.QMenu(self)
        actions = (
            ('Relocate links', self._relocate_selected,
             not self.busy and any(i.resolved and i.status == 'found' for i in items)),
            ('Convert images', self._convert_selected,
             not self.busy and any(i.resolved and i.ext in scanmod.CONVERT_EXTS for i in items)),
            ('Preview image/map', self._preview_selected,
             not self.busy and len(items) == 1 and bool(items[0].resolved)
             and items[0].kind in ('Textures', 'HDRI')),
        )
        for text, fn, enabled in actions:
            action = QAction(text, m)
            action.setEnabled(enabled)
            action.triggered.connect(fn)
            m.addAction(action)
        m.addSeparator()
        self._add_texture_actions(m, items)
        for text, fn in (('Copy path', self._copy),):
            a = QAction(text, m)
            a.triggered.connect(fn)
            m.addAction(a)
        at = self.table.viewport().mapToGlobal(pos)
        m.exec_(at) if hasattr(m, 'exec_') else m.exec(at)

    def _relocate_selected(self):
        """Commit resolved moved/relative paths for selected assets only."""
        if self.busy:
            return
        pairs = [(i, i.resolved) for i in self.selected_items()
                 if i.resolved and i.status == 'found']
        if not pairs:
            return
        if QtWidgets.QMessageBox.question(
                self, 'Relocate links', 'Make %d selected link(s) absolute?\nCtrl+Z undoes this step.' % len(pairs)
        ) != QtWidgets.QMessageBox.Yes:
            return
        with maxops.undo('NSC Relocate selected links'):
            n = ops.relink(pairs, log)
        log('Relocated %d of %d selected link(s)' % (n, len(pairs)))
        self.after_change('Relocated %d selected link(s)' % n)

    def _convert_selected(self):
        """Reuse the existing TX/TIF/TIFF conversion and relink workflow."""
        if self.busy:
            return
        items = [i for i in self.selected_items()
                 if i.resolved and i.ext in scanmod.CONVERT_EXTS]
        if items:
            self._convert_items(items, self.after_change)

    def _preview_selected(self):
        if self.busy:
            return
        items = self.selected_items()
        if len(items) != 1 or not items[0].resolved:
            return
        item = items[0]
        if item.kind not in ('Textures', 'HDRI'):
            return
        pixmap = QtGui.QPixmap(item.resolved)
        if pixmap.isNull():
            # Max plug-in loaders support formats Qt cannot decode, such as TX/HDR.
            try:
                with tempfile.TemporaryDirectory(prefix='nsc_preview_') as folder:
                    target = os.path.join(folder, 'preview.png')
                    if maxops.max_to_png(item.resolved, target):
                        pixmap = QtGui.QPixmap(target)
            except Exception as e:
                log('Preview failed: %s (%s)' % (item.resolved, e))
        if pixmap.isNull():
            QtWidgets.QMessageBox.warning(self, 'Preview image/map',
                                         'Cannot preview this asset with Qt or the 3ds Max bitmap loader.\n'
                                         + item.resolved)
            return
        dialog = QtWidgets.QDialog(self)
        dialog.setAttribute(Qt.WA_DeleteOnClose)
        dialog.setWindowTitle('Preview - ' + item.name)
        layout = QtWidgets.QVBoxLayout(dialog)
        info = label('%s  |  %d x %d' % (item.resolved, pixmap.width(), pixmap.height()), 'muted')
        info.setWordWrap(True)
        layout.addWidget(info)
        image = QtWidgets.QLabel()
        image.setAlignment(Qt.AlignCenter)
        image.setPixmap(pixmap)
        scroll = QtWidgets.QScrollArea()
        scroll.setWidget(image)
        scroll.setWidgetResizable(True)
        layout.addWidget(scroll)
        dialog.resize(min(1000, max(400, pixmap.width() + 40)),
                      min(800, max(300, pixmap.height() + 100)))
        dialog.show()

    def _bind_texture_menu(self, table, handler):
        viewport = table.viewport()
        self.texture_context_handlers[viewport] = handler
        viewport.installEventFilter(self)

    def eventFilter(self, watched, event):
        if event.type() == QtCore.QEvent.ContextMenu:
            handler = self.texture_context_handlers.get(watched)
            if handler is not None:
                handler(event.pos())
                return True
        return super().eventFilter(watched, event)

    def _audit_asset_menu(self, cat, pos):
        table = self.aud_tab_tables[cat]
        index = table.indexAt(pos)
        if not index.isValid():
            return
        proxy = self.aud_tab_proxies[cat]
        row = self.aud_tab_models[cat].rows[proxy.mapToSource(index).row()]
        if row.item is None:
            return
        menu = QtWidgets.QMenu(self)
        self._add_texture_actions(menu, [row.item])
        at = table.viewport().mapToGlobal(pos)
        menu.exec_(at) if hasattr(menu, 'exec_') else menu.exec(at)

    def _add_texture_actions(self, menu, items):
        textures = [it for it in items if it.kind in ('Textures', 'HDRI')]
        for name, callback, enabled in (
            ('Select objects using texture', lambda: self._inspect_usage(textures), bool(textures)),
            ('Show material in Material Editor', lambda: self._inspect_usage(textures, material=True), bool(textures)),
            ('Open in Explorer', lambda: self._explore_item(items[0]), True),
        ):
            action = menu.addAction(name)
            action.setEnabled(enabled and not self.busy)
            action.triggered.connect(callback)

    def _inspect_usage(self, items, material=False):
        if self.busy or not items:
            return
        rt = maxops.rt
        nodes = {}
        visited = set()
        owners = []
        try:
            for item in items:
                for owner, prop in item.inspection_refs + item.refs:
                    current = maxops.get_map_path(owner, prop)
                    if scanmod.norm_key(current) != item.key:
                        continue
                    handle = int(rt.getHandleByAnim(owner))
                    if handle in visited:
                        continue
                    visited.add(handle)
                    owners.append(owner)
                    for node in rt.refs.dependentNodes(owner):
                        nodes[int(rt.getHandleByAnim(node))] = node
            if not nodes and not material:
                self.status.setText('No objects found in the latest audit. Rescan if scene materials changed.')
                return
            if not material:
                rt.select(list(nodes.values()))
                rt.redrawViews()
                names = ', '.join(str(n.name) for n in list(nodes.values())[:3])
                self.status.setText(f'Selected {len(nodes)} object(s): {names}')
                return
            materials = {}
            for owner in owners:
                for dep in rt.refs.dependents(owner):
                    if rt.superClassOf(dep) == rt.Material:
                        materials[int(rt.getHandleByAnim(dep))] = dep
            choices = list(materials.values()) or owners[:1]
            if not choices:
                self.status.setText('No live texture owner was found in the latest audit.')
                return
            selected = choices[0]
            if len(choices) > 1:
                names = [f'{i + 1}. {mtl.name}' for i, mtl in enumerate(choices)]
                choice, ok = QtWidgets.QInputDialog.getItem(self, 'Show material', 'Material', names, 0, False)
                if not ok:
                    self.status.setText('Material selection cancelled.')
                    return
                selected = choices[names.index(choice)]
            rt.sme.Open()
            view = rt.sme.GetView(rt.sme.activeView)
            if view.GetNodeByRef(selected) is None:
                x = max((view.GetNode(i).position.x for i in range(1, view.GetNumNodes() + 1)), default=-320)
                view.CreateNode(selected, rt.Point2(x + 320, 0))
            view.SetSelectedNodes(rt.Array(selected))
            view.ZoomExtents(type=rt.Name('selected'))
            rt.sme.SetMtlInParamEditor(selected)
            self.status.setText(f'Showing {selected.name} in the Slate Material Editor.')
        except (RuntimeError, TypeError, AttributeError) as exc:
            log(f'Could not inspect texture usage: {exc}')
            self.status.setText('Could not inspect texture usage. See Log.')

    def _explore(self):
        items = self.selected_items()
        if items:
            self._explore_item(items[0])

    def _explore_item(self, item):
        path = os.path.normpath(item.resolved or item.path)
        if os.path.isabs(path) and os.path.isfile(path):
            subprocess.Popen(['explorer.exe', '/select,' + path])
        elif os.path.isabs(path) and os.path.isdir(os.path.dirname(path)):
            subprocess.Popen(['explorer.exe', os.path.dirname(path)])
        else:
            self.status.setText('This texture has no accessible folder.')

    def _copy(self):
        QtWidgets.QApplication.clipboard().setText('\n'.join(i.resolved or i.path for i in self.selected_items()))

    def closeEvent(self, e):
        if self._scan_cancel is not None:
            self.cancel()
            e.ignore()
            return
        if self.job is not None:
            self.cancel()
            e.ignore()
            return
        NSCWindow.instance = None
        super(NSCWindow, self).closeEvent(e)


def show():
    """Open (or bring back) the window. Reuses the last scan of this session."""
    w = NSCWindow.instance
    if w is not None:
        w.show()
        w.raise_()
        w.activateWindow()
        return w
    w = NSCWindow(max_main_window())
    NSCWindow.instance = w
    w.show()
    w._scene_defaults()
    r = _CACHE['result']
    if r is not None:
        r.scene = maxops.scene_file()   # Save As keeps the scan
        r.recheck(w._exclude_patterns(), w.maps_folder(), w._search_dirs(), w.col_recursive.isChecked())
        w.show_result(r)
        w.status.setText(('Cached Quick audit - input files rechecked. Full scan for map usage/conversion.') if r.mode == 'quick' else ('Results from %s - files re-checked' % time.strftime('%H:%M:%S', time.localtime(r.created))))
    else:
        QtCore.QTimer.singleShot(50, lambda: w.run_scan(quick=True, deep=False))
    return w


def invalidate():
    """Called by Max callbacks when a different scene is opened / reset."""
    _CACHE['result'] = None
