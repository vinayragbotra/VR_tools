"""Network Sanity Check - Python / Qt version.  Usage inside 3ds Max:  import nsc; nsc.show()"""
from __future__ import annotations

try:
    from pymxs import runtime as rt
except ImportError:
    rt = None  # type: ignore  # outside 3ds Max: package stays importable, CLI prints a friendly error

from .config import config

__version__ = "1.1.2"


def _register_callbacks() -> None:
    if rt is None:
        return
    # opening / resetting a scene makes the cached scan stale (Save As keeps it)
    try:
        rt.callbacks.removeScripts(id=rt.Name("NSC_PyStale"))
    except Exception:
        pass
    cmd = 'python.Execute "import nsc; nsc.invalidate_safe()"'
    for ev in ("filePostOpen", "filePostMerge", "systemPostReset", "systemPostNew"):
        try:
            rt.callbacks.addScript(rt.Name(ev), cmd, id=rt.Name("NSC_PyStale"))
        except Exception:
            pass  # one unsupported event must not break the others


def invalidate_safe() -> None:
    """Callback entry point - a callback must never raise inside Max."""
    try:
        from . import ui
        ui.invalidate()
    except Exception:
        pass


def show():
    if rt is None:
        raise RuntimeError("nsc.show() only works inside 3ds Max (pymxs not available)")
    from . import ui
    _register_callbacks()
    return ui.show()


def reload_all():
    """Developer helper: reload the modules after editing the .py files."""
    import importlib
    import sys
    w = sys.modules.get("nsc.ui")
    if w is not None and w.NSCWindow.instance is not None:
        w.NSCWindow.instance.close()
    for name in ("nsc.qt", "nsc.maxops", "nsc.scan", "nsc.ops", "nsc.ui", "nsc.config"):
        if name in sys.modules:
            importlib.reload(sys.modules[name])
