"""Everything that touches the 3ds Max scene. Must run on Max's main thread.

Bulk work is done by small MAXScript helpers (one call from Python instead of thousands).
"""
from __future__ import annotations

import os
from typing import TYPE_CHECKING

from pymxs import runtime as rt
import pymxs

from .config import config, ini_get, ini_set

if TYPE_CHECKING:
    from typing import Any, Callable

_HELPERS_PATH = os.path.join(os.path.dirname(__file__), "helpers.ms")
_loaded = False


def _ensure() -> None:
    """Load MAXScript helpers once."""
    global _loaded
    if not _loaded:
        if not os.path.isfile(_HELPERS_PATH):
            raise FileNotFoundError(f"MAXScript helpers not found at {_HELPERS_PATH}")
        with open(_HELPERS_PATH, "r", encoding="utf-8") as f:
            rt.execute(f.read())
        _loaded = True


def scan_maps(progress=None, cancelled=None):
    """Enumerate one map class at a time; callbacks stay on Max's thread."""
    from .scan import check_cancel
    _ensure()
    classes = list(rt.textureMap.classes)
    rows = []
    for index, cls in enumerate(classes):
        check_cancel(cancelled)
        if progress:
            progress(0.05 + 0.30 * index / max(1, len(classes)),
                     'Reading maps: %d/%d classes | %d links | %s' %
                     (index + 1, len(classes), len(rows), str(cls)))
        check_cancel(cancelled)
        owners, props, paths, used = rt.NSC_ScanMaps(classes=rt.Array(cls))
        rows.extend((owners[i], str(props[i]), str(paths[i]), bool(used[i])) for i in range(len(paths)))
    return rows


def output_files():
    """Configured/typed output paths only; never list or stat output directories."""
    paths = rt.execute(r"""(
        local paths = #()
        if rendOutputFilename != "" do append paths rendOutputFilename
        local manager = maxOps.GetCurRenderElementMgr()
        for i = 0 to (manager.NumRenderElements() - 1) do (
            local path = manager.GetRenderElementFilename i
            if path != "" do append paths path
        )
        for i = 1 to batchRenderMgr.numViews do (
            local path = (batchRenderMgr.getView i).outputFilename
            if path != "" do append paths path
        )
        for i = 1 to AssetManager.GetNumAssets() do (
            local asset = AssetManager.GetAssetByIndex i
            if asset.GetType() == #RenderOutput do append paths (asset.GetFileName())
        )
        paths
    )""")
    return {os.path.normcase(os.path.normpath(str(path))) for path in paths if path}


def ats_files():
    """Input dependencies only. Do not probe output/network paths in native ATS."""
    outputs = output_files()
    ats = rt.ATSOps
    previous = {}
    files = []
    try:
        for key, value in [('ExcludeOutputFiles', True), ('DisplayExcluded', False), ('CheckNetworkPaths', False)]:
            previous[key] = getattr(ats, key)
            setattr(ats, key, value)
        ats.Refresh()
        res = ats.GetFiles(pymxs.byref([]))
        if isinstance(res, tuple) and len(res) > 1:
            files = res[1] or []
        elif isinstance(res, list):
            files = res
        return [str(f) for f in files if f and os.path.normcase(os.path.normpath(str(f))) not in outputs]
    finally:
        for key, value in previous.items():
            setattr(ats, key, value)


def resolved_paths(paths):
    """Read Max's resolved alternatives without modifying scene references."""
    _, resolved = rt.ATSOps.GetResolvedPaths(paths, pymxs.byref(rt.Array()))
    return [str(path) for path in resolved]


def set_map_path(owner: Any, prop: str, path: str) -> bool:
    """Set a texture map's file path. Returns True on success."""
    try:
        rt.setProperty(owner, prop, path)
        return True
    except (RuntimeError, AttributeError, TypeError):
        return False


def get_map_path(owner: Any, prop: str) -> str | None:
    """Get a texture map's current file path."""
    try:
        return str(rt.getProperty(owner, prop))
    except (RuntimeError, AttributeError, TypeError):
        return None


def retarget(olds: list[str], news: list[str]) -> list[bool]:
    """Asset Tracking relink (proxies, IES, XRefs ...). Returns [bool] per file."""
    if not olds:
        return []
    _ensure()
    return [bool(x) for x in rt.NSC_Retarget(olds, news)]


def effects() -> list[str]:
    """Names of all render effects in the scene."""
    return [str(rt.getEffect(i).name) for i in range(1, rt.numEffects + 1)]


def delete_effects(indices: list[int]) -> int:
    """Delete render effects by 1-based indices. Returns count deleted."""
    n = 0
    for i in sorted(indices, reverse=True):
        if 1 <= i <= rt.numEffects:
            rt.deleteEffect(i)
            n += 1
    return n


def max_to_png(src: str, dest: str) -> bool:
    """Convert image to PNG using 3ds Max bitmap (fallback converter)."""
    _ensure()
    return bool(rt.NSC_MaxToPng(src, dest))


def save_copy(path: str) -> bool:
    """Save a copy of the current scene to path."""
    _ensure()
    return bool(rt.NSC_SaveCopy(path))


def scene_file() -> str:
    """Full path to the current scene file, or empty string if unsaved."""
    return (
        os.path.join(str(rt.maxFilePath), str(rt.maxFileName))
        if rt.maxFileName
        else ""
    )


def undo(label: str) -> Callable[[], None]:
    """Context manager for undo block. Usage: with undo('Label'): ..."""
    return pymxs.undo(True, label)


def save_required() -> bool:
    return bool(rt.getSaveRequired())


def set_save_required(on: bool) -> None:
    rt.setSaveRequired(bool(on))


def no_undo() -> Callable[[], None]:
    """Context manager that disables undo. Usage: with no_undo(): ..."""
    return pymxs.undo(False)
