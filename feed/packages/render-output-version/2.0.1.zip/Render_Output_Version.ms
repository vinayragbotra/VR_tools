-- Compatibility entry point for VR Tools menus and existing toolbar buttons.
global VR_Python_vr_output
(
    local source = try (getThisScriptFilename()) catch (undefined)
    local entry = if source != undefined then (getFilenamePath source + "vr_output/ui.py") else ""
    if doesFileExist entry then VR_Python_vr_output = entry
    else if VINAY_LOCAL_DIR != undefined do VR_Python_vr_output = VINAY_LOCAL_DIR + "vr_output/ui.py"
)
python.Execute "__import__('runpy').run_path(str(__import__('pymxs').runtime.VR_Python_vr_output))['launch']('open_tool')"
