import re
import tempfile
from pathlib import Path
from .ui import Panel, W, leaf, rt

def next_version(parent):
    numbers = [int(p.name[1:]) for p in parent.iterdir()
               if p.is_dir() and re.fullmatch(r"v[0-9]+", p.name, re.I)] if parent.is_dir() else []
    return f"v{max(numbers, default=0)+1:02d}"

def apply_output(parent, version, stem, ext, keep_formats):
    if not parent.is_absolute():
        raise ValueError("Choose an absolute parent folder.")
    folder = parent / leaf(version)
    prefix = leaf(stem) + "_" + version
    if not re.fullmatch(r"\.[a-z0-9]+", ext, re.I):
        raise ValueError("Enter a file extension such as .exr.")
    if rt.renderSceneDialog.isOpen():
        rt.renderSceneDialog.commit()
        rt.renderSceneDialog.close()
    mgr = rt.maxOps.GetRenderElementMgr(rt.Name("production"))
    old_main, old_save, active = rt.rendOutputFilename, rt.rendSaveFile, mgr.GetElementsActive()
    old_paths = [str(mgr.GetRenderElementFilename(i) or "") for i in range(mgr.NumRenderElements())]
    main = str(folder/(prefix+ext))
    used = {Path(main).name.casefold()}
    paths = []
    for i, old in enumerate(old_paths):
        name = re.sub(r'[<>:"/\\|?*\x00-\x1f]', "_", str(mgr.GetRenderElement(i).elementName)).strip(" .") or "Element"
        ending = (Path(old).suffix if keep_formats else "") or ext
        base = prefix+"_"+name
        filename = base+ending
        number = 2
        while filename.casefold() in used:
            filename = f"{base}_{number}{ending}"
            number += 1
        used.add(filename.casefold())
        paths.append(str(folder/filename))
    folder.mkdir(parents=True, exist_ok=False)
    with tempfile.NamedTemporaryFile(dir=folder):
        pass
    try:
        rt.rendOutputFilename = main
        rt.rendSaveFile = True
        mgr.SetElementsActive(True)
        for i,path in enumerate(paths):
            mgr.SetRenderElementFilename(i,path)
        if (Path(rt.rendOutputFilename)!=Path(main) or not rt.rendSaveFile or not mgr.GetElementsActive()
                or any(Path(str(mgr.GetRenderElementFilename(i)))!=Path(p) for i,p in enumerate(paths))):
            raise RuntimeError("3ds Max did not retain all output settings.")
        rt.setSaveRequired(True)
    except Exception as error:
        failures = []
        restore = [(setattr,(rt,"rendOutputFilename",old_main)), (setattr,(rt,"rendSaveFile",old_save)),
                   (mgr.SetElementsActive,(active,))]
        restore.extend((mgr.SetRenderElementFilename,(i,p)) for i,p in enumerate(old_paths))
        for setter,args in restore:
            try:
                setter(*args)
            except Exception as exc:
                failures.append(str(exc))
        raise RuntimeError(str(error) + ("\nCheck Render Setup: " + ", ".join(failures) if failures
                           else "\nPrevious output settings restored.")) from error
    return len(paths)

class OutputPanel(Panel):
    def __init__(self):
        super().__init__("Render Output Version",480)
        current = str(rt.rendOutputFilename or "")
        parent = Path(current).parent if current else Path(str(rt.maxFilePath or rt.getDir(rt.Name("renderoutput"))))
        if re.fullmatch(r"v[0-9]+",parent.name,re.I):
            parent = parent.parent
        form = self.group("Output location")
        self.folder = W.QLineEdit(str(parent))
        self.version = W.QLineEdit(next_version(parent))
        self.stem = W.QLineEdit(re.sub(r"_v[0-9]+$","",Path(current or str(rt.maxFileName)).stem,flags=re.I) or "render")
        self.ext = W.QLineEdit(Path(current).suffix or ".exr")
        form.addRow("Parent folder",self.row(self.folder,self.button("Browse",self.browse)))
        form.addRow("Version",self.row(self.version,self.button("Next unused",self.next)))
        form.addRow("Image name",self.stem)
        form.addRow("Format",self.ext)
        self.keep = W.QCheckBox("Keep existing element formats")
        self.keep.setChecked(True)
        form.addRow(self.keep)
        self.preview = W.QLineEdit()
        self.preview.setReadOnly(True)
        form.addRow("Main output",self.preview)
        for field in (self.folder,self.version,self.stem,self.ext):
            field.textChanged.connect(self.refresh)
        self.refresh()
        self.body.addWidget(self.button("Create folder and update paths",self.apply,True))
        self.finish()

    def refresh(self):
        path = Path(self.folder.text())/self.version.text()/(self.stem.text()+"_"+self.version.text()+self.ext.text())
        self.preview.setText(str(path))
        self.preview.setToolTip(str(path))

    def next(self):
        self.version.setText(next_version(Path(self.folder.text())))

    def browse(self):
        folder = W.QFileDialog.getExistingDirectory(self,"Parent folder",self.folder.text())
        if folder:
            self.folder.setText(folder)
            self.next()

    def apply(self):
        count = apply_output(Path(self.folder.text()),self.version.text().strip(),self.stem.text().strip(),self.ext.text().strip(),self.keep.isChecked())
        self.status.setText(f"Updated the main output and {count} element paths. Save the scene before submitting.")
        self.next()

open_tool = OutputPanel
