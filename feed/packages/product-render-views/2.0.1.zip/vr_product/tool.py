from pathlib import Path
from .ui import Panel, QtCore, W, cameras, leaf, rt


class ProductPanel(Panel):
    def __init__(self):
        super().__init__("Product Render Views")
        self.product = W.QLineEdit()
        form = self.group("Product")
        form.addRow("Name", self.product)

        camera_form = self.group("Cameras")
        self.camera_list = W.QListWidget()
        self.camera_list.setMinimumHeight(105)
        self.camera_list.setMaximumHeight(185)
        camera_form.addRow(self.camera_list)
        camera_form.addRow(self.button("Refresh cameras", self.refresh_cameras))
        self.render_button = self.button("Render selected angles", lambda: self.process(False), True)
        self.batch_button = self.button("Send to Batch Render", lambda: self.process(True))
        self.body.addLayout(self.row(self.render_button, self.batch_button))
        self.camera_list.itemChanged.connect(self.update_actions)
        self.refresh_cameras()
        self.finish()

    def eligible_cameras(self):
        states = rt.sceneStateMgr
        names = [str(states.GetSceneState(i)) for i in range(1, states.GetCount() + 1)]
        lookup = {name.casefold(): name for name in names}
        return [(cam, lookup[cam.name[4:].casefold()]) for cam in cameras()
                if cam.name.lower().startswith("cam_") and cam.name[4:].casefold() in lookup]

    def camera_items(self):
        return [self.camera_list.item(i) for i in range(self.camera_list.count())]

    def selected_handles(self):
        return {item.data(QtCore.Qt.UserRole) for item in self.camera_items()
                if item.checkState() == QtCore.Qt.Checked}

    def update_actions(self):
        enabled = bool(self.selected_handles())
        self.render_button.setEnabled(enabled)
        self.batch_button.setEnabled(enabled)

    def refresh_cameras(self):
        unchecked = {item.data(QtCore.Qt.UserRole) for item in self.camera_items()
                     if item.checkState() != QtCore.Qt.Checked}
        self.camera_list.clear()
        for cam, state in self.eligible_cameras():
            handle = int(rt.getHandleByAnim(cam))
            item = W.QListWidgetItem(str(cam.name))
            item.setData(QtCore.Qt.UserRole, handle)
            item.setToolTip(f"Scene state: {state}")
            item.setFlags(item.flags() | QtCore.Qt.ItemIsUserCheckable)
            item.setCheckState(QtCore.Qt.Unchecked if handle in unchecked else QtCore.Qt.Checked)
            self.camera_list.addItem(item)
        self.update_actions()
        self.status.setText("" if self.camera_list.count() else "No cam_<view> cameras have matching scene states.")

    def process(self, batch):
        selected = self.selected_handles()
        if not selected:
            raise ValueError("Check at least one camera.")
        eligible = {int(rt.getHandleByAnim(cam)): (cam, state) for cam, state in self.eligible_cameras()}
        ordered = [item.data(QtCore.Qt.UserRole) for item in self.camera_items()
                   if item.checkState() == QtCore.Qt.Checked]
        if not selected.issubset(eligible):
            raise ValueError("The checked cameras or scene states changed. Refresh cameras and review the selection.")
        if not str(rt.maxFilePath):
            raise ValueError("Save your scene first.")
        product = leaf(self.product.text().replace(" ", "_"))
        states = rt.sceneStateMgr
        jobs = []
        for handle in ordered:
            cam, state = eligible[handle]
            view = leaf(cam.name[4:])
            path = Path(str(rt.maxFilePath))/"_renders"/"products"/product/view/(product+"_"+view+".exr")
            jobs.append((cam, view, state, path))
        for _, _, _, path in jobs:
            path.parent.mkdir(parents=True, exist_ok=True)

        manager = rt.batchRenderMgr
        if batch:
            while manager.numViews:
                manager.DeleteView(manager.numViews)
        for cam, view, state, path in jobs:
            if batch:
                job = manager.CreateView(cam)
                job.name = product + "_" + view
                job.outputFilename = str(path)
                job.sceneStateName = state
            else:
                if not states.RestoreAllParts(state):
                    raise RuntimeError("Could not restore scene state " + state)
                rt.render(camera=cam, outputFile=str(path), vfb=False, quiet=True)
        self.status.setText(f"{len(jobs)} view(s) " + ("queued." if batch else "rendered."))


open_tool = ProductPanel

