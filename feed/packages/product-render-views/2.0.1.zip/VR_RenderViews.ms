-- Compatibility entry point for VR Tools menus and existing toolbar buttons.
global VR_Python_vr_product
(
    local source = try (getThisScriptFilename()) catch (undefined)
    local entry = if source != undefined then (getFilenamePath source + "vr_product/ui.py") else ""
    if doesFileExist entry then VR_Python_vr_product = entry
    else if VINAY_LOCAL_DIR != undefined do VR_Python_vr_product = VINAY_LOCAL_DIR + "vr_product/ui.py"
)
python.Execute "__import__('runpy').run_path(str(__import__('pymxs').runtime.VR_Python_vr_product))['launch']('open_tool')"
