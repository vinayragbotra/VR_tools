from pathlib import Path
from .ui import Panel, W, cameras, leaf, rt

class ProductPanel(Panel):
    def __init__(self):
        super().__init__("Product Render Views")
        self.product = W.QLineEdit()
        form = self.group("Product")
        form.addRow("Name", self.product)
        form.addRow(self.row(self.button("Render all angles", lambda: self.process(False), True),
                             self.button("Send to Batch Render", lambda: self.process(True))))
        self.finish()

    def process(self, batch):
        if not str(rt.maxFilePath):
            raise ValueError("Save your scene first.")
        product = leaf(self.product.text().replace(" ", "_"))
        states = rt.sceneStateMgr
        names = [str(states.GetSceneState(i)) for i in range(1,states.GetCount()+1)]
        lookup = {s.casefold():s for s in names}
        jobs, skipped = [], []
        for cam in cameras():
            if cam.name.lower().startswith("cam_"):
                view = cam.name[4:]
                state = lookup.get(view.casefold())
                if not state:
                    skipped.append(cam.name)
                    continue
                view = leaf(view)
                path = Path(str(rt.maxFilePath))/"_renders"/"products"/product/view/(product+"_"+view+".exr")
                path.parent.mkdir(parents=True,exist_ok=True)
                jobs.append((cam,view,state,path))
        if not jobs:
            raise ValueError("No cam_<view> cameras have matching scene states.")
        manager = rt.batchRenderMgr
        if batch:
            while manager.numViews:
                manager.DeleteView(manager.numViews)
        for cam, view, state, path in jobs:
            if batch:
                job = manager.CreateView(cam)
                job.name = product + "_" + view
                job.outputFilename = str(path)
                job.sceneStateName = state
            else:
                if not states.RestoreAllParts(state):
                    raise RuntimeError("Could not restore scene state "+state)
                rt.render(camera=cam, outputFile=str(path), vfb=False, quiet=True)
        self.status.setText(f"{len(jobs)} view(s) " + ("queued." if batch else "rendered.") +
                            (" Skipped: " + ", ".join(skipped) if skipped else ""))

open_tool = ProductPanel
