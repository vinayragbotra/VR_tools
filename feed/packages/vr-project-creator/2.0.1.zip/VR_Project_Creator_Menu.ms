-- Compatibility entry point for VR Tools menus and existing toolbar buttons.
global VR_Python_vr_project
(
    local source = try (getThisScriptFilename()) catch (undefined)
    local entry = if source != undefined then (getFilenamePath source + "vr_project/ui.py") else ""
    if doesFileExist entry then VR_Python_vr_project = entry
    else if VINAY_LOCAL_DIR != undefined do VR_Python_vr_project = VINAY_LOCAL_DIR + "vr_project/ui.py"
)

macroScript VR_Project_Creator category:"VR_tools" buttonText:"VR Project Creator" (
    on execute do (
        if VR_Python_vr_project == undefined do VR_Python_vr_project = (getEnvVariable "LOCALAPPDATA") + "/VR_tools/scripts/vr_project/ui.py"
        python.Execute "__import__('runpy').run_path(str(__import__('pymxs').runtime.VR_Python_vr_project))['launch']('open_tool')"
    )
)
