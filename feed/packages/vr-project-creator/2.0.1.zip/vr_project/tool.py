import getpass
from pathlib import Path
from .ui import Panel, W, rt, leaf, message
from .elements import add_elements

BASES = [Path("Z:/"), Path("D:/_projects")]
UNITS = ["1bhk","2bhk","3bhk","4bhk","jodiflat_a","jodiflat_b"]

def clean(name):
    return leaf(name.strip().lower().replace(" ","_").replace("\\","_").replace("/","_"))

def subfolders(path):
    return sorted((p.name for p in path.iterdir() if p.is_dir()),key=str.casefold) if path.is_dir() else []

def write_project_file(folder):
    directories = dict.fromkeys(("Animations","BitmapProxies","Downloads","Expressions","Fluid Simulations",
                                 "Import","Materials","MaxStart","Photometric","Previews","RenderAssets",
                                 "RenderPresets","Scenes","Sounds","VideoPost"),".\\")
    directories.update(Archives=".\\archives",AutoBackup=".\\autobackup",Export=".\\exports",Images=".\\maps",
                       ProjectFolder=str(folder)+"\\",RenderOutput=".\\_renders")
    (folder/"3ds.mxp").write_text("[Directories]\n"+"".join(f"{k}={v}\n" for k,v in directories.items()),encoding="utf-8")

def camera_names(unit):
    names = ["bedroom01","living_cam01","living_cam02","kitchen","balcony00","bathroom00","bathroom01"]
    if unit in UNITS[1:4]:
        for n in range(2,int(unit[0])+1):
            names.append(f"bedroom{n:02d}")
            if n<4:
                names.append(f"bathroom{n:02d}")
    return ["cam360_"+unit+"_"+s for s in names]

def renderer_instance(renderer):
    candidates = ["Corona"] if renderer=="Corona" else ["V_Ray_7","V_Ray_6__update_2_1","V_Ray_6__update_2",
                                                         "V_Ray_6__update_1","V_Ray_6","V_Ray_Next","V_Ray_Adv"]
    for name in candidates:
        factory = getattr(rt,name,None)
        if factory is not None:
            return factory()
    if renderer == "V-Ray":
        for factory in rt.RendererClass.classes:
            label = str(factory).casefold().replace("_","").replace("-","").replace(" ","")
            if label.startswith("vray") and not any(tag in label for tag in ("gpu","rt","bake","material","preview")):
                return factory()
    raise ValueError(f"{renderer} is unavailable. Check the renderer installation.")

def make_cameras(renderer,unit):
    if renderer=="Corona":
        layers = rt.LayerManager
        layer = layers.getLayerFromName("zzz_cameras360") or layers.newLayerFromName("zzz_cameras360")
        layer.current = True
    for i,name in enumerate(camera_names(unit)):
        if renderer=="Corona":
            cam = rt.CoronaCam()
            cam.targeted = False
            cam.rotation = rt.eulerToQuat(rt.eulerAngles(-90,0,0))
            key = "projection" if rt.isProperty(cam,rt.Name("projection")) else "projectionType"
            setattr(cam,key,2)
        else:
            cam = rt.VRayPhysicalCamera()
            if cam.target is not None:
                rt.delete(cam.target)
                cam.target = None
            cam.type = 3
        cam.name = name
        cam.pos = rt.Point3(i*300,0,167.64)

class ProjectPanel(Panel):
    def __init__(self):
        super().__init__("Project Creator",430)
        form = self.group("Project location")
        self.drive = W.QComboBox()
        self.drive.addItems([f"ASR — {BASES[0]}", f"Mumbai — {BASES[1]}"])
        form.addRow("Base folder",self.drive)
        self.client,self.project = W.QComboBox(),W.QComboBox()
        for name,combo in [("Client",self.client),("Project",self.project)]:
            form.addRow(name,combo)
            field = W.QLineEdit()
            field.setPlaceholderText("New "+name.lower()+" name")
            form.addRow(self.row(field,self.button("Create "+name.lower(),lambda f=field,c=combo:self.create_folder(f,c))))
        form = self.group("Scene setup")
        self.category,self.unit,self.renderer = W.QComboBox(),W.QComboBox(),W.QComboBox()
        self.category.addItems(["units","elevation","amenities","superimpose"])
        self.unit.addItems(UNITS)
        self.renderer.addItems(["Corona","V-Ray"])
        self.custom = W.QLineEdit()
        self.shot = W.QLineEdit()
        self.unit_label,self.custom_label,self.shot_label = [W.QLabel(s) for s in ("Unit type","Custom unit (optional)","Shot / name")]
        form.addRow("Category",self.category)
        form.addRow(self.unit_label,self.unit)
        form.addRow(self.custom_label,self.custom)
        form.addRow(self.shot_label,self.shot)
        form.addRow("Renderer",self.renderer)
        self.category.currentTextChanged.connect(self.fields)
        self.drive.currentIndexChanged.connect(self.clients)
        self.client.currentIndexChanged.connect(self.projects)
        self.load_default_location()
        self.fields()
        self.body.addWidget(self.button("Create project",self.create,True))
        self.finish()

    def base(self):
        return BASES[self.drive.currentIndex()]

    def load_default_location(self):
        if self.clients():
            return
        # Select Mumbai even on a new PC where its project folder is missing.
        self.drive.setCurrentIndex(1)

    def clients(self, *_):
        self.client.clear()
        self.project.clear()
        base = self.base()
        try:
            if self.drive.currentIndex() == 1:
                base.mkdir(parents=True, exist_ok=True)
            names = sorted((p.name for p in base.iterdir() if p.is_dir()), key=str.casefold)
        except OSError as error:
            self.status.setText(f"Cannot open {base}. Check the drive and folder permissions. {error}")
            return False
        self.status.clear()
        self.client.addItems(names)
        return True

    def projects(self):
        self.project.clear()
        if self.client.currentText():
            folder = self.base() / self.client.currentText()
            try:
                self.project.addItems(subfolders(folder))
            except OSError as error:
                self.status.setText(f"Cannot list projects in {folder}. {error}")

    def fields(self):
        units = self.category.currentText()=="units"
        for widget in (self.unit,self.custom,self.unit_label,self.custom_label):
            widget.setVisible(units)
        self.shot.setVisible(not units)
        self.shot_label.setVisible(not units)

    def create_folder(self, field, combo):
        name = clean(field.text())
        parent = self.base()
        if combo is self.project:
            parent /= leaf(self.client.currentText())
        (parent/name).mkdir(exist_ok=True)
        (self.clients if combo is self.client else self.projects)()
        combo.setCurrentText(name)
        field.clear()

    def create(self):
        client, project = leaf(self.client.currentText()),leaf(self.project.currentText())
        category = self.category.currentText()
        variant = clean((self.custom.text() or self.unit.currentText()) if category=="units" else self.shot.text())
        special = category=="superimpose"
        root = self.base()/client/project
        root = root/category/variant if special else root/"archviz"/category/variant
        folder = root/"3ds"
        scene = folder/(clean(project)+("_SI_" if special else "_")+variant+"_v01_"+clean(getpass.getuser())+".max")
        if scene.exists() and not message(self.title,f"Overwrite {scene}?",True,self):
            return
        renderer = self.renderer.currentText()
        instance = renderer_instance(renderer)
        dirs = ["3ds/"+n for n in ("autobackup","maps","proxies","exports","archives")]
        dirs += (["_renders","ae","nuke","plates","tracks"] if special else
                 ["3ds/_renders/_prev/_temp","3ds/_renders/360","ue/imports","_cad","_moodboards"] +
                 ["d5/imports/"+s for s in ("d5a","fbx","abc","maps")])
        for sub in dirs:
            (root/sub).mkdir(parents=True,exist_ok=True)
        write_project_file(folder)
        if not special:
            rt.pathConfig.setCurrentProjectFolder(str(folder))
        rt.units.DisplayType = rt.Name("Metric")
        rt.units.MetricType = rt.units.SystemType = rt.Name("Centimeters")
        rt.renderers.current = instance
        add_elements(renderer,lightmix=False)
        if renderer=="Corona":
            rt.renderers.current.progressive_passLimit = 10
            rt.renderers.current.denoise_filterType = 2
        if category=="units":
            make_cameras(renderer,self.unit.currentText())
        if not rt.saveMaxFile(str(scene),useNewFile=True):
            raise RuntimeError("3ds Max could not save "+str(scene))
        self.status.setText("Saved "+str(scene))

open_tool = ProjectPanel
