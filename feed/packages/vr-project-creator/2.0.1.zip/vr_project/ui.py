"""Shared Qt controls, window lifetime and package entry point."""
import importlib.util
import re
import sys
import weakref
from pathlib import Path

import qtmax
from pymxs import runtime as rt
try:
    from PySide6 import QtCore, QtWidgets as W
except ImportError:
    from PySide2 import QtCore, QtWidgets as W

STYLE = """
QDialog, QMessageBox {background:#141b21;color:#e5ecf0;}
QWidget {font:9pt 'Segoe UI';color:#e5ecf0;}
QLabel {background:transparent;}
QLabel#title {font-size:13pt;font-weight:600;}
QGroupBox {border:1px solid #354653;border-radius:5px;margin-top:8px;padding-top:6px;}
QGroupBox::title {subcontrol-origin:margin;left:8px;padding:0 4px;}
QPushButton {background:#2a3b49;border:1px solid #354653;border-radius:4px;padding:4px 10px;}
QPushButton:hover {background:#395367;}
QPushButton[primary="true"] {background:#176f99;}
QPushButton:disabled {color:#88959d;background:#202c35;}
QLineEdit,QComboBox,QSpinBox,QListWidget,QPlainTextEdit {background:#1d2832;border:1px solid #415362;border-radius:3px;padding:3px;}
QListWidget::item:selected {background:#176f99;color:white;}
"""
def window():
    return qtmax.GetQMaxMainWindow()

def message(title, text, confirm=False, parent=None):
    box = W.QMessageBox(parent or window())
    box.setWindowTitle("VR Tools | " + title)
    box.setTextFormat(QtCore.Qt.PlainText)
    box.setText(str(text))
    box.setStyleSheet(STYLE)
    if confirm:
        box.setStandardButtons(W.QMessageBox.Yes | W.QMessageBox.No)
        box.setDefaultButton(W.QMessageBox.No)
    return box.exec_() == W.QMessageBox.Yes

def leaf(text):
    text = str(text).strip()
    if (not text or text.endswith(('.', ' ')) or re.search(r'[<>:"/\\|?*\x00-\x1f]', text)
            or re.match(r'^(CON|PRN|AUX|NUL|COM[1-9]|LPT[1-9])(?:\.|$)', text, re.I)):
        raise ValueError("Enter a valid Windows file or folder name.")
    return text

def cameras():
    return [node for node in rt.objects if rt.isKindOf(node, rt.Camera)]

class Panel(W.QDialog):
    def __init__(self, title, width=400):
        super().__init__(window())
        self.title = title
        self.setWindowTitle("VR Tools | " + title)
        self.setAttribute(QtCore.Qt.WA_DeleteOnClose)
        self.setStyleSheet(STYLE)
        self.setMinimumWidth(width)
        self.body = W.QVBoxLayout(self)
        heading = W.QLabel(title)
        heading.setObjectName("title")
        self.body.addWidget(heading)
        self.status = W.QLabel()
        self.status.setWordWrap(True)

    def group(self, name):
        group = W.QGroupBox(name)
        form = W.QFormLayout(group)
        form.setFieldGrowthPolicy(W.QFormLayout.AllNonFixedFieldsGrow)
        self.body.addWidget(group)
        return form

    def button(self, label, callback, primary=False):
        button = W.QPushButton(label)
        button.setAutoDefault(False)
        button.setProperty("primary", primary)
        def run():
            try:
                callback()
            except Exception as exc:
                self.status.setText(str(exc))
                message(self.title, exc, parent=self)
        button.clicked.connect(run)
        return button

    def row(self, *widgets):
        layout = W.QHBoxLayout()
        for widget in widgets:
            layout.addWidget(widget)
        return layout

    def finish(self):
        self.body.addWidget(self.status)
        self.adjustSize()

def launch(action="open_tool"):
    # Load each tool as its own package. Each installation owns its files.
    folder = Path(__file__).resolve().parent
    key = "_vrtools_" + folder.name
    app = W.QApplication.instance()
    if not hasattr(app, "_vrtools_dialogs"):
        app._vrtools_dialogs = {}
    windows = app._vrtools_dialogs
    if action == "open_tool" and key in windows:
        existing = windows[key]
        existing.showNormal()
        existing.raise_()
        existing.activateWindow()
        return existing
    spec = importlib.util.spec_from_file_location(key, folder/"tool.py",
                                                  submodule_search_locations=[str(folder)])
    module = importlib.util.module_from_spec(spec)
    sys.modules[key] = module
    sys.modules.pop(key + ".ui", None)
    spec.loader.exec_module(module)
    result = getattr(module, action)()
    if isinstance(result, (W.QDialog, W.QDockWidget)):
        windows[key] = result
        ref = weakref.ref(result)
        def forget(*_):
            if windows.get(key) is ref():
                windows.pop(key, None)
        result.destroyed.connect(forget)
        result.show()
    return result
