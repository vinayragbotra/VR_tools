"""Render element specifications shared by LightMix and Project Creator."""
from pymxs import runtime as rt

def specifications(renderer, lightmix):
    corona = renderer == "Corona"
    base = ([("CESSENTIAL_Reflect",None),("CESSENTIAL_Refract",None),("CMasking_ID","CMasking_MatID"),("CTexmap","CTexmap_AO")]
            if corona else [(name,None) for name in ("VRayReflection","VRayRefraction","VRayMtlID","VRayAO","VRayDenoiser")])
    base.append(("CGeometry_NormalsShading" if corona else "VRayBumpNormals", None))
    if lightmix:
        base.insert(0,("CShading_LightMix" if corona else "VRayLightMix",None))
        base.extend(("CShading_LightSelect" if corona else "VRayLightSelect","LS_"+suffix)
                    for suffix in ("unassigned","HDRI01_light","SUN","winportal","fill","ceiling_panel","profile","objects"))
    return base

def checklist(renderer, lightmix=True):
    manager = rt.maxOps.GetCurRenderElementMgr()
    existing = [manager.GetRenderElement(i) for i in range(manager.NumRenderElements())]
    for kind, name in specifications(renderer,lightmix):
        exists = any(str(rt.classOf(el)).casefold()==kind.casefold() and
                     (not kind.endswith("LightSelect") or str(el.elementName)==name) for el in existing)
        yield kind, name, exists

def set_optional(obj, key, val):
    if rt.isProperty(obj, rt.Name(key)):
        setattr(obj,key,val)

def add_elements(renderer, lightmix=True):
    manager = rt.maxOps.GetCurRenderElementMgr()
    added = 0
    for kind,name,exists in list(checklist(renderer,lightmix)):
        if exists:
            continue
        factory = getattr(rt,kind,None)
        if factory is None:
            raise ValueError(f"{kind} is unavailable. Check the {renderer} installation.")
        element = factory()
        element.enabled = True
        if kind.startswith("CESSENTIAL") or kind=="CTexmap":
            element.useDenoise = True
        if kind=="CTexmap":
            key = "texmap" if rt.isProperty(element,rt.Name("texmap")) else "texture"
            setattr(element,key,rt.CoronaAO())
        if kind=="CMasking_ID":
            element.what = 3
        if kind.endswith("LightSelect"):
            element.elementName = name
            if renderer=="Corona" and name=="LS_unassigned":
                element.nodeSource = 1
            if renderer=="Corona" and name=="LS_HDRI01_light":
                element.addEnvironment = True
        if kind in ("VRayLightMix","VRayReflection","VRayRefraction","VRayAO","VRayLightSelect"):
            set_optional(element,"denoise",True)
        if kind=="VRayDenoiser":
            set_optional(element,"denoising_engine",0)
        if manager.AddRenderElement(element) is False:
            raise RuntimeError("Could not add "+kind)
        added += 1
    return added
