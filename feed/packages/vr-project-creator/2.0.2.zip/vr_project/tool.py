import getpass
import os
from pathlib import Path
from .ui import Panel, W, rt, leaf, message
from .elements import add_elements

BASES = [Path("Z:/"), Path("D:/_projects")]
UNITS = ["1bhk","2bhk","3bhk","4bhk","jodiflat_a","jodiflat_b"]

def clean(name):
    return leaf(name.strip().lower().replace(" ","_").replace("\\","_").replace("/","_"))

def subfolders(path):
    return sorted((p.name for p in path.iterdir() if p.name.casefold() != "$recycle.bin" and p.is_dir()),key=str.casefold) if path.is_dir() else []

def write_project_file(folder):
    directories = dict.fromkeys(("Animations","BitmapProxies","Downloads","Expressions","Fluid Simulations",
                                 "Import","Materials","MaxStart","Photometric","Previews","RenderAssets",
                                 "RenderPresets","Scenes","Sounds","VideoPost"),".\\")
    directories.update(Archives=".\\archives",AutoBackup=".\\autobackup",Export=".\\exports",Images=".\\maps",
                       ProjectFolder=str(folder)+"\\",RenderOutput=".\\_renders")
    (folder/"3ds.mxp").write_text("[Directories]\n"+"".join(f"{k}={v}\n" for k,v in directories.items()),encoding="utf-8")

def camera_names(unit):
    names = ["bedroom01","living_cam01","living_cam02","kitchen","balcony00","bathroom00","bathroom01"]
    if unit in UNITS[1:4]:
        for n in range(2,int(unit[0])+1):
            names.append(f"bedroom{n:02d}")
            if n<4:
                names.append(f"bathroom{n:02d}")
    return ["cam360_"+unit+"_"+s for s in names]

def renderer_instance(renderer):
    candidates = ["Corona"] if renderer=="Corona" else ["V_Ray_7","V_Ray_6__update_2_1","V_Ray_6__update_2",
                                                         "V_Ray_6__update_1","V_Ray_6","V_Ray_Next","V_Ray_Adv"]
    for name in candidates:
        factory = getattr(rt,name,None)
        if factory is not None:
            return factory()
    if renderer == "V-Ray":
        for factory in rt.RendererClass.classes:
            label = str(factory).casefold().replace("_","").replace("-","").replace(" ","")
            if label.startswith("vray") and not any(tag in label for tag in ("gpu","rt","bake","material","preview")):
                return factory()
    raise ValueError(f"{renderer} is unavailable. Check the renderer installation.")

def make_cameras(renderer,unit):
    if renderer=="Corona":
        layers = rt.LayerManager
        layer = layers.getLayerFromName("zzz_cameras360") or layers.newLayerFromName("zzz_cameras360")
        layer.current = True
    for i,name in enumerate(camera_names(unit)):
        if renderer=="Corona":
            cam = rt.CoronaCam()
            cam.targeted = False
            cam.rotation = rt.eulerToQuat(rt.eulerAngles(-90,0,0))
            key = "projection" if rt.isProperty(cam,rt.Name("projection")) else "projectionType"
            setattr(cam,key,2)
        else:
            cam = rt.VRayPhysicalCamera()
            if cam.target is not None:
                rt.delete(cam.target)
                cam.target = None
            cam.type = 3
        cam.name = name
        cam.pos = rt.Point3(i*300,0,167.64)

class ClientFolders(W.QComboBox):
    def __init__(self, load):
        super().__init__()
        self.load = load

    def showPopup(self):
        if not self.count():
            self.load()
        super().showPopup()


class ProjectPanel(Panel):
    def __init__(self):
        super().__init__("Project Creator",430)
        form = self.group("Project location")
        self.drive = W.QComboBox()
        self.drive.addItems([f"ASR — {BASES[0]}", f"Mumbai — {BASES[1]}"])
        form.addRow("Base folder",self.drive)
        self.client,self.project = ClientFolders(self.clients),W.QComboBox()
        folder_buttons = []
        for name,combo in [("Client",self.client),("Project",self.project)]:
            form.addRow(name,combo)
            hint = ("New client? Create a client folder first." if combo is self.client
                    else "New project? Create a project folder.")
            create_button = self.button(f"Create {name} Folder", lambda c=combo: self.folder_dialog(c))
            folder_buttons.append(create_button)
            form.addRow(self.row(W.QLabel(hint),create_button))
        width = max(button.sizeHint().width() for button in folder_buttons)
        height = max(button.sizeHint().height() for button in folder_buttons)
        for button in folder_buttons:
            button.setFixedSize(width,height)
        form = self.group("Scene setup")
        self.category,self.unit,self.renderer = W.QComboBox(),W.QComboBox(),W.QComboBox()
        self.category.addItems(["units","elevation","amenities","superimpose"])
        self.unit.addItems(UNITS)
        self.renderer.addItems(["Corona","V-Ray"])
        self.custom = W.QLineEdit()
        self.shot = W.QLineEdit()
        self.area = W.QLineEdit()
        self.area_label = W.QLabel("Area (optional)")
        self.unit_label,self.custom_label,self.shot_label = [W.QLabel(s) for s in ("Unit type","Custom unit (optional)","Shot / name")]
        form.addRow("Category",self.category)
        form.addRow(self.unit_label,self.unit)
        form.addRow(self.custom_label,self.custom)
        form.addRow(self.area_label,self.area)
        form.addRow(self.shot_label,self.shot)
        form.addRow("Renderer",self.renderer)
        self.category.currentTextChanged.connect(self.fields)
        self.drive.currentIndexChanged.connect(self.clients)
        self.client.currentIndexChanged.connect(self.projects)
        self.load_default_location()
        self.fields()
        preview = self.group("Scene Name Preview")
        self.scene_preview = W.QLineEdit()
        self.scene_preview.setReadOnly(True)
        self.scene_preview.setPlaceholderText("Select a project and complete Scene Setup")
        open_folder = self.button("Open Project Folder", self.open_project_folder)
        open_folder.setEnabled(False)
        self.project.currentTextChanged.connect(lambda name: open_folder.setEnabled(bool(name)))
        preview.addRow(self.row(self.scene_preview,open_folder))
        for combo in (self.project, self.category, self.unit):
            combo.currentTextChanged.connect(self.update_preview)
        for field in (self.custom, self.area, self.shot):
            field.textChanged.connect(self.update_preview)
        self.update_preview()
        self.body.addWidget(self.button("Create Project",self.create,True))
        self.finish()

    def base(self):
        return BASES[self.drive.currentIndex()]

    def project_folder(self):
        return self.base() / leaf(self.client.currentText()) / leaf(self.project.currentText())

    def scene_folder(self, category, variant):
        project = self.project_folder()
        if category != "superimpose":
            project /= "archviz"
        return project / category / variant

    def open_project_folder(self):
        category, variant, _ = self.scene_parts()
        folder = self.scene_folder(category, variant)
        if not folder.is_dir():
            raise ValueError(f"This folder has not been created. Use Create Project first.\n{folder}")
        os.startfile(str(folder))

    def load_default_location(self):
        try:
            asr_available = self.base().is_dir()
        except OSError:
            asr_available = False
        if not asr_available:
            blocked = self.drive.blockSignals(True)
            self.drive.setCurrentIndex(1)
            self.drive.blockSignals(blocked)

    def clients(self, *_):
        self.client.clear()
        self.project.clear()
        base = self.base()
        try:
            if self.drive.currentIndex() == 1:
                base.mkdir(parents=True, exist_ok=True)
            names = subfolders(base)
        except OSError as error:
            self.status.setText(f"Cannot open {base}. Check the drive and folder permissions. {error}")
            return False
        self.status.clear()
        self.client.addItems(names)
        self.client.setCurrentIndex(-1)
        return True

    def projects(self):
        self.project.clear()
        if self.client.currentText():
            folder = self.base() / self.client.currentText()
            try:
                self.project.addItems(subfolders(folder))
                self.project.setCurrentIndex(-1)
            except OSError as error:
                self.status.setText(f"Cannot list projects in {folder}. {error}")

    def fields(self):
        units = self.category.currentText()=="units"
        for widget in (self.unit,self.custom,self.unit_label,self.custom_label,self.area,self.area_label):
            widget.setVisible(units)
        self.shot.setVisible(not units)
        self.shot_label.setVisible(not units)

    def folder_dialog(self, combo):
        creating_client = combo is self.client
        client = self.client.currentText()
        if not creating_client and not client:
            message(self.title, "Select or create a client folder first.", parent=self)
            return
        title = "Create Client Folder" if creating_client else "Create Project Folder"
        dialog = W.QDialog(self)
        dialog.setWindowTitle(title)
        dialog.setMinimumWidth(390)
        form = W.QFormLayout(dialog)
        client_field = W.QLineEdit()
        project_field = W.QLineEdit()
        if creating_client:
            form.addRow("Client Folder Name", client_field)
        else:
            form.addRow("Client", W.QLabel(client))
        form.addRow("Project Folder Name (optional)" if creating_client else "Project Folder Name",
                    project_field)
        status = W.QLabel()
        status.setWordWrap(True)
        form.addRow(status)
        buttons = W.QDialogButtonBox(W.QDialogButtonBox.Cancel)
        create_button = buttons.addButton(title, W.QDialogButtonBox.AcceptRole)
        create_button.setDefault(True)
        form.addRow(buttons)

        def create():
            try:
                client_name = clean(client_field.text()) if creating_client else leaf(client)
                project_text = project_field.text().strip()
                project_name = clean(project_text) if project_text or not creating_client else ""
                folder = self.base() / client_name
                if creating_client:
                    folder.mkdir(parents=self.drive.currentIndex() == 1, exist_ok=True)
                if project_name:
                    (folder / project_name).mkdir(exist_ok=True)
            except (ValueError, OSError) as error:
                status.setText(str(error))
                return
            if creating_client:
                self.clients()
                self.client.setCurrentText(client_name)
            else:
                self.projects()
            if project_name:
                self.project.setCurrentText(project_name)
            dialog.accept()

        buttons.accepted.connect(create)
        buttons.rejected.connect(dialog.reject)
        dialog.exec_()

    def scene_parts(self):
        project = clean(self.project.currentText())
        category = self.category.currentText()
        variant = clean((self.custom.text() or self.unit.currentText()) if category=="units" else self.shot.text())
        separator = "_SI_" if category == "superimpose" else "_"
        scene_variant = variant
        if category == "units" and self.area.text().strip():
            scene_variant += "_" + clean(self.area.text())
        return category, variant, f"{project}{separator}{scene_variant}_v01_{clean(getpass.getuser())}.max"

    def update_preview(self):
        try:
            name = self.scene_parts()[2]
        except ValueError:
            name = ""
        self.scene_preview.setText(name)
        self.scene_preview.setToolTip(name)

    def create(self):
        category, variant, filename = self.scene_parts()
        special = category=="superimpose"
        root = self.scene_folder(category, variant)
        folder = root/"3ds"
        scene = folder/filename
        if scene.exists() and not message(self.title,f"Overwrite {scene}?",True,self):
            return
        renderer = self.renderer.currentText()
        instance = renderer_instance(renderer)
        dirs = ["3ds/"+n for n in ("autobackup","maps","proxies","exports","archives")]
        dirs += (["_renders","ae","nuke","plates","tracks"] if special else
                 ["3ds/_renders/_prev/_temp","3ds/_renders/360","ue/imports","_cad","_moodboards"] +
                 ["d5/imports/"+s for s in ("d5a","fbx","abc","maps")])
        for sub in dirs:
            (root/sub).mkdir(parents=True,exist_ok=True)
        write_project_file(folder)
        if not special:
            rt.pathConfig.setCurrentProjectFolder(str(folder))
        rt.units.DisplayType = rt.Name("Metric")
        rt.units.MetricType = rt.units.SystemType = rt.Name("Centimeters")
        rt.renderers.current = instance
        add_elements(renderer,lightmix=False)
        if renderer=="Corona":
            rt.renderers.current.progressive_passLimit = 10
            rt.renderers.current.denoise_filterType = 2
        if category=="units":
            make_cameras(renderer,self.unit.currentText())
        if not rt.saveMaxFile(str(scene),useNewFile=True):
            raise RuntimeError("3ds Max could not save "+str(scene))
        self.status.setText("Saved "+str(scene))

open_tool = ProjectPanel
