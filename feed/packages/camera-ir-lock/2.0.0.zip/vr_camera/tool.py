from .ui import Panel, W, QtCore, cameras, rt, window

class CameraPanel(Panel):
    def __init__(self):
        super().__init__("Camera IR Lock", 300)
        form = self.group("Render camera")
        self.nodes = cameras()
        self.picker = W.QComboBox()
        self.picker.addItems([c.name for c in self.nodes])
        form.addRow("Camera", self.picker)
        lock = self.button("Set camera and lock", self.lock, True)
        lock.setEnabled(bool(self.nodes))
        form.addRow(self.row(lock, self.button("Unlock", self.unlock)))
        self.status.setText(("Render follows the active viewport." if rt.rendUseActiveView else "Render camera locked.")
                            if self.nodes else "No cameras found in this scene.")
        self.finish()

    def unlock(self):
        if rt.renderSceneDialog.isOpen():
            rt.renderSceneDialog.close()
        rt.rendUseActiveView = True
        self.status.setText("Render follows the active viewport.")

    def lock(self):
        camera = self.nodes[self.picker.currentIndex()]
        if not rt.isValidNode(camera):
            raise ValueError("This camera was removed. Reopen Camera IR Lock.")
        panels = rt.ViewPanelManager
        slots = [(n, rt.Name(f"Floating_ViewPanel_{n}")) for n in range(1,4)]
        available = [(n, key, panels.GetViewPanelIndexFromFloatingID(key)) for n,key in slots]
        available = [item for item in available if item[2] >= 0]
        if not available:
            raise ValueError("No floating viewport is available.")
        slot, key, idx = next((item for item in available if panels.IsViewPanelVisible(item[2])), available[0])
        original = panels.GetActiveViewPanelIndex()
        view = rt.viewport.activeViewport
        try:
            if rt.renderSceneDialog.isOpen():
                rt.renderSceneDialog.close()
            panels.SetFloatingViewPanelVisibility(key, True)
            panels.SetActiveViewPanel(idx)
            rt.viewport.activeViewport = 1
            rt.viewport.setCamera(camera)
            rt.rendViewIndex = rt.viewport.getID(1, viewPanelIndex=idx)
            rt.rendUseActiveView = False
        finally:
            panels.SetActiveViewPanel(original)
            if 1 <= view <= rt.viewport.numViews:
                rt.viewport.activeViewport = view
        rt.redrawViews()
        self.status.setText(f"{camera.name} locked in floating viewport {slot}.")

def open_tool():
    host = window()
    dock = W.QDockWidget("VR Tools | Camera IR Lock", host)
    dock.setObjectName("VRToolsCameraIRLock")
    dock.setAttribute(QtCore.Qt.WA_DeleteOnClose)
    dock.setAllowedAreas(QtCore.Qt.AllDockWidgetAreas)
    panel = CameraPanel()
    panel.setWindowFlags(QtCore.Qt.Widget)
    dock.setWidget(panel)
    host.addDockWidget(QtCore.Qt.RightDockWidgetArea, dock)
    return dock
