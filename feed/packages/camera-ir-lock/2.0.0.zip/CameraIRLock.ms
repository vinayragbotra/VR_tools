-- Compatibility entry point for VR Tools menus and existing toolbar buttons.
global VR_Python_vr_camera
(
    local source = try (getThisScriptFilename()) catch (undefined)
    local entry = if source != undefined then (getFilenamePath source + "vr_camera/ui.py") else ""
    if doesFileExist entry then VR_Python_vr_camera = entry
    else if VINAY_LOCAL_DIR != undefined do VR_Python_vr_camera = VINAY_LOCAL_DIR + "vr_camera/ui.py"
)

macroScript CameraIRLockTool category:"VR_tools" buttonText:"Camera IR Lock" (
    on execute do (
        if VR_Python_vr_camera == undefined do VR_Python_vr_camera = (getEnvVariable "LOCALAPPDATA") + "/VR_tools/scripts/vr_camera/ui.py"
        python.Execute "__import__('runpy').run_path(str(__import__('pymxs').runtime.VR_Python_vr_camera))['launch']('open_tool')"
    )
)
