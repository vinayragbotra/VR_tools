-- Compatibility entry point for VR Tools menus and existing toolbar buttons.
global VR_Python_vr_batch
(
    local source = try (getThisScriptFilename()) catch (undefined)
    local entry = if source != undefined then (getFilenamePath source + "vr_batch/ui.py") else ""
    if doesFileExist entry then VR_Python_vr_batch = entry
    else if VINAY_LOCAL_DIR != undefined do VR_Python_vr_batch = VINAY_LOCAL_DIR + "vr_batch/ui.py"
)

macroScript VR_Batch_Render_Setup category:"VR_tools" buttonText:"Batch Render Setup" (
    on execute do (
        if VR_Python_vr_batch == undefined do VR_Python_vr_batch = (getEnvVariable "LOCALAPPDATA") + "/VR_tools/scripts/vr_batch/ui.py"
        python.Execute "__import__('runpy').run_path(str(__import__('pymxs').runtime.VR_Python_vr_batch))['launch']('open_tool')"
    )
)
