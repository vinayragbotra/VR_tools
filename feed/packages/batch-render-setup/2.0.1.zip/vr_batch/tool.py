import os
import subprocess
import tempfile
from pathlib import Path
from .ui import Panel, W, cameras, leaf, message, rt

def output_path(base, camera, preview, version, patch=False):
    parts = base.parts
    project = unit = ""
    for i,part in enumerate(parts):
        if part.lower()=="archviz" and 0<i<len(parts)-1:
            project,unit = parts[i-1],parts[i+1]
            variant = parts[i+2] if i+2<len(parts) else ""
            if "bhk" in variant.lower() or "rk" in variant.lower() or variant.lower().startswith("studio"):
                unit = variant
    prefix = "cam360_"+unit+"_"
    cam = camera[len(prefix):] if camera.lower().startswith(prefix.lower()) else camera
    cam = leaf(cam.removeprefix("360_"))
    tag = f"v{version:02d}"
    folder = base/"_renders"
    if preview:
        folder = folder/"_prev"/"360"/("_".join(filter(None,[project,unit,tag])))
    else:
        folder = folder/"360"/tag/cam
    if patch:
        folder /= "_patch"
    return folder/("_".join(filter(None,[project,unit,cam,tag]))+(".jpg" if preview else ".exr"))

def renderer_kind():
    name = str(rt.classOf(rt.renderers.current)).lower().replace("_","")
    return "Corona" if "corona" in name else "V-Ray" if "vray" in name else ""

def clear_outputs():
    rt.rendSaveFile = False
    rt.rendOutputFilename = ""
    manager = rt.maxOps.GetCurRenderElementMgr()
    for i in range(manager.NumRenderElements()):
        try:
            manager.SetRenderElementFileName(i,"")
        except RuntimeError:
            manager.GetRenderElement(i).outputFileName = ""

def spin(lo,hi,value):
    widget = W.QSpinBox()
    widget.setRange(lo,hi)
    widget.setValue(value)
    return widget

class BatchPanel(Panel):
    def __init__(self):
        super().__init__("Batch Render Setup",450)
        self.custom = ""
        self.mode = 0
        self.settings = [[rt.renderWidth,rt.renderHeight,passes,True] for passes in (5,20)]
        form = self.group("Render settings")
        self.kind,self.patch = W.QComboBox(),W.QComboBox()
        self.kind.addItems(["Preview (JPG)","Final (EXR)"])
        self.patch.addItems(["Normal (new version)","Patch (same version)"])
        self.version = spin(1,999,1)
        form.addRow("Render type",self.row(self.kind,self.patch))
        form.addRow("Version",self.version)
        self.width_box,self.height_box = spin(1,20000,rt.renderWidth),spin(1,20000,rt.renderHeight)
        self.ratio = W.QCheckBox("Lock ratio")
        self.ratio.setChecked(True)
        self.aspect = self.width_box.value()/self.height_box.value()
        form.addRow("Width × height",self.row(self.width_box,self.height_box,self.ratio))
        self.passes = spin(1,999,5)
        self.denoise = W.QCheckBox("Denoise")
        self.denoise.setChecked(True)
        form.addRow("V-Ray quality" if renderer_kind()=="V-Ray" else "Render passes",self.row(self.passes,self.denoise))
        camera_group = W.QGroupBox("Cameras")
        camera_layout = W.QVBoxLayout(camera_group)
        self.body.addWidget(camera_group, 1)
        self.cam_list = W.QListWidget()
        self.cam_list.setSelectionMode(W.QAbstractItemView.ExtendedSelection)
        camera_layout.addWidget(self.cam_list, 1)
        camera_layout.addLayout(self.row(self.button("Select all",self.cam_list.selectAll),
                                         self.button("Select none",self.cam_list.clearSelection),
                                         self.button("Refresh",self.refresh_cams)))
        form = self.group("Output")
        self.path = W.QLineEdit()
        self.path.setReadOnly(True)
        form.addRow("Preview",self.path)
        form.addRow(self.row(self.button("Browse folder",self.browse),self.button("Open folder",lambda:self.reveal(False)),
                             self.button("Reveal file",lambda:self.reveal(True))))
        self.net = W.QCheckBox("Net render")
        self.net.setChecked(True)
        self.queue_button = self.button("Add to Batch Render",lambda:self.apply(False),True)
        self.render_button = self.button("Render",lambda:self.apply(True))
        self.body.addLayout(self.row(self.net,self.queue_button,self.render_button))
        self.kind.currentIndexChanged.connect(self.switch_mode)
        self.patch.currentIndexChanged.connect(self.preview)
        self.version.valueChanged.connect(self.preview)
        self.ratio.toggled.connect(self.set_ratio)
        self.width_box.valueChanged.connect(lambda v:self.resize_other(v,True))
        self.height_box.valueChanged.connect(lambda v:self.resize_other(v,False))
        self.cam_list.itemSelectionChanged.connect(self.preview)
        self.refresh_cams()
        self.finish()

    def set_ratio(self, *_):
        self.aspect = self.width_box.value()/self.height_box.value()

    def resize_other(self,value,width):
        if self.ratio.isChecked():
            other = self.height_box if width else self.width_box
            other.blockSignals(True)
            other.setValue(max(1,round(value/self.aspect if width else value*self.aspect)))
            other.blockSignals(False)

    def switch_mode(self,index):
        self.settings[self.mode] = [self.width_box.value(),self.height_box.value(),self.passes.value(),self.denoise.isChecked()]
        self.mode = index
        w,h,p,d = self.settings[index]
        for widget,val in [(self.width_box,w),(self.height_box,h),(self.passes,p)]:
            widget.blockSignals(True)
            widget.setValue(val)
            widget.blockSignals(False)
        self.denoise.setChecked(d)
        self.set_ratio()
        self.preview()

    def selected(self):
        return [self.nodes[i] for i in range(self.cam_list.count()) if self.cam_list.item(i).isSelected()]

    def refresh_cams(self):
        self.cam_list.clear()
        self.nodes = cameras()
        self.cam_list.addItems([cam.name for cam in self.nodes])
        self.cam_list.selectAll()
        self.preview()

    def browse(self):
        path = W.QFileDialog.getExistingDirectory(self,"Custom output folder",self.custom or str(rt.maxFilePath))
        if path:
            self.custom = path
            self.preview()

    def preview(self,*_):
        nodes = self.selected()
        base = self.custom or str(rt.maxFilePath)
        self.queue_button.setEnabled(bool(nodes))
        self.render_button.setEnabled(bool(nodes))
        p = output_path(Path(base),nodes[0].name,self.mode==0,self.version.value(),bool(self.patch.currentIndex())) if base and nodes else ""
        self.path.setText(str(p))
        self.path.setToolTip(str(p))

    def reveal(self,file):
        if not self.path.text():
            raise ValueError("Choose a camera and an output folder first.")
        p = Path(self.path.text())
        if file and p.is_file():
            subprocess.Popen(["explorer.exe","/select,"+str(p)])
        else:
            ancestor = next((p for p in p.parents if p.is_dir()),None)
            if ancestor:
                os.startfile(ancestor)

    def apply(self,render):
        nodes = self.selected()
        base = self.custom or str(rt.maxFilePath)
        if not base or not nodes or not all(rt.isValidNode(c) for c in nodes):
            raise ValueError("Save the scene or choose a folder and select existing cameras.")
        if render:
            if not str(rt.maxFileName):
                raise ValueError("Save the scene first.")
            if message(self.title,"Save the current scene before rendering?",True,self):
                if not rt.saveMaxFile(str(Path(str(rt.maxFilePath))/str(rt.maxFileName))):
                    raise RuntimeError("Scene save failed.")
        preview = self.mode==0
        patch = bool(self.patch.currentIndex())
        version = self.version.value()
        def exists(v):
            return any(output_path(Path(base),c.name,preview,v).is_file() for c in nodes)
        if patch:
            # Enumerate version folders once, then inspect existing camera outputs.
            example = output_path(Path(base),nodes[0].name,preview,version)
            versions = example.parent.parent if preview else example.parent.parent.parent
            import re
            matches = (re.search(r"v([0-9]+)$",p.name,re.I) for p in versions.iterdir() if p.is_dir()) if versions.is_dir() else ()
            version = max((int(m[1]) for m in matches if m and exists(int(m[1]))),default=version)
        else:
            while exists(version):
                version += 1
        if version>999:
            raise ValueError("All supported version numbers are in use.")
        self.version.setValue(version)
        outputs = [output_path(Path(base),c.name,preview,version,patch) for c in nodes]
        if len(set(outputs))!=len(nodes):
            raise ValueError("Two selected cameras produce the same output filename.")
        for path in outputs:
            path.parent.mkdir(parents=True,exist_ok=True)
        mgr = rt.maxOps.GetCurRenderElementMgr()
        active = mgr.GetElementsActive()
        renderer = rt.renderers.current
        kind = renderer_kind()
        settings = [(rt,"renderWidth",self.width_box.value()),(rt,"renderHeight",self.height_box.value())]
        if kind=="Corona":
            settings += [(renderer,"progressive_passLimit",self.passes.value()),(renderer,"denoise_filterType",2 if self.denoise.isChecked() else 0)]
        elif kind=="V-Ray":
            quality = max(0,min(1,(self.passes.value()-1)/29))
            settings.append((renderer,"imageSampler_noiseThreshold",0.05*(1-quality*0.96)))
            if rt.isProperty(renderer,rt.Name("denoiser_enabled")):
                settings.append((renderer,"denoiser_enabled",self.denoise.isChecked()))
        previous = [(o,k,getattr(o,k)) for o,k,v in settings]
        success = False
        try:
            for obj,key,value in settings:
                setattr(obj,key,value)
                if abs(float(getattr(obj,key))-float(value))>0.00001:
                    raise RuntimeError("Could not set "+key)
            clear_outputs()
            mgr.SetElementsActive(not preview)
            rt.rendSaveFile = True
            rt.rendOutputFilename = str(Path(tempfile.gettempdir())/("brs_init"+outputs[0].suffix))
            batch = rt.batchRenderMgr
            try:
                while batch.numViews:
                    batch.DeleteView(batch.numViews)
                for cam,path in zip(nodes,outputs):
                    job = batch.CreateView(cam)
                    job.name = cam.name
                    job.enabled = True
                    job.width,job.height = self.width_box.value(),self.height_box.value()
                    job.outputFilename = str(path)
            finally:
                rt.rendOutputFilename = ""
                rt.rendSaveFile = False
            if render:
                batch.netRender = self.net.isChecked()
                batch.Render()
            success = True
        finally:
            if preview or not success:
                mgr.SetElementsActive(active)
            if not success or (preview and render):
                for obj,key,old in previous:
                    setattr(obj,key,old)
        self.status.setText(f"{len(nodes)} view(s) "+("submitted." if render else "added to Batch Render."))

open_tool = BatchPanel
