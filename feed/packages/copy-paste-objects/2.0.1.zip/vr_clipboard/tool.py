from pathlib import Path
import filecmp
import json
import os
import shutil
import tempfile
import zipfile

from .ui import rt, message


def clipboard(directory=None):
    return Path(directory or Path(str(rt.getDir(rt.Name("temp")))) / "MaxClipboard") / "pastefile.max"


def texture_slots(nodes):
    pending = [node.material for node in nodes if node.material is not None]
    visited = set()
    while pending:
        owner = pending.pop()
        handle = int(rt.getHandleByAnim(owner))
        if handle in visited:
            continue
        visited.add(handle)
        is_texture = rt.superClassOf(owner) == rt.TextureMap
        if is_texture:
            for prop in ("filename", "HDRIMapName"):
                if rt.isProperty(owner, prop):
                    path = rt.getProperty(owner, prop)
                    if isinstance(path, str) and path.strip():
                        yield owner, prop, path
        children = [(rt.getNumSubTexmaps, rt.getSubTexmap)]
        if not is_texture:
            children.append((rt.getNumSubMtls, rt.getSubMtl))
        for count, child in children:
            for i in range(1, count(owner) + 1):
                part = child(owner, i)
                if part is not None:
                    pending.append(part)


def path_key(path):
    return os.path.normcase(os.path.normpath(path))


def source_path(raw):
    path = Path(raw)
    if path.is_absolute() and path.is_file():
        return str(path)
    scene = str(rt.maxFilePath)
    if scene and not path.is_absolute():
        for root in (Path(scene), Path(scene) / "maps"):
            candidate = root / path
            if candidate.is_file():
                return str(candidate.resolve())
    resolved = rt.mapPaths.getFullFilePath(raw)
    if resolved:
        candidate = Path(str(resolved))
        if candidate.is_absolute() and candidate.is_file():
            return str(candidate)
    return str(path) if path.is_absolute() else None


def copy_objects(directory=None, notify=True):
    nodes = list(rt.selection)
    if not nodes:
        if notify:
            message("Copy Objects", "Select the objects you want to copy.")
        return False
    textures = {}
    for _, _, path in texture_slots(nodes):
        key = path_key(path)
        if key not in textures:
            textures[key] = source_path(path)
    target = clipboard(directory).with_suffix(".zip")
    target.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(dir=target.parent) as temp:
        staged = Path(temp) / "selection.max"
        if not rt.saveNodes(nodes, str(staged)):
            raise RuntimeError("3ds Max could not save the selected objects.")
        archive = Path(temp) / "selection.zip"
        with zipfile.ZipFile(archive, "w") as payload:
            payload.write(staged, "selection.max")
            payload.writestr("textures.json", json.dumps(textures))
        os.replace(archive, target)
    return True


def collect_texture(source, folder):
    folder.mkdir(parents=True, exist_ok=True)
    index = 0
    while True:
        dest = folder / (source.name if index == 0 else f"{source.stem}_{index}{source.suffix}")
        if dest.is_file() and (path_key(str(source)) == path_key(str(dest)) or filecmp.cmp(source, dest, shallow=False)):
            return dest
        if not dest.exists():
            with tempfile.TemporaryDirectory(dir=folder) as temp:
                staged = Path(temp) / source.name
                shutil.copy2(source, staged)
                try:
                    staged.rename(dest)
                    return dest
                except FileExistsError:
                    continue
        index += 1


def relink_textures(nodes, inventory, maps_folder):
    destinations = {}
    issues = {}
    for owner, prop, old in texture_slots(nodes):
        key = path_key(old)
        if key not in inventory:
            # Max can rewrite a path during merge. Never resolve it against the destination scene.
            issues[old] = "Source path could not be matched after merge"
            continue
        raw = inventory[key]
        if not raw:
            issues[old] = "Source texture missing"
            continue
        source = Path(raw)
        if raw not in destinations:
            destination = source
            if not source.is_file():
                issues[raw] = "Source texture missing"
            elif maps_folder is not None:
                try:
                    destination = collect_texture(source, maps_folder)
                except OSError as exc:
                    issues[raw] = f"Could not copy texture: {exc}"
            destinations[raw] = destination
        try:
            rt.setProperty(owner, prop, str(destinations[raw]))
        except (RuntimeError, TypeError) as exc:
            issues[raw] = f"Could not update texture path: {exc}"
    return issues


def paste_objects(directory=None, notify=True):
    legacy = clipboard(directory)
    archive = legacy.with_suffix(".zip")
    if legacy.is_file() and (not archive.is_file() or legacy.stat().st_mtime_ns > archive.stat().st_mtime_ns):
        return rt.mergeMaxFile(str(legacy), rt.Name("select"))
    if not archive.is_file():
        if notify:
            message("Paste Objects", "Copy some objects first.")
        return False

    scene = str(rt.maxFilePath)
    maps_folder = Path(scene) / "maps" if scene and str(rt.maxFileName) else None
    from pymxs import byref
    with tempfile.TemporaryDirectory(dir=archive.parent) as temp:
        staged = Path(temp) / "selection.max"
        with zipfile.ZipFile(archive) as payload:
            inventory = json.loads(payload.read("textures.json"))
            with payload.open("selection.max") as source, staged.open("wb") as dest:
                shutil.copyfileobj(source, dest)
        ok, merged = rt.mergeMaxFile(str(staged), rt.Name("select"), rt.Name("autoRenameDups"),
                                    rt.Name("renameMtlDups"), mergedNodes=byref(rt.Array()))
        if not ok:
            return False
    issues = relink_textures(merged, inventory, maps_folder)
    if issues:
        for path, issue in issues.items():
            print(f"[Copy/Paste] {path}: {issue}")
        if notify:
            details = "\n".join(f"{path}: {issue}" for path, issue in list(issues.items())[:8])
            more = "\nSee the Listener for the full list." if len(issues) > 8 else ""
            message("Paste Objects", f"Pasted objects with {len(issues)} texture issue(s).\n\n{details}{more}")
    return True

