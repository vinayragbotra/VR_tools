-- Compatibility entry point for VR Tools menus and existing toolbar buttons.
global VR_Python_vr_clipboard
(
    local source = try (getThisScriptFilename()) catch (undefined)
    local entry = if source != undefined then (getFilenamePath source + "vr_clipboard/ui.py") else ""
    if doesFileExist entry then VR_Python_vr_clipboard = entry
    else if VINAY_LOCAL_DIR != undefined do VR_Python_vr_clipboard = VINAY_LOCAL_DIR + "vr_clipboard/ui.py"
)

macroScript Copy_Objects_To_File category:"CG_Tools" buttonText:"Copy Objects" (
    on execute do (
        if VR_Python_vr_clipboard == undefined do VR_Python_vr_clipboard = (getEnvVariable "LOCALAPPDATA") + "/VR_tools/scripts/vr_clipboard/ui.py"
        python.Execute "__import__('runpy').run_path(str(__import__('pymxs').runtime.VR_Python_vr_clipboard))['launch']('copy_objects')"
    )
)

macroScript Paste_Objects_From_File category:"CG_Tools" buttonText:"Paste Objects" (
    on execute do (
        if VR_Python_vr_clipboard == undefined do VR_Python_vr_clipboard = (getEnvVariable "LOCALAPPDATA") + "/VR_tools/scripts/vr_clipboard/ui.py"
        python.Execute "__import__('runpy').run_path(str(__import__('pymxs').runtime.VR_Python_vr_clipboard))['launch']('paste_objects')"
    )
)
