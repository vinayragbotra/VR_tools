from pathlib import Path
import os
import tempfile
from .ui import rt, message

def clipboard(directory=None):
    return Path(directory or Path(str(rt.getDir(rt.Name("temp")))) / "MaxClipboard") / "pastefile.max"

def copy_objects(directory=None, notify=True):
    nodes = list(rt.selection)
    if not nodes:
        if notify:
            message("Copy Objects", "Select the objects you want to copy.")
        return False
    target = clipboard(directory)
    target.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(dir=target.parent) as temp:
        staged = Path(temp)/"selection.max"
        if not rt.saveNodes(nodes, str(staged)):
            raise RuntimeError("3ds Max could not save the selected objects.")
        os.replace(staged, target)
    return True

def paste_objects(directory=None, notify=True):
    source = clipboard(directory)
    if not source.is_file():
        if notify:
            message("Paste Objects", "Copy some objects first.")
        return False
    return rt.mergeMaxFile(str(source), rt.Name("select"))
