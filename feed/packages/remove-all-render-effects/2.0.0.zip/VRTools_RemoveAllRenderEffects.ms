-- Compatibility entry point for VR Tools menus and existing toolbar buttons.
global VR_Python_vr_effects
(
    local source = try (getThisScriptFilename()) catch (undefined)
    local entry = if source != undefined then (getFilenamePath source + "vr_effects/ui.py") else ""
    if doesFileExist entry then VR_Python_vr_effects = entry
    else if VINAY_LOCAL_DIR != undefined do VR_Python_vr_effects = VINAY_LOCAL_DIR + "vr_effects/ui.py"
)

macroScript VRTools_RemoveAllRenderEffects category:"VR_tools" buttonText:"Remove All Render Effects" (
    on execute do (
        if VR_Python_vr_effects == undefined do VR_Python_vr_effects = (getEnvVariable "LOCALAPPDATA") + "/VR_tools/scripts/vr_effects/ui.py"
        python.Execute "__import__('runpy').run_path(str(__import__('pymxs').runtime.VR_Python_vr_effects))['launch']('open_tool')"
    )
)
