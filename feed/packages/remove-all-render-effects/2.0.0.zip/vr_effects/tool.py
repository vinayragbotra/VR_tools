from .ui import rt, message

def open_tool():
    title = "Remove All Render Effects"
    count = int(rt.numEffects)
    if count == 0:
        message(title, "This scene has no render effects.")
        return
    names = [str(rt.getEffect(i).name) for i in range(1, min(count,12)+1)]
    if count > 12:
        names.append(f"and {count-12} more")
    if message(title, f"Remove {count} render effect(s)?\n\n" + "\n".join(names), confirm=True):
        for i in range(count, 0, -1):
            rt.deleteEffect(i)
        message(title, f"Removed {count} render effect(s). The scene has not been saved.")
