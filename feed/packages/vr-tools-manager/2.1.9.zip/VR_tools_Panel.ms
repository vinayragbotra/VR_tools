-- VR Tools 2.1.0: thin launcher. No live menu rebuilds or retained CUI pointers.
-- Menus are created ONLY inside Autodesk's registration notification.
global VINAY_PANEL_DIR = getFilenamePath (getThisScriptFilename())
global VT_THIS_FILE = getThisScriptFilename()
global VINAY_LOCAL_DIR = VINAY_PANEL_DIR + "scripts/"
global VT_OpenPanel
global VT_CuiRegisterMenus


fn VT_OpenPanel show:true = (
    if not show do return true
    if not doesFileExist (VINAY_PANEL_DIR + "vrtools_manager/ui.py") do (
        messageBox "VR Tools manager files are missing. Run VR_tools_install.ms from the complete extracted installer." title:"VR Tools"
        return false
    )
    python.Execute "exec('import sys\\nfrom pymxs import runtime as rt\\nd=str(rt.VINAY_PANEL_DIR)\\nif d not in sys.path: sys.path.insert(0,d)\\nfrom vrtools_manager.ui import queue_show\\nqueue_show(d)', {})"
    true
)

-- Existing menu actions call this global function, so no action-table replacement
-- is needed in an already-running session.
if VRTools_MacroRegistered != true do (
    macroScript VRToolsPanel category:"VR_tools" buttonText:"VR Tools" tooltip:"VR Tools Script Manager" (
        on execute do VT_OpenPanel()
    )
    global VRTools_MacroRegistered = true
)


fn VT_MenuRows copyOnly:false = (
    local file = VINAY_PANEL_DIR + "menu_actions.ini"
    local keys = filterString (getINISetting file "menu" "keys") ","
    local rows = #()
    for key in keys do (
        local toolId = getINISetting file key "tool"
        if (not copyOnly) or toolId == "copy-paste-objects" do (
            local title = getINISetting file key "title"
            if title != "" do append rows #(key, title)
        )
    )
    rows
)

fn VT_PopulateInstalled menuRoot copyOnly:false = (
    local rows = VT_MenuRows copyOnly:copyOnly
    for i = 1 to rows.count do menuRoot.AddItem i rows[i][2]
    rows
)

fn VT_RunMenuAction key = (
    global VT_ActionKey = key
    python.Execute "exec('import sys\\nfrom pymxs import runtime as rt\\nd=str(rt.VINAY_PANEL_DIR)\\nif d not in sys.path: sys.path.insert(0,d)\\nfrom vrtools_manager.menus import queue_action\\nqueue_action(d,str(rt.VT_ActionKey))', {})"
)

if (maxVersion())[8] >= 2025 and VRTools_DynamicRegistered != true do (
    macroScript VRToolsInstalledScripts category:"VR_tools" buttonText:"Installed scripts" (
        local rows = #()
        on populateDynamicMenu menuRoot do (rows = VT_PopulateInstalled menuRoot)
        on dynamicMenuItemSelected id do (
            if id >= 1 and id <= rows.count do VT_RunMenuAction rows[id][1]
        )
    )
    macroScript VRToolsCopyPasteDynamic category:"VR_tools" buttonText:"Copy/Paste Objects" (
        local rows = #()
        on populateDynamicMenu menuRoot do (rows = VT_PopulateInstalled menuRoot copyOnly:true)
        on dynamicMenuItemSelected id do (
            if id >= 1 and id <= rows.count do VT_RunMenuAction rows[id][1]
        )
    )
    global VRTools_DynamicRegistered = true
)

fn VT_HasItem menu itemId = (
    for item in menu.menuItems do (if (stricmp (item.id as string) itemId) == 0 do return true)
    false
)

fn VT_CuiQuadRegister = (
    local qm = callbacks.notificationParam()
    if qm == undefined do return false
    local ctx = qm.GetContextById "ac7c70f8-3f86-4ff5-a510-e4fd6a9c368e"
    if ctx == undefined do return false
    local quad = ctx.GetRightClickMenuByModifiers #nonePressed
    if quad == undefined do return false
    local markerId = "B64BA56F-C021-5D12-B090-764CD3101AC5"
    for pos in #(#TopLeft, #TopRight, #BottomLeft, #BottomRight) do (
        local menu = quad.GetMenuByPos pos
        if menu != undefined do (
            -- Retire only our three legacy Copy/Paste items, only inside this
            -- registration notification. Never clear/rebuild an existing live quad.
            for oldId in #("0c9a1e21-3b4d-4e5f-8a9b-0c1d2e3f4a00", "0c9a1e21-3b4d-4e5f-8a9b-0c1d2e3f4a01", "0c9a1e21-3b4d-4e5f-8a9b-0c1d2e3f4a02") do (
                if VT_HasItem menu oldId do menu.DeleteItem oldId
            )
            local items = menu.menuItems
            for i = 1 to items.count do (
                local text = try (toLower (substituteString items[i].title "&" "")) catch ("")
                if matchPattern text pattern:"clone*" do (
                    if not (VT_HasItem menu markerId) do (
                        local item = undefined
                        if i < items.count then (
                            item = menu.CreateAction markerId 647394 "VRToolsCopyPasteDynamic`VR_tools" beforeId:items[i+1].id
                        ) else (
                            item = menu.CreateAction markerId 647394 "VRToolsCopyPasteDynamic`VR_tools"
                        )
                        item.isFlat = true
                    )
                    global VT_CopyPasteQuadPosition = pos as string
                    return true
                )
            )
        )
    )
    format "[VR Tools] Clone was not found in the default viewport quad.\n"
    false
)

fn VT_CuiRegisterMenus = (
    -- Never retain this interface beyond the notification that owns it.
    local mgr = callbacks.notificationParam()
    if mgr == undefined do return false
    local menuId = "CCBC40B8-15B7-45F0-9FC3-7DA8C319FE79"
    local menu = mgr.GetMenuById menuId
    if menu == undefined do (
        menu = mgr.mainMenuBar.CreateSubMenu menuId "VR_tools"
        menu.CreateAction "84CDDD56-FDB9-48C4-AE62-89BA9480AF64" 647394 "VRToolsPanel`VR_tools" title:"VR Tools"
    )
    local installedId = "7FA19D8F-45B5-5AD3-883A-8FC92AE3D7C5"
    if not (VT_HasItem menu installedId) do (
        menu.CreateSeparator "657CA8C6-1D51-57AB-9A72-1CB279EA7F2D"
        local item = menu.CreateAction installedId 647394 "VRToolsInstalledScripts`VR_tools"
        item.isFlat = true
    )
    true
)

fn VT_RegisterLegacyMenu = (
    if menuMan == undefined do return false
    local menu = menuMan.findMenu "VR_tools"
    if menu == undefined do (
        menu = menuMan.createMenu "VR_tools"
        menuMan.registerMenu menu 0
        (menuMan.getMainMenuBar()).addItem (menuMan.createSubMenuItem "VR_tools" menu) -1
    )
    local hasManager = false
    for i = 1 to menu.numItems() do (if (menu.getItem i).getTitle() == "VR Tools" do hasManager = true)
    if not hasManager do (
        local action = menuMan.createActionItem "VRToolsPanel" "VR_tools"
        action.setTitle "VR Tools"
        action.setUseCustomTitle true
        menu.addItem action -1
    )
    local legacyFile = VINAY_PANEL_DIR + "vrtools_manager/legacy.ms"
    if doesFileExist legacyFile do fileIn legacyFile
    menuMan.updateMenuBar()
    true
)

-- Replace our old callbacks, but never trigger them or reload the menu layout.
callbacks.removeScripts id:#VRT_cui
callbacks.removeScripts id:#VRT_menu_rebuild
callbacks.removeScripts id:#VRT_quad
callbacks.removeScripts id:#CG_CP_quad
if (maxVersion())[8] >= 2025 then (
    callbacks.addScript #cuiRegisterMenus VT_CuiRegisterMenus id:#VRT_cui
    callbacks.addScript #cuiRegisterQuadMenus VT_CuiQuadRegister id:#VRT_quad
) else (
    callbacks.addScript #postSystemStartup "VT_RegisterLegacyMenu()" id:#VRT_menu_rebuild
)

-- FileIn of this launcher is side-effect free during install/startup. Manual
-- evaluation may open the Qt manager after the current MAXScript call returns.
if VRTools_AutoLoad != true do VT_OpenPanel()
