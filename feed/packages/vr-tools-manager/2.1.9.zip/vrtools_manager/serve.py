"""Read-only localhost release-feed server, suitable as a Cloudflare Tunnel origin."""
import argparse
from functools import partial
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlsplit, unquote


class FeedHandler(SimpleHTTPRequestHandler):
    def list_directory(self, path):
        self.send_error(404, 'Directory listings are disabled')
        return None

    def send_head(self):
        path = unquote(urlsplit(self.path).path)
        root = Path(self.directory).resolve()
        target = (root / path.lstrip('/')).resolve()
        if not target.is_relative_to(root) or target.suffix not in ('.json', '.zip', '.mzp'):
            self.send_error(404)
            return None
        return super().send_head()

    def end_headers(self):
        self.send_header('X-Content-Type-Options', 'nosniff')
        self.send_header('Cache-Control', 'no-store' if self.path.split('?')[0].endswith('catalog.json') else 'no-cache')
        super().end_headers()


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--directory', default=str(Path(__file__).resolve().parents[1] / 'feed'))
    p.add_argument('--port', type=int, default=8765)
    a = p.parse_args()
    directory = Path(a.directory).resolve()
    if not (directory / 'catalog.json').is_file(): p.error('Publish a feed before starting the server')
    print('VR Tools release feed: http://127.0.0.1:%d (folder: %s)' % (a.port, directory), flush=True)
    ThreadingHTTPServer(('127.0.0.1', a.port), partial(FeedHandler, directory=str(directory))).serve_forever()


if __name__ == '__main__': main()
