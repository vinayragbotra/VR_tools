-- Max 2024 only. Loaded by the manager at postSystemStartup, never on install.
-- Native interfaces stay local; other plugins' items and separators are preserved.

fn VT_LegacyCopyAction index = (
    local rows = VT_MenuRows copyOnly:true
    if rows.count >= index do VT_RunMenuAction rows[index][1]
)

macroScript VRToolsLegacyCopy category:"VR_tools" buttonText:"VR Copy Objects" (
    on execute do VT_LegacyCopyAction 1
)
macroScript VRToolsLegacyPaste category:"VR_tools" buttonText:"VR Paste Objects" (
    on execute do VT_LegacyCopyAction 2
)

fn VT_LegacyRemoveCopyPaste menu = (
    for i = menu.numItems() to 1 by -1 do (
        local item = menu.getItem i
        if findItem #("VR_CP_copy", "VR_CP_paste", "VR Copy Objects", "VR Paste Objects") (item.getTitle()) > 0 do menu.removeItem item
    )
)

fn VT_LegacyAddCopyPaste menu position = (
    menu.addItem (menuMan.createActionItem "VRToolsLegacyCopy" "VR_tools") position
    menu.addItem (menuMan.createActionItem "VRToolsLegacyPaste" "VR_tools") (if position == -1 then -1 else position + 1)
)

fn VT_InstallLegacyCopyPaste = (
    local installed = (VT_MenuRows copyOnly:true).count == 2
    local quad = menuMan.getQuadMenu 1
    local inserted = false
    if quad != undefined do (
        for q = 1 to 4 do (
            local menu = quad.getMenu q
            if menu != undefined do (
                VT_LegacyRemoveCopyPaste menu
                if installed and not inserted do (
                    for i = 1 to menu.numItems() do (
                        local title = toLower (substituteString ((menu.getItem i).getTitle()) "&" "")
                        if matchPattern title pattern:"clone*" do (
                            VT_LegacyAddCopyPaste menu (i + 1)
                            inserted = true
                            exit
                        )
                    )
                )
            )
        )
    )
    local main = menuMan.findMenu "VR_tools"
    if main != undefined do (
        VT_LegacyRemoveCopyPaste main
        if installed do VT_LegacyAddCopyPaste main -1
    )
    if installed and not inserted do format "[VR Tools] Clone was not found in legacy quad 1; Copy/Paste remain available under VR_tools.\n"
    menuMan.updateMenuBar()
    inserted
)

VT_InstallLegacyCopyPaste()
