"""Qt manager UI. Workers do file/network operations; Max calls stay on UI thread."""
from pathlib import Path
import sys
import threading
import traceback
from . import __version__
from .core import Store, version

TAB_NAMES = ("Discover", "Installed", "Updates", "Other scripts")
OTHER_SCRIPT_IDS = frozenset({
    "remove-all-render-effects", "camera-ir-lock", "product-render-views", "render-output-version",
})

RUNTIME_GENERATION = 4  # Legacy native-menu callbacks must not be hot-upgraded.

try:
    from PySide6 import QtCore, QtGui, QtWidgets
except ImportError:
    from PySide2 import QtCore, QtGui, QtWidgets

STYLE = '''
QWidget { background:#141b21; color:#e5ecf0; font-family:Segoe UI; font-size:9pt; }
QFrame#card { background:#1b2731; border:1px solid #30414e; border-radius:7px; }
QFrame#card:hover { border-color:#4a6578; }
QLabel { background:transparent; }
QLabel#title { font-size:15pt; font-weight:600; }
QLabel#name { font-size:10pt; font-weight:600; }
QLabel#muted { color:#9cabb6; }
QLabel#badge { color:#8bd4c8; font-size:8pt; }
QPushButton { background:#2a3b49; padding:5px 9px; border:0; border-radius:4px; }
QPushButton:hover { background:#3a5265; }
QPushButton:disabled { color:#667985; background:#202c35; }
QPushButton#primary { background:#176f99; }
QLineEdit { padding:5px 7px; border:1px solid #354653; border-radius:4px; }
QTabBar { background:#141b21; border:0; }
QTabBar::tab { background:#141b21; border:0; border-bottom:2px solid #30414e; padding:7px 14px; margin:0; }
QTabBar::tab:hover { background:#1b2731; }
QTabBar::tab:selected { background:#1b2731; color:#70d4d0; border-bottom:2px solid #70d4d0; }
QWidget#managerNotice { background:#203341; border-radius:5px; }
QScrollBar:vertical { background:#141b21; width:8px; margin:0; }
QScrollBar::handle:vertical { background:#405665; min-height:28px; border-radius:4px; }
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical { height:0; }
QScrollBar::add-page:vertical, QScrollBar::sub-page:vertical { background:transparent; }
QScrollArea { border:0; }
'''


class Window(QtWidgets.QWidget):
    instance = None

    def __init__(self, root, parent=None):
        super().__init__(parent)
        self.setWindowFlags(QtCore.Qt.Window)
        self.setAttribute(QtCore.Qt.WA_DeleteOnClose)
        self.setWindowTitle('VR Tools - Script Manager')
        self.setStyleSheet(STYLE)
        self.resize(740, 560)
        self.setMinimumSize(620, 360)
        self.store = Store(root)
        self.catalog_data = None
        self.busy = False
        self.manager_changed = False
        self.max_year = 0
        try:
            from pymxs import runtime as rt
            self.max_year = int(rt.maxVersion()[7])
        except Exception:
            pass
        layout = QtWidgets.QVBoxLayout(self)
        layout.setContentsMargins(12, 10, 12, 10)
        layout.setSpacing(6)
        top = QtWidgets.QHBoxLayout()
        brand = QtWidgets.QLabel('VR Tools'); brand.setObjectName('title')
        top.addWidget(brand); top.addStretch()
        top.addWidget(QtWidgets.QLabel('v' + __version__))
        self.settings_btn = self.button('Feed settings', self.settings)
        self.check_btn = self.button('Check updates', self.refresh)
        self.update_btn = self.button('Update all', self.update_all, primary=True)
        for b in (self.settings_btn, self.check_btn, self.update_btn): top.addWidget(b)
        layout.addLayout(top)
        self.search = QtWidgets.QLineEdit(); self.search.setPlaceholderText('Search tools...')
        self.search.textChanged.connect(self.render)
        layout.addWidget(self.search)
        self.tabs = QtWidgets.QTabBar()
        self.tabs.setDrawBase(False)
        for title in TAB_NAMES: self.tabs.addTab(title)
        self.tabs.currentChanged.connect(self.render); layout.addWidget(self.tabs)
        self.manager_notice = QtWidgets.QWidget()
        self.manager_notice.setObjectName('managerNotice')
        self.manager_row = QtWidgets.QHBoxLayout(self.manager_notice)
        self.manager_row.setContentsMargins(9, 5, 5, 5)
        self.manager_text = QtWidgets.QLabel('')
        self.manager_btn = self.button('Update manager', self.update_manager)
        self.manager_row.addWidget(self.manager_text, 1); self.manager_row.addWidget(self.manager_btn)
        layout.addWidget(self.manager_notice); self.manager_notice.hide(); self.manager_btn.hide()
        self.scroll = QtWidgets.QScrollArea(); self.scroll.setWidgetResizable(True)
        layout.addWidget(self.scroll, 1)
        self.status = QtWidgets.QLabel('Ready'); self.status.setWordWrap(True); self.status.setObjectName('muted')
        self.status.setMaximumHeight(36)
        layout.addWidget(self.status)
        self.feed_label = QtWidgets.QLabel('Feed configured - change in Feed settings')
        self.feed_label.setToolTip(self.store.source)
        self.feed_label.setObjectName('muted'); self.feed_label.hide()
        self.settings_btn.setToolTip('Change release feed\n' + self.store.source)
        self.timer = QtCore.QTimer(self); self.timer.setInterval(100); self.timer.timeout.connect(self.poll)
        self.work = None
        # Populate before starting network work; Max must never show an empty catalog
        # merely because a refresh is slow. Qt timers may wait for the host event loop.
        try:
            self.catalog_data = self.store.catalog(False)
            self.status.setText('Showing saved catalog; checking for updates...')
        except Exception:
            pass
        self.render()
        QtCore.QTimer.singleShot(0, self.refresh)

    def button(self, text, callback, primary=False):
        b = QtWidgets.QPushButton(text)
        if primary: b.setObjectName('primary')
        b.clicked.connect(lambda *_: callback())
        return b

    def start(self, description, fn, done):
        if self.busy: return
        self.busy = True
        self.status.setText(description)
        self.settings_btn.setEnabled(False); self.check_btn.setEnabled(False)
        self.update_btn.setEnabled(False); self.manager_btn.setEnabled(False)
        self.render()
        result = {'done': False}
        self.work = (result, done)
        def run():
            try: result['value'] = fn()
            except Exception as e: result['error'] = str(e); result['traceback'] = traceback.format_exc()
            finally: result['done'] = True
        threading.Thread(target=run, daemon=True).start()
        self.timer.start()

    def poll(self):
        if not self.work or not self.work[0]['done']: return
        result, callback = self.work
        self.work = None; self.timer.stop(); self.busy = False
        self.settings_btn.setEnabled(True); self.check_btn.setEnabled(True)
        self.manager_btn.setEnabled(True)
        try:
            if 'error' in result:
                self.status.setText('Failed: ' + result['error'])
                log = self.store.meta / 'last-error.log'
                log.write_text(result['traceback'], encoding='utf-8')
                QtWidgets.QMessageBox.warning(self, 'VR Tools', result['error'] + '\n\nDetails: ' + str(log))
            else: callback(result.get('value'))
        except Exception as e:
            self.status.setText('UI refresh failed: ' + str(e))
        self.render()

    def refresh(self):
        if self.busy: return
        def work():
            from .core import process_lock
            with process_lock(self.store.meta / 'install.lock'): self.store.recover()
            try: return self.store.catalog(), False, ''
            except Exception as e:
                return self.store.catalog(False), True, str(e)
        def done(value):
            self.catalog_data, offline, error = value
            self.status.setText(('Offline - cached catalog. ' + error) if offline else 'Catalog checked. Installed tools run locally.')
            self.sync_menu()
        self.start('Checking release catalog...', work, done)

    def entries(self):
        if not self.catalog_data: return []
        entries = {e['id']: e for e in self.catalog_data['tools']}
        for ident, e in self.store.state()['tools'].items(): entries.setdefault(ident, e)
        return list(entries.values())

    def installed(self, e): return self.store.installed_version(e)

    def is_update(self, e):
        v = self.installed(e)
        return bool(v and version(e['version']) > version(v))

    def compatible(self, e): return not self.max_year or self.max_year >= e.get('min_max', 2024)

    def render(self, *_):
        entries = self.entries()
        available = {e['id'] for e in (self.catalog_data or {}).get('tools', [])}
        counts = [len(available - OTHER_SCRIPT_IDS), sum(bool(self.installed(e)) for e in entries),
                  sum(self.is_update(e) for e in entries), len(available & OTHER_SCRIPT_IDS)]
        for i, name in enumerate(TAB_NAMES):
            self.tabs.setTabText(i, '%s  (%d)' % (name, counts[i]))
        self.update_btn.setText('Update all (%d)' % counts[2])
        self.update_btn.setEnabled(not self.busy and any(self.is_update(e) and self.compatible(e) for e in entries))
        mode = self.tabs.currentIndex()
        query = self.search.text().strip().lower()
        self.status.setToolTip(self.status.text())
        view = QtWidgets.QWidget(); grid = QtWidgets.QGridLayout(view)
        grid.setContentsMargins(0, 0, 0, 0); grid.setSpacing(8)
        grid.setAlignment(QtCore.Qt.AlignTop)
        row = 0
        for e in sorted(entries, key=lambda x: x['name'].lower()):
            iv, update = self.installed(e), self.is_update(e)
            if mode in (0, 3):
                if e['id'] not in available or (e['id'] in OTHER_SCRIPT_IDS) != (mode == 3):
                    continue
            elif (mode == 1 and not iv) or (mode == 2 and not update):
                continue
            if query and query not in (e['name'] + ' ' + e.get('description', '')).lower(): continue
            card = QtWidgets.QFrame(); card.setObjectName('card')
            box = QtWidgets.QVBoxLayout(card)
            box.setContentsMargins(10, 9, 10, 9); box.setSpacing(5)
            info = QtWidgets.QVBoxLayout(); info.setSpacing(2)
            heading = QtWidgets.QHBoxLayout(); heading.setSpacing(8)
            name = QtWidgets.QLabel(e['name']); name.setObjectName('name')
            name.setSizePolicy(QtWidgets.QSizePolicy.Ignored, QtWidgets.QSizePolicy.Preferred)
            name.setToolTip(e['name']); heading.addWidget(name, 1)
            badge = ('%s > %s' % (iv, e['version'])) if update else ('v' + (iv or e['version']))
            badge_label = QtWidgets.QLabel(badge); badge_label.setObjectName('badge')
            badge_label.setToolTip(('Update available' if update else ('Installed' if iv else 'Available')) + '\n3ds Max %s+' % e.get('min_max', 2024))
            heading.addWidget(badge_label); info.addLayout(heading)
            desc = QtWidgets.QLabel(e.get('description', '')); desc.setObjectName('muted')
            desc.setWordWrap(True); desc.setFixedHeight(32)
            desc.setSizePolicy(QtWidgets.QSizePolicy.Ignored, QtWidgets.QSizePolicy.Preferred)
            desc.setToolTip(e.get('description', '') + '\n3ds Max %s+' % e.get('min_max', 2024))
            info.addWidget(desc); box.addLayout(info)
            actions = QtWidgets.QHBoxLayout()
            actions.setSpacing(4)
            actions.addStretch()
            if iv and e['id'] != 'copy-paste-objects':
                run = self.button('Run', lambda e=e: self.run_tool(e), True); run.setEnabled(not self.busy and self.compatible(e)); actions.addWidget(run)
            if not iv or update:
                action = self.button('Update' if iv else 'Install', lambda e=e: self.install([e]), True)
                action.setEnabled(not self.busy and self.compatible(e)); actions.addWidget(action)
            elif iv:
                repair = self.button('Repair', lambda e=e: self.install([e])); repair.setEnabled(not self.busy); actions.addWidget(repair)
            notes = self.button('Details', lambda e=e: QtWidgets.QMessageBox.information(self, e['name'],
                'Available: %s\n\n%s\n\n%s' % (e['version'], e.get('description', ''), e.get('notes') or 'No release notes.')))
            actions.addWidget(notes)
            box.addLayout(actions)
            has_rollback = iv and (self.store.meta / 'rollback' / e['id'] / 'entry.json').is_file()
            if mode == 1 and has_rollback:
                # Keep the compact two-column cards usable at the minimum window width.
                actions = QtWidgets.QHBoxLayout()
                actions.setSpacing(4)
                actions.addStretch()
                box.addLayout(actions)
            if has_rollback:
                rb = self.button('Roll back', lambda e=e: self.rollback(e)); rb.setEnabled(not self.busy); actions.addWidget(rb)
            if mode == 1:
                remove = self.button('Uninstall', lambda e=e: self.uninstall(e))
                remove.setToolTip('Remove ' + e['name'] + ' from this installation')
                remove.setEnabled(not self.busy)
                actions.addWidget(remove)
            grid.addWidget(card, row // 2, row % 2); row += 1
        if not row: grid.addWidget(QtWidgets.QLabel('No tools to show in this view.'), 0, 0)
        grid.setColumnStretch(0, 1)
        grid.setColumnStretch(1, 1)
        old = self.scroll.takeWidget()
        if old: old.deleteLater()
        self.scroll.setWidget(view)
        if self.catalog_data:
            e = self.catalog_data['manager']; newer = version(e['version']) > version(__version__)
            self.manager_text.setText('Manager update available: ' + e['version'] if newer else ('Manager installed. Restart Max to use the update.' if self.manager_changed else ''))
            self.manager_btn.setVisible(newer and not self.manager_changed)
            self.manager_notice.setVisible(newer or self.manager_changed)

    def install(self, entries):
        if self.busy: return
        def work():
            results = []
            for e in entries:
                try: self.store.install(e); results.append(e['name'] + ': installed')
                except Exception as ex: results.append(e['name'] + ': FAILED - ' + str(ex))
            return results
        def done(results):
            self.sync_menu()
            menu_status = 'Restart Max to refresh legacy menus.' if self.max_year and self.max_year < 2025 else 'Menus update when next opened.'
            self.status.setText(' | '.join(results) + ' | ' + menu_status)
        self.start('Downloading and verifying %d package(s)...' % len(entries), work, done)

    def update_all(self):
        self.install([e for e in self.entries() if self.is_update(e) and self.compatible(e)])

    def uninstall(self, e):
        if self.busy:
            return
        name = e['name']
        message = 'Uninstall ' + name + ' from this installation of VR Tools?'
        if any(item['id'] == e['id'] for item in self.catalog_data['tools']):
            tab = 'Other scripts' if e['id'] in OTHER_SCRIPT_IDS else 'Discover'
            message += '\n\nYou can install it again from ' + tab + '.'
        answer = QtWidgets.QMessageBox.question(self, 'Uninstall script', message,
            QtWidgets.QMessageBox.Yes | QtWidgets.QMessageBox.No, QtWidgets.QMessageBox.No)
        if answer != QtWidgets.QMessageBox.Yes:
            return

        def done(_):
            self.sync_menu()
            message = name + ' uninstalled.'
            if self.max_year and self.max_year < 2025:
                message += ' Restart 3ds Max to refresh its menus.'
            self.status.setText(message)
        self.start('Uninstalling ' + name + '...', lambda: self.store.uninstall(e), done)

    def rollback(self, e):
        if QtWidgets.QMessageBox.question(self, 'Roll back', 'Restore the previous installed version of ' + e['name'] + '?') != QtWidgets.QMessageBox.Yes: return
        def done(_): self.sync_menu(); self.status.setText('Previous version restored. Reopen the tool.')
        self.start('Restoring previous package...', lambda: self.store.rollback(e['id']), done)

    def update_manager(self):
        if self.busy or not self.catalog_data: return
        if QtWidgets.QMessageBox.question(self, 'Update manager', 'Install the manager update? Restart 3ds Max afterward to load it.') != QtWidgets.QMessageBox.Yes: return
        def done(_): self.manager_changed = True; self.status.setText('Manager updated. Restart 3ds Max when convenient.')
        self.start('Updating manager...', lambda: self.store.install(self.catalog_data['manager'], manager=True), done)

    def run_tool(self, e):
        if self.busy: return
        from pymxs import runtime as rt
        # Choose installed entry metadata, not a newer catalog entry point.
        entry = self.store.state()['tools'].get(e['id'], e)
        path = str(self.store.root / 'scripts' / entry['main'])
        try:
            if entry['type'] == 'py': rt.python.ExecuteFile(path)
            else:
                rt.fileIn(path)
                from .core import macro_actions
                actions, autorun = macro_actions(Path(path))
                if actions and not autorun:
                    rt.macros.run(actions[0][0], actions[0][1])
        except Exception as ex:
            QtWidgets.QMessageBox.warning(self, e['name'], str(ex))

    def sync_menu(self):
        # Catalog refresh/install is filesystem-only. Never call native CUI APIs
        # here: retained Max menu interfaces can become invalid after UI changes.
        if self.catalog_data:
            self.store.write_menu_catalog(self.catalog_data)

    def settings(self):
        value, ok = QtWidgets.QInputDialog.getText(self, 'Release feed',
            'HTTPS feed URL or local feed folder (containing catalog.json):', text=self.store.source)
        if ok:
            self.store.set_source(value); self.catalog_data = None
            self.feed_label.setToolTip(self.store.source); self.refresh()
            self.settings_btn.setToolTip('Change release feed\n' + self.store.source)

    def closeEvent(self, event):
        if self.busy:
            event.ignore()
            self.status.setText('An installation is in progress. Wait until it finishes before closing.')
            return
        Window.instance = None
        super().closeEvent(event)


def show(root):
    w = Window.instance
    if w is not None:
        w.show(); w.raise_(); w.activateWindow(); return w
    parent = None
    try:
        import qtmax
        parent = qtmax.GetQMaxMainWindow()
    except ImportError: pass
    w = Window(root, parent); Window.instance = w; w.show(); return w


def queue_show(root):
    """Return from the MAXScript installer before constructing Qt widgets."""
    QtCore.QTimer.singleShot(0, lambda: show(root))
