"""File-backed dynamic menu rows. No native menus or tool code run during syncing."""
import configparser
import io
import os
from pathlib import Path
import uuid

NAMESPACE = uuid.UUID('c6b0cc2d-56e5-4f88-aab0-31cefda6cdee')
COPY_LABELS = {'Copy_Objects_To_File': 'Copy Objects', 'Paste_Objects_From_File': 'Paste Objects'}


def write_actions(store, catalog):
    from .core import macro_actions
    installed = store.state()['tools']
    entries = {e['id']: installed.get(e['id'], e) for e in catalog['tools']}
    entries.update(installed)
    config = configparser.ConfigParser(interpolation=None)
    config.optionxform = str
    keys = []
    for e in sorted(entries.values(), key=lambda x: x['name'].casefold()):
        if not store.installed_version(e):
            continue
        path = store.root / 'scripts' / e['main']
        actions = macro_actions(path)[0] if e['type'] == 'ms' else []
        for category, macro in actions or [('', '')]:
            title = e['name']
            if e['id'] == 'copy-paste-objects' and macro in COPY_LABELS:
                title = COPY_LABELS[macro]
            elif len(actions) > 1:
                title += ': ' + macro
            key = uuid.uuid5(NAMESPACE, e['id'] + '/' + category + '/' + macro).hex
            keys.append(key)
            config[key] = {'title': title, 'tool': e['id'], 'macro': macro, 'category': category}
    config['menu'] = {'keys': ','.join(keys)}
    stream = io.StringIO(); config.write(stream)
    destination = store.root / 'menu_actions.ini'
    temporary = destination.with_name('menu_actions.ini.writing')
    # Native MAXScript INI reading recognizes the UTF-16 BOM, including Unicode titles.
    temporary.write_bytes(stream.getvalue().encode('utf-16'))
    os.replace(temporary, destination)
    return destination


def run_action(root, key, runtime=None):
    from .core import Store, read_ini, macro_actions, safe_path
    if runtime is None:
        from pymxs import runtime
    store = Store(root)
    config = read_ini(store.root / 'menu_actions.ini')
    row = config[key]
    catalog = store.catalog(False)
    record = store.state()['tools'].get(row['tool'])
    if record is None:
        record = next(e for e in catalog['tools'] if e['id'] == row['tool'])
    if not store.installed_version(record):
        raise RuntimeError('This tool is no longer installed. Open VR Tools to refresh the catalog.')
    path = store.root / 'scripts' / safe_path(record['main'])
    if not path.resolve().is_relative_to((store.root / 'scripts').resolve()):
        raise ValueError('Tool path escapes the installed scripts folder')
    if record['type'] == 'py':
        return runtime.python.ExecuteFile(str(path))
    actions, autorun = macro_actions(path)
    requested = (row['category'], row['macro'])
    if row['macro'] and requested not in actions:
        raise RuntimeError('Tool actions changed. Open VR Tools to refresh their menu entries.')
    if record['id'] == 'copy-paste-objects':
        # Compatibility with already-installed 1.0.0: load its macro definitions,
        # never its old self-install/live-quad-mutation block.
        data = path.read_bytes()
        text = data.decode('utf-16' if data.startswith((b'\xff\xfe', b'\xfe\xff')) else 'utf-8-sig')
        runtime.execute(text.split('global CG_CP_SelfPath', 1)[0])
    else:
        runtime.fileIn(str(path))
    if row['macro'] and (not autorun or len(actions) > 1):
        return runtime.macros.run(row['category'], row['macro'])


def queue_action(root, key):
    # Let the dynamic menu close before loading/redefining a tool's macros or UI.
    from .ui import QtCore, QtWidgets
    def execute():
        try:
            run_action(root, key)
        except Exception as e:
            print('[VR Tools] Menu action failed:', e)
            QtWidgets.QMessageBox.warning(None, 'VR Tools', str(e))
    QtCore.QTimer.singleShot(0, execute)
