"""Publish immutable ZIPs and swap catalog last. Run with ordinary Python."""
import argparse
import ast
from datetime import datetime, timezone
import io
import json
import os
from pathlib import Path
import re
import zipfile
from . import __version__
from .core import atomic_json, digest, read_ini, safe_path, validate_catalog, version


def package(output, ident, ver, files, **metadata):
    version(ver)
    if ident == 'network-sanity-check-py':
        files = dict(files)
        name = 'nsc/__init__.py'
        marker = b'__version__ = None'
        source = files[name]
        assert source.count(marker) == 1, 'Network Sanity Check version marker missing or duplicated'
        files[name] = source.replace(marker, ('__version__ = ' + repr(ver)).encode('ascii'))
    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer, 'w', zipfile.ZIP_DEFLATED) as z:
        for name, data in sorted(files.items()):
            safe_path(name)
            info = zipfile.ZipInfo(name, (2020, 1, 1, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            z.writestr(info, data)
    data = buffer.getvalue()
    relative = 'packages/%s/%s.zip' % (ident, ver)
    dest = output / relative
    if dest.exists() and dest.read_bytes() != data:
        raise ValueError('%s %s already published with different contents. Bump its version.' % (ident, ver))
    dest.parent.mkdir(parents=True, exist_ok=True)
    if not dest.exists():
        temporary = dest.with_name(dest.name + '.writing')
        temporary.write_bytes(data)
        os.replace(temporary, dest)
    return dict(id=ident, version=ver, package=relative, sha256=digest(data),
                files={n: digest(b) for n, b in files.items()}, **metadata)


def publish(root, output, base_url='', manager_only=False):
    root, output = Path(root).resolve(), Path(output).resolve()
    output.mkdir(parents=True, exist_ok=True)
    manifest = read_ini(root / 'repo/manifest.ini') if not manager_only else None
    tools = validate_catalog(json.loads((output / 'catalog.json').read_text(encoding='utf-8')))['tools'] if manager_only else []
    for name in (manifest.get('scripts', 'list').split(',') if manifest else []):
        name = name.strip()
        section = manifest[name]
        names = [safe_path(x.strip()) for x in section.get('files', section['main']).split(';') if x.strip()]
        files = {}
        for f in names:
            p = root / 'repo' / f
            if not p.resolve().is_relative_to(root / 'repo'):
                raise ValueError('Source escapes repo: ' + f)
            data = p.read_bytes()
            if f.endswith('.py'):
                ast.parse(data.decode('utf-8-sig'), filename=f)
            files[f] = data
        ident = re.sub(r'[^a-z0-9]+', '-', name.lower()).strip('-')
        tools.append(package(output, ident, section['version'], files, name=name,
                             main=section['main'], type=section.get('type', 'ms'),
                             description=section.get('desc', ''),
                             notes=section.get('notes', ''), min_max=int(section.get('min_max', '2024'))))
    files = {f: (root / f).read_bytes() for f in ('VR_tools_Panel.ms', 'VR_tools_install.ms', 'VR_tools_bootstrap.py')}
    files['vrtools_manager/legacy.ms'] = (root / 'vrtools_manager/legacy.ms').read_bytes()
    for f in sorted((root / 'vrtools_manager').glob('*.py')):
        data = f.read_bytes(); ast.parse(data.decode('utf-8-sig'), filename=str(f))
        files['vrtools_manager/' + f.name] = data
    manager = package(output, 'vr-tools-manager', __version__, files, name='VR Tools Manager',
                      notes='Central catalog, verified installs, rollback and online bootstrap.', min_max=2024)
    catalog = validate_catalog({'schema': 1, 'published': datetime.now(timezone.utc).isoformat(),
                                'manager': manager, 'tools': tools})
    bootstrap_files = {'VR_tools_install.ms': files['VR_tools_install.ms'],
                       'VR_tools_bootstrap.py': files['VR_tools_bootstrap.py'],
                       'feed_url.txt': (base_url.strip().rstrip('/') + '\n').encode('utf-8')}
    installer = output / 'VR_Tools_Installer.zip'
    temporary = installer.with_name(installer.name + '.writing')
    with zipfile.ZipFile(temporary, 'w', zipfile.ZIP_DEFLATED) as z:
        for name, data in bootstrap_files.items():
            z.writestr(name, data)
    os.replace(temporary, installer)
    # Native Max package: one file can be run from Scripting > Run Script or dropped
    # into a viewport, without asking the user to extract a source repository.
    mzp = output / 'VR_Tools_Installer.mzp'
    temporary = mzp.with_name(mzp.name + '.writing')
    with zipfile.ZipFile(temporary, 'w', zipfile.ZIP_DEFLATED) as z:
        for name, data in bootstrap_files.items():
            z.writestr(name, data)
        z.writestr('mzp.run', 'name "VR Tools Installer"\nversion 2\nrun "VR_tools_install.ms"\ndrop "VR_tools_install.ms"\nclear temp on MAX exit\n')
    os.replace(temporary, mzp)
    # No catalog change is visible until all packages and the installer are ready.
    atomic_json(output / 'catalog.json', catalog)
    return catalog


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', default=str(Path(__file__).resolve().parents[1]))
    parser.add_argument('--output', required=True, help='Dedicated served release-feed directory')
    parser.add_argument('--base-url', default='', help='HTTPS address embedded in the downloadable installer')
    parser.add_argument('--manager-only', action='store_true', help='Update the manager/installer, retaining published tool packages')
    args = parser.parse_args()
    c = publish(args.root, args.output, args.base_url, args.manager_only)
    print('Published %d tools; manager %s. Catalog: %s' % (len(c['tools']), __version__, Path(args.output) / 'catalog.json'))


if __name__ == '__main__':
    main()
