-- VR Tools 2: extract VR_Tools_Installer.zip, then run this file inside 3ds Max.
-- Keep VR_tools_bootstrap.py beside it. The online source is retained on this PC.
global VTI_SourceDir = getFilenamePath (getThisScriptFilename())
try
(
    python.Execute "__import__('runpy').run_path(__import__('os').path.join(str(__import__('pymxs').runtime.VTI_SourceDir), 'VR_tools_bootstrap.py'))['install_interactive'](str(__import__('pymxs').runtime.VTI_SourceDir))"
)
catch
(
    messageBox ("VR Tools installation failed. See %LOCALAPPDATA%/VR_tools/.vrtools/bootstrap.log and the Python Listener (F11).\n" + (getCurrentException() as string)) title:"VR Tools"
)
