"""VR Tools package manager. Scene operations are confined to ui.py."""
__version__ = "2.1.7"
