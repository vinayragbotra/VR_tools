"""Standard-library-only feed, verification, transactions and rollback. No Max calls."""
import configparser
import contextlib
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import re
import shutil
import tempfile
from urllib.parse import urlsplit, urlencode, unquote
from urllib.request import Request, build_opener, HTTPRedirectHandler
import zipfile

MAX_PACKAGE = 128 * 1024 * 1024
MAX_UNPACKED = 512 * 1024 * 1024
MANAGER_FILES = {'VR_tools_Panel.ms', 'VR_tools_install.ms', 'VR_tools_bootstrap.py'}


def read_ini(path):
    c = configparser.ConfigParser(interpolation=None)
    c.optionxform = str
    p = Path(path)
    if p.exists():
        b = p.read_bytes()
        c.read_string(b.decode('utf-16' if b.startswith((b'\xff\xfe', b'\xfe\xff')) else 'utf-8-sig'))
    return c


def atomic_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + '.writing')
    tmp.write_text(json.dumps(value, indent=2) + '\n', encoding='utf-8')
    os.replace(tmp, path)


def version(v):
    if not isinstance(v, str) or not re.fullmatch(r'\d+\.\d+\.\d+', v):
        raise ValueError('Versions must use three numbers: major.minor.patch')
    return tuple(map(int, v.split('.')))


def safe_path(value):
    if not isinstance(value, str) or not value or '\\' in value or ':' in value:
        raise ValueError('Unsafe package path: %r' % value)
    p = PurePosixPath(value)
    if p.is_absolute() or any(x in ('', '.', '..') or x.endswith((' ', '.')) for x in value.split('/')):
        raise ValueError('Unsafe package path: ' + value)
    for part in p.parts:
        if re.search(r'[<>"|?*\x00-\x1f]', part) or part.split('.')[0].upper() in {
            'CON', 'PRN', 'AUX', 'NUL', *('COM%d' % i for i in range(1, 10)),
            *('LPT%d' % i for i in range(1, 10))}:
            raise ValueError('Invalid Windows file name: ' + value)
    return value


def digest(data):
    return hashlib.sha256(data).hexdigest()


def macro_actions(path):
    """Read MAXScript entry points without invoking Max menu/action APIs."""
    b = Path(path).read_bytes()
    if b.startswith((b'\xff\xfe', b'\xfe\xff')):
        text = b.decode('utf-16')
    else:
        try:
            text = b.decode('utf-8-sig')
        except UnicodeDecodeError:
            text = b.decode('cp1252')
    actions = []
    for match in re.finditer(r'^\s*macroScript\s+([A-Za-z_][A-Za-z_0-9]*)\b([^\(]*)\(', text, re.I | re.M):
        category = re.search(r'\bcategory\s*:\s*"([^"]+)"', match.group(2), re.I)
        if category:
            actions.append((category.group(1), match.group(1)))
    autorun = bool(re.search(r'^(?:try\s*\(\s*)?macros\.run\s+', text, re.I | re.M))
    return actions, autorun


def remove_owned_tree(root, path):
    root, resolved = Path(root).resolve(), Path(path).resolve()
    if resolved == root or not resolved.is_relative_to(root):
        raise ValueError('Refusing cleanup outside the installation metadata')
    shutil.rmtree(path)


class Redirects(HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        if urlsplit(req.full_url).scheme == 'https' and urlsplit(newurl).scheme != 'https':
            raise ValueError('Refusing HTTPS downgrade')
        result = super().redirect_request(req, fp, code, msg, headers, newurl)
        if result and urlsplit(newurl).netloc != urlsplit(req.full_url).netloc:
            for name in list(result.headers):
                if name.lower() in ('cf-access-client-id', 'cf-access-client-secret', 'authorization'):
                    result.remove_header(name)
        return result


def fetch(base, relative, limit=MAX_PACKAGE):
    safe_path(relative)
    u = urlsplit(base)
    if u.scheme in ('http', 'https'):
        if u.scheme == 'http' and u.hostname not in ('localhost', '127.0.0.1', '::1'):
            raise ValueError('Internet feeds must use HTTPS (HTTP is allowed on localhost for testing)')
        headers = {'User-Agent': 'VRTools/2.0', 'Cache-Control': 'no-cache'}
        for env, key in [('VRTOOLS_CF_CLIENT_ID', 'CF-Access-Client-Id'),
                         ('VRTOOLS_CF_CLIENT_SECRET', 'CF-Access-Client-Secret')]:
            if u.hostname == 'vrfiles.animationnodes.com' and os.environ.get(env):
                headers[key] = os.environ[env]
        url = base.rstrip('/') + '/' + relative
        share = re.fullmatch(r'(.*)/public/share/([A-Za-z0-9_-]+)(/.*)?', u.path)
        if share:
            # FileBrowser Quantum serves a browser page at the share URL and bytes at
            # this download endpoint. Keep its share hash scoped to the supplied folder.
            prefix = unquote(share.group(3) or '').strip('/')
            if prefix: safe_path(prefix)
            file_path = '/' + '/'.join(x for x in (prefix, relative) if x)
            url = '%s://%s%s/public/api/resources/download?' % (u.scheme, u.netloc, share.group(1))
            url += urlencode({'file': file_path, 'hash': share.group(2)})
        with build_opener(Redirects()).open(Request(url, headers=headers), timeout=25) as f:
            data = f.read(limit + 1)
    else:
        if u.scheme and len(u.scheme) != 1:
            raise ValueError('Unsupported feed scheme')
        with (Path(base) / relative).open('rb') as f:
            data = f.read(limit + 1)
    if len(data) > limit:
        raise ValueError('Download exceeds size limit')
    return data


def validate_entry(e, manager=False):
    if not isinstance(e, dict):
        raise ValueError('Invalid catalog entry')
    for key in ('id', 'name', 'version', 'package', 'sha256', 'files'):
        if key not in e:
            raise ValueError('Catalog entry missing ' + key)
    if not re.fullmatch(r'[a-z0-9][a-z0-9_-]*', e['id']):
        raise ValueError('Invalid package id')
    version(e['version'])
    safe_path(e['package'])
    if not re.fullmatch('[a-f0-9]{64}', e['sha256']):
        raise ValueError('Invalid package checksum')
    if not isinstance(e['files'], dict) or not e['files'] or len(e['files']) > 10000:
        raise ValueError('Invalid file list')
    seen = set()
    for name, checksum in e['files'].items():
        safe_path(name)
        if name.lower() in seen:
            raise ValueError('Case-insensitive duplicate path')
        seen.add(name.lower())
        if not re.fullmatch('[a-f0-9]{64}', checksum):
            raise ValueError('Invalid file checksum')
        if manager:
            if name not in MANAGER_FILES and not name.startswith('vrtools_manager/'):
                raise ValueError('Unexpected manager file: ' + name)
        elif name.split('/')[0].lower() in ('installed.ini', '.vrtools', 'manager'):
            raise ValueError('Reserved tool path')
    if not manager and (e.get('main') not in e['files'] or e.get('type') not in ('ms', 'py')):
        raise ValueError('Invalid tool entry point')
    if manager and not {'vrtools_manager/core.py', 'vrtools_manager/ui.py', 'vrtools_manager/__init__.py', *MANAGER_FILES}.issubset(e['files']):
        raise ValueError('Incomplete manager package')
    return e


def validate_catalog(c):
    if c.get('schema') != 1 or not isinstance(c.get('tools'), list):
        raise ValueError('Unsupported catalog format')
    validate_entry(c['manager'], manager=True)
    ids, names, paths = set(), set(), set()
    for e in c['tools']:
        validate_entry(e)
        if e['id'] in ids or e['name'].casefold() in names:
            raise ValueError('Duplicate tool id or name')
        if paths.intersection(x.lower() for x in e['files']):
            raise ValueError('Tools cannot own overlapping files')
        ids.add(e['id']); names.add(e['name'].casefold()); paths.update(x.lower() for x in e['files'])
    return c


def unpack(data, entry, destination):
    if digest(data) != entry['sha256']:
        raise ValueError('Package checksum mismatch')
    import io
    with zipfile.ZipFile(io.BytesIO(data)) as z:
        members = z.infolist()
        names = [x.filename for x in members]
        if len(names) != len(set(x.lower() for x in names)) or set(names) != set(entry['files']):
            raise ValueError('ZIP contents differ from catalog')
        if sum(x.file_size for x in members) > MAX_UNPACKED:
            raise ValueError('Unpacked package exceeds size limit')
        for info in members:
            safe_path(info.filename)
            if info.is_dir() or ((info.external_attr >> 16) & 0o170000) == 0o120000:
                raise ValueError('Directory/symlink entry is not allowed')
            b = z.read(info)
            if digest(b) != entry['files'][info.filename]:
                raise ValueError('File checksum mismatch: ' + info.filename)
            p = Path(destination) / info.filename
            p.parent.mkdir(parents=True, exist_ok=True)
            p.write_bytes(b)


@contextlib.contextmanager
def process_lock(path):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('a+b') as f:
        f.seek(0); f.write(b'0'); f.flush(); f.seek(0)
        if os.name == 'nt':
            import msvcrt
            try:
                msvcrt.locking(f.fileno(), msvcrt.LK_NBLCK, 1)
            except OSError:
                raise RuntimeError('Another VR Tools process is installing; try again shortly')
        else:
            import fcntl
            fcntl.flock(f, fcntl.LOCK_EX | fcntl.LOCK_NB)
        try:
            yield
        finally:
            f.seek(0)
            if os.name == 'nt':
                msvcrt.locking(f.fileno(), msvcrt.LK_UNLCK, 1)
            else:
                fcntl.flock(f, fcntl.LOCK_UN)


class Store:
    def __init__(self, root, source=None):
        self.root = Path(root).resolve()
        self.meta = self.root / '.vrtools'
        if not self.meta.resolve().is_relative_to(self.root):
            raise ValueError('Installation metadata escapes the selected folder')
        self.meta.mkdir(parents=True, exist_ok=True)
        self.source = source or read_ini(self.root / 'panel.ini').get('config', 'source', fallback=str(self.root / 'feed'))

    def state(self):
        p = self.meta / 'state.json'
        return json.loads(p.read_text(encoding='utf-8')) if p.exists() else {'tools': {}}

    def catalog(self, refresh=True):
        cache = self.meta / 'catalog.json'
        if refresh:
            c = validate_catalog(json.loads(fetch(self.source, 'catalog.json', 4 * 1024 * 1024)))
            atomic_json(cache, {'source': self.source, 'catalog': c})
            return c
        if not cache.exists():
            raise RuntimeError('No cached catalog; connect to the release feed first')
        cached = json.loads(cache.read_text(encoding='utf-8'))
        if cached['source'] != self.source:
            raise RuntimeError('Cached catalog belongs to a different source')
        return validate_catalog(cached['catalog'])

    def installed_version(self, e):
        record = self.state()['tools'].get(e['id'])
        if record:
            # Check the installed release's files, not files added by a future release.
            return record['version'] if all((self.root / 'scripts' / f).is_file() for f in record['files']) else None
        if not (self.root / 'scripts' / e['main']).is_file():
            return None
        return read_ini(self.root / 'scripts/installed.ini').get('versions', e['name'], fallback='0.0.0')

    def recover(self):
        journal = self.meta / 'transaction.json'
        if journal.exists():
            j = json.loads(journal.read_text(encoding='utf-8'))
            backup = self.meta / 'transaction-backup'
            for rel, existed in j['files'].items():
                safe_path(rel)
                target = self.root / rel
                if existed:
                    target.parent.mkdir(parents=True, exist_ok=True)
                    try:
                        shutil.copy2(backup / rel, target)
                    except PermissionError:
                        # A tool held open on Windows may already contain the original
                        # bytes. Continue restoring the other files in the transaction.
                        if not target.is_file() or target.read_bytes() != (backup / rel).read_bytes():
                            raise
                elif target.is_file():
                    target.unlink()
            journal.unlink()

    def _apply(self, writes, deletes=()):
        # Journal before touching live files; a crash is repaired on next operation.
        self.recover()
        backup = self.meta / 'transaction-backup'
        if backup.exists():
            remove_owned_tree(self.meta, backup)
        touched = set(writes) | set(deletes)
        existed = {}
        for rel in touched:
            safe_path(rel)
            dest = self.root / rel
            # Refuse junction/symlink escapes from the local installation.
            if not dest.resolve().is_relative_to(self.root):
                raise ValueError('Target escapes installation folder')
            existed[rel] = dest.is_file()
            if existed[rel]:
                saved = backup / rel
                saved.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(dest, saved)
        atomic_json(self.meta / 'transaction.json', {'files': existed})
        try:
            for rel, data in writes.items():
                dest = self.root / rel
                dest.parent.mkdir(parents=True, exist_ok=True)
                tmp = dest.with_name(dest.name + '.vrtools-writing')
                tmp.write_bytes(data)
                os.replace(tmp, dest)
            for rel in deletes:
                if rel not in writes:
                    (self.root / rel).unlink(missing_ok=True)
            (self.meta / 'transaction.json').unlink()
        except BaseException:
            self.recover()
            raise

    def install(self, e, manager=False, allow_downgrade=False):
        validate_entry(e, manager)
        with process_lock(self.meta / 'install.lock'):
            self.recover()
            state = self.state()
            if not manager:
                wanted = {name.lower() for name in e['files']}
                for ident, record in state['tools'].items():
                    if ident != e['id'] and wanted.intersection(name.lower() for name in record['files']):
                        raise ValueError('Package would overwrite files owned by ' + ident)
            old = state.get('manager') if manager else state['tools'].get(e['id'])
            installed = old['version'] if old else (None if manager else self.installed_version(e))
            if installed and version(e['version']) < version(installed) and not allow_downgrade:
                raise ValueError('Refusing downgrade; use Roll back for the previous release')
            if old and not old.get('legacy') and old['version'] == e['version'] and old['sha256'] != e['sha256']:
                raise ValueError('Published version was changed; publish a new version number')
            data = fetch(self.source, e['package'])
            with tempfile.TemporaryDirectory(prefix='vrtools-') as temp:
                unpack(data, e, temp)
                prefix = '' if manager else 'scripts/'
                writes = {prefix + f: (Path(temp) / f).read_bytes() for f in e['files']}
            # Preserve one complete previous package, including migrated legacy installs.
            if old is None and installed and not manager:
                old = dict(e, version=installed, legacy=True)
            if old and all((self.root / prefix / f).is_file() for f in old['files']):
                prev = self.meta / 'rollback' / e['id']
                if prev.exists():
                    remove_owned_tree(self.meta, prev)
                for f in old['files']:
                    out = prev / f; out.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copy2(self.root / prefix / f, out)
                snapshot = dict(old, files={f: digest((prev / f).read_bytes()) for f in old['files']})
                atomic_json(prev / 'entry.json', snapshot)
            if manager:
                state['manager'] = e
            else:
                state['tools'][e['id']] = e
                ini = read_ini(self.root / 'scripts/installed.ini')
                if not ini.has_section('versions'):
                    ini.add_section('versions')
                ini.set('versions', e['name'], e['version'])
                import io
                out = io.StringIO(); ini.write(out)
                writes['scripts/installed.ini'] = out.getvalue().encode('utf-8')
            writes['.vrtools/state.json'] = (json.dumps(state, indent=2) + '\n').encode('utf-8')
            deletes = [prefix + f for f in (old or {}).get('files', {}) if f not in e['files']]
            self._apply(writes, deletes)

    def uninstall(self, entry):
        validate_entry(entry)
        tool_id = entry['id']
        if tool_id == 'vr-tools-manager':
            raise ValueError('Select an installed script to uninstall')
        with process_lock(self.meta / 'install.lock'):
            self.recover()
            state = self.state()
            record = state['tools'].pop(tool_id, None)
            if record is None and not self.installed_version(entry):
                return
            installed = validate_entry(record or entry)
            if installed['id'] != tool_id:
                raise ValueError('Installed package ID mismatch')
            other_files = {name.casefold() for other in state['tools'].values() for name in other['files']}
            deletes = []
            for name, checksum in installed['files'].items():
                rel = 'scripts/' + name
                path = self.root / rel
                if path.resolve() != path or name.casefold() in other_files:
                    raise ValueError('Cannot safely remove ' + name)
                # Legacy installs have no file inventory. Only the known entry point
                # and companion files matching the catalog bytes can be identified.
                if record or name == installed['main'] or (path.is_file() and digest(path.read_bytes()) == checksum):
                    deletes.append(rel)

            snapshot_dir = '.vrtools/rollback/' + tool_id + '/'
            snapshot = self.root / snapshot_dir / 'entry.json'
            if snapshot.exists():
                previous = validate_entry(json.loads(snapshot.read_text(encoding='utf-8')))
                if previous['id'] != tool_id:
                    raise ValueError('Rollback package ID mismatch')
                deletes.extend(snapshot_dir + name for name in previous['files'])
                deletes.append(snapshot_dir + 'entry.json')

            writes = {'.vrtools/state.json': (json.dumps(state, indent=2) + '\n').encode('utf-8')}
            versions = 'scripts/installed.ini'
            ini = read_ini(self.root / versions)
            if ini.has_option('versions', installed['name']):
                ini.remove_option('versions', installed['name'])
                out = io.StringIO()
                ini.write(out)
                writes[versions] = out.getvalue().encode('utf-8')
            for rel in (*writes, *deletes):
                path = self.root / rel
                if path.resolve() != path:
                    raise ValueError('Cannot safely remove a tool through a redirected path: ' + rel)
            self._apply(writes, deletes)

    def rollback(self, tool_id):
        with process_lock(self.meta / 'install.lock'):
            self.recover()
            prev = self.meta / 'rollback' / tool_id
            e = json.loads((prev / 'entry.json').read_text(encoding='utf-8'))
            validate_entry(e)
            current = self.state()['tools'][tool_id]
            writes = {'scripts/' + f: (prev / f).read_bytes() for f in e['files']}
            if any(digest(writes['scripts/' + f]) != sha for f, sha in e['files'].items()):
                raise ValueError('Rollback backup checksum mismatch')
            state = self.state(); state['tools'][tool_id] = e
            writes['.vrtools/state.json'] = json.dumps(state, indent=2).encode('utf-8')
            ini = read_ini(self.root / 'scripts/installed.ini'); ini.set('versions', e['name'], e['version'])
            import io
            out = io.StringIO(); ini.write(out)
            writes['scripts/installed.ini'] = out.getvalue().encode('utf-8')
            self._apply(writes, ['scripts/' + f for f in current['files'] if f not in e['files']])

    def write_menu_catalog(self, catalog):
        # Retain installed entries removed from the latest Discover catalog.
        entries = {e['id']: e for e in catalog['tools']}
        for ident, e in self.state()['tools'].items():
            entries[ident] = e
        c = configparser.ConfigParser(interpolation=None)
        c['scripts'] = {'list': ','.join(e['name'] for e in entries.values())}
        for e in entries.values():
            c[e['name']] = {'version': e['version'], 'type': e['type'], 'main': e['main'],
                            'files': ';'.join(e['files']), 'desc': e.get('description', '')}
        p = self.root / 'local_catalog.ini'
        with p.open('w', encoding='utf-8') as f:
            c.write(f)
        from .menus import write_actions
        write_actions(self, catalog)
        return p

    def set_source(self, source):
        source = source.strip().rstrip('/')
        if not source:
            raise ValueError('Enter an HTTPS feed URL or local feed folder')
        c = read_ini(self.root / 'panel.ini')
        if not c.has_section('config'):
            c.add_section('config')
        c.set('config', 'source', source); c.set('config', 'autocheck', '1')
        with (self.root / 'panel.ini').open('w', encoding='utf-8') as f:
            c.write(f)
        self.source = source
