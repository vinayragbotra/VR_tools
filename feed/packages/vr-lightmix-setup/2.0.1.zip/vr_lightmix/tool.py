from .ui import Panel, W, rt
from .elements import add_elements, checklist

class LightMixPanel(Panel):
    def __init__(self):
        super().__init__("LightMix Setup",440)
        form = self.group("Render elements")
        self.renderer = W.QComboBox()
        self.renderer.addItems(["Corona","V-Ray"])
        name = str(rt.classOf(rt.renderers.current)).lower().replace("_","")
        if "vray" in name:
            self.renderer.setCurrentIndex(1)
        self.renderer.setEnabled("vray" not in name and "corona" not in name)
        form.addRow("Renderer",self.renderer)
        self.pending, self.existing = W.QListWidget(), W.QListWidget()
        form.addRow(self.row(W.QLabel("Will add"),W.QLabel("Already exists")))
        form.addRow(self.row(self.pending,self.existing))
        self.renderer.currentTextChanged.connect(self.refresh)
        self.body.addLayout(self.row(self.button("Add render elements",self.apply,True),self.button("Close",self.close)))
        self.refresh()
        self.finish()

    def refresh(self):
        self.pending.clear()
        self.existing.clear()
        for kind,name,exists in checklist(self.renderer.currentText()):
            (self.existing if exists else self.pending).addItem(name or kind)

    def apply(self):
        count = add_elements(self.renderer.currentText())
        self.refresh()
        self.status.setText(f"Added {count} render element(s).")

open_tool = LightMixPanel
