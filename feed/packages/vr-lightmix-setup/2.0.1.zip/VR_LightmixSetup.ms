-- Compatibility entry point for VR Tools menus and existing toolbar buttons.
global VR_Python_vr_lightmix
(
    local source = try (getThisScriptFilename()) catch (undefined)
    local entry = if source != undefined then (getFilenamePath source + "vr_lightmix/ui.py") else ""
    if doesFileExist entry then VR_Python_vr_lightmix = entry
    else if VINAY_LOCAL_DIR != undefined do VR_Python_vr_lightmix = VINAY_LOCAL_DIR + "vr_lightmix/ui.py"
)

macroScript VR_LightmixSetup category:"VR_tools" buttonText:"VR Lightmix Setup" (
    on execute do (
        if VR_Python_vr_lightmix == undefined do VR_Python_vr_lightmix = (getEnvVariable "LOCALAPPDATA") + "/VR_tools/scripts/vr_lightmix/ui.py"
        python.Execute "__import__('runpy').run_path(str(__import__('pymxs').runtime.VR_Python_vr_lightmix))['launch']('open_tool')"
    )
)
