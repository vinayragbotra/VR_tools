"""Bootstrap VR Tools into the current user's LOCALAPPDATA. No pip needed."""
import hashlib
import importlib.util
import io
import json
import os
import re
from pathlib import Path, PurePosixPath
import tempfile
from urllib.parse import urlsplit, urlencode, unquote
from urllib.request import Request, build_opener, HTTPRedirectHandler
import zipfile


class Redirects(HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        if urlsplit(req.full_url).scheme == 'https' and urlsplit(newurl).scheme != 'https':
            raise ValueError('Refusing insecure redirect')
        result = super().redirect_request(req, fp, code, msg, headers, newurl)
        if result and urlsplit(newurl).netloc != urlsplit(req.full_url).netloc:
            for name in list(result.headers):
                if name.lower() in ('cf-access-client-id', 'cf-access-client-secret'):
                    result.remove_header(name)
        return result


def get(source, name, limit):
    parts = name.split('/')
    if not name or '\\' in name or ':' in name or name.startswith('/') or any(x in ('', '.', '..') for x in parts):
        raise ValueError('Invalid download path')
    if source.startswith(('https://', 'http://')):
        u = urlsplit(source)
        if u.scheme == 'http' and u.hostname not in ('localhost', '127.0.0.1', '::1'):
            raise ValueError('Online installer requires HTTPS')
        headers = {'User-Agent': 'VRToolsBootstrap/2.0', 'Cache-Control': 'no-cache'}
        for env, key in [('VRTOOLS_CF_CLIENT_ID', 'CF-Access-Client-Id'), ('VRTOOLS_CF_CLIENT_SECRET', 'CF-Access-Client-Secret')]:
            if u.hostname == 'vrfiles.animationnodes.com' and os.environ.get(env): headers[key] = os.environ[env]
        url = source.rstrip('/') + '/' + name
        share = re.fullmatch(r'(.*)/public/share/([A-Za-z0-9_-]+)(/.*)?', u.path)
        if share:
            prefix = unquote(share.group(3) or '').strip('/')
            if prefix and ('\\' in prefix or ':' in prefix or any(p in ('', '.', '..') for p in prefix.split('/'))):
                raise ValueError('Unsafe share folder')
            url = '%s://%s%s/public/api/resources/download?' % (u.scheme, u.netloc, share.group(1))
            url += urlencode({'file': '/' + '/'.join(x for x in (prefix, name) if x), 'hash': share.group(2)})
        with build_opener(Redirects()).open(Request(url, headers=headers), timeout=30) as f:
            data = f.read(limit + 1)
    else:
        with (Path(source) / name).open('rb') as f: data = f.read(limit + 1)
    if len(data) > limit: raise ValueError('Download exceeds size limit')
    return data



from contextlib import contextmanager

@contextmanager
def verified_core(stage):
    """Load verified helper modules as a private package, never a cached runtime."""
    import sys
    import uuid
    name = '_vrtools_verified_' + uuid.uuid4().hex
    package_path = Path(stage) / 'vrtools_manager'
    try:
        spec = importlib.util.spec_from_file_location(name, package_path / '__init__.py', submodule_search_locations=[str(package_path)])
        package = importlib.util.module_from_spec(spec)
        sys.modules[name] = package
        spec.loader.exec_module(package)
        spec = importlib.util.spec_from_file_location(name + '.core', package_path / 'core.py')
        core = importlib.util.module_from_spec(spec)
        sys.modules[spec.name] = core
        spec.loader.exec_module(core)
        yield core
    finally:
        for key in [key for key in sys.modules if key == name or key.startswith(name + '.')]:
            del sys.modules[key]

def _install(installer_folder, source=None, target=None, register=True, status=lambda step: None):
    if register:
        import sys
        loaded = sys.modules.get('vrtools_manager.ui')
        if loaded is not None and getattr(loaded, 'RUNTIME_GENERATION', 0) < 4:
            raise RuntimeError('Restart 3ds Max before installing: an older VR Tools manager is still loaded.')
    folder = Path(installer_folder)
    if not source:
        config = folder / 'feed_url.txt'
        source = config.read_text(encoding='utf-8-sig').strip() if config.exists() else ''
    if not source and (folder / 'release-config.json').is_file():
        source = json.loads((folder / 'release-config.json').read_text(encoding='utf-8-sig')).get('base_url', '')
    if not source and (folder / 'feed/catalog.json').exists(): source = str(folder / 'feed')
    if not source:
        from pymxs import runtime as rt
        source = rt.getString('Enter the VR Tools HTTPS release-feed URL:')
        if source is None or not str(source).strip(): return False
        source = str(source).strip()
    target = Path(target) if target else Path(os.environ['LOCALAPPDATA']) / 'VR_tools'
    status('download catalog')
    catalog_bytes = get(source, 'catalog.json', 4 * 1024 * 1024)
    catalog = json.loads(catalog_bytes)
    entry = catalog['manager']
    status('download and verify manager')
    data = get(source, entry['package'], 128 * 1024 * 1024)
    if hashlib.sha256(data).hexdigest() != entry['sha256']: raise ValueError('Manager checksum mismatch')
    with tempfile.TemporaryDirectory(prefix='vrtools-bootstrap-') as temp:
        stage = Path(temp)
        with zipfile.ZipFile(io.BytesIO(data)) as z:
            infos = z.infolist()
            if sum(i.file_size for i in infos) > 512 * 1024 * 1024: raise ValueError('Manager package too large')
            if len(infos) != len(entry['files']) or {i.filename for i in infos} != set(entry['files']): raise ValueError('Package file list differs')
            for info in infos:
                name = info.filename
                if (name not in ('VR_tools_Panel.ms', 'VR_tools_install.ms', 'VR_tools_bootstrap.py')
                        and not name.startswith('vrtools_manager/')): raise ValueError('Unexpected manager path')
                if ('\\' in name or ':' in name or PurePosixPath(name).is_absolute()
                        or any(x in ('', '.', '..') for x in name.split('/'))
                        or ((info.external_attr >> 16) & 0o170000) == 0o120000): raise ValueError('Unsafe manager ZIP')
                b = z.read(info)
                if hashlib.sha256(b).hexdigest() != entry['files'][name]: raise ValueError('File checksum mismatch')
                p = stage / name; p.parent.mkdir(parents=True, exist_ok=True); p.write_bytes(b)
        # Reuse the same verified transactional installer as normal client updates.
        with verified_core(stage) as core:
            core.validate_catalog(catalog)
            store = core.Store(target, source)
            status('install verified files')
            store.install(entry, manager=True)
            store.set_source(source)
            core.atomic_json(store.meta / 'catalog.json', {'source': source, 'catalog': catalog})
            store.write_menu_catalog(catalog)
    if register:
        import sys
        from pymxs import runtime as rt
        if str(target) not in sys.path:
            sys.path.insert(0, str(target))
        from vrtools_manager.registration import configure
        status('register startup definitions; no live menu mutation')
        configure(target, rt)
    return True


def install(installer_folder, source=None, target=None, register=True, progress=None):
    """Record the exact stage; never report completed installation after a failure."""
    import traceback
    from datetime import datetime
    target = Path(target) if target else Path(os.environ['LOCALAPPDATA']) / 'VR_tools'
    log = target / '.vrtools' / 'bootstrap.log'
    log.parent.mkdir(parents=True, exist_ok=True)
    def status(step):
        with log.open('a', encoding='utf-8') as f:
            f.write(datetime.now().isoformat() + ' ' + step + '\n')
        if progress is not None:
            progress(step)
    status('start')
    try:
        result = _install(installer_folder, source, target, register, status)
        status('files and startup registered; manager window queued' if result and register else ('files installed' if result else 'cancelled'))
        return result
    except Exception as e:
        status('FAILED: ' + traceback.format_exc())
        raise RuntimeError('VR Tools could not finish installation. ' + str(e) + '\nDetails: ' + str(log)) from e


def install_interactive(installer_folder, source=None, target=None, bundle_root=None):
    """Visible, main-thread Qt shell; downloads/install run in a file-only worker."""
    import sys
    import types
    import threading
    import traceback
    from datetime import datetime
    try:
        from PySide6 import QtCore, QtWidgets
    except ImportError:
        from PySide2 import QtCore, QtWidgets
    anchor = sys.modules.setdefault('_vrtools_installer_dialog', types.ModuleType('_vrtools_installer_dialog'))
    previous = getattr(anchor, 'window', None)
    if previous is not None:
        previous.show(); previous.raise_(); previous.activateWindow()
        return previous
    folder = Path(installer_folder)
    if not source:
        if (folder / 'feed_url.txt').exists():
            source = (folder / 'feed_url.txt').read_text(encoding='utf-8-sig').strip()
        elif (folder / 'release-config.json').exists():
            source = json.loads((folder / 'release-config.json').read_text(encoding='utf-8-sig')).get('base_url')
        elif (folder / 'feed/catalog.json').exists():
            source = str(folder / 'feed')
    target = Path(target) if target else Path(os.environ['LOCALAPPDATA']) / 'VR_tools'
    try:
        import qtmax
        parent = qtmax.GetQMaxMainWindow()
    except ImportError:
        parent = None

    class Installer(QtWidgets.QDialog):
        def __init__(self):
            super().__init__(parent)
            self.setWindowTitle('VR Tools Installer')
            self.setAttribute(QtCore.Qt.WA_DeleteOnClose)
            self.setMinimumWidth(490); self.resize(540, 430)
            self.busy = False; self.finished = False; self.state = None
            layout = QtWidgets.QVBoxLayout(self); layout.setContentsMargins(22, 20, 22, 20); layout.setSpacing(12)
            self.heading = QtWidgets.QLabel('Install VR Tools')
            font = self.heading.font(); font.setPointSize(17); font.setBold(True); self.heading.setFont(font)
            layout.addWidget(self.heading)
            self.message = QtWidgets.QLabel('This installs the VR Tools panel for your Windows account.\n\nYour scene will stay open. Individual tools can be installed from Discover afterward.')
            self.message.setWordWrap(True); self.message.setMinimumHeight(160); layout.addWidget(self.message)
            location = QtWidgets.QLabel('Install location: ' + str(target)); location.setWordWrap(True); layout.addWidget(location)
            self.stage = QtWidgets.QLabel('Ready - click Install VR Tools to begin.'); self.stage.setWordWrap(True); layout.addWidget(self.stage)
            self.bar = QtWidgets.QProgressBar(); self.bar.setRange(0, 1); self.bar.setValue(0); layout.addWidget(self.bar)
            self.details = QtWidgets.QPlainTextEdit(); self.details.setReadOnly(True); self.details.setMaximumHeight(120); self.details.hide(); layout.addWidget(self.details)
            row = QtWidgets.QHBoxLayout(); row.addStretch()
            self.close_button = QtWidgets.QPushButton('Close'); self.close_button.clicked.connect(self.close); row.addWidget(self.close_button)
            self.install_button = QtWidgets.QPushButton('Install VR Tools'); self.install_button.clicked.connect(self.start); self.install_button.setDefault(True); row.addWidget(self.install_button)
            layout.addLayout(row)
            self.timer = QtCore.QTimer(self); self.timer.setInterval(80); self.timer.timeout.connect(self.poll)

        def fail(self, error):
            self.busy = False; self.finished = False; self.timer.stop()
            self.heading.setText('Installation did not finish')
            self.message.setText('VR Tools could not finish installation. Your scene has not been closed. Review the details below, then retry or share the log with the maintainer.')
            self.stage.setText('Log: ' + str(target / '.vrtools/bootstrap.log'))
            self.details.setPlainText(str(error)); self.details.show()
            self.bar.setRange(0, 1); self.bar.setValue(0)
            self.close_button.setEnabled(True); self.install_button.setEnabled(True); self.install_button.setText('Try again')

        def start(self):
            if self.busy: return
            if self.finished:
                self.close(); return
            loaded = sys.modules.get('vrtools_manager.ui')
            if loaded is not None and getattr(loaded, 'RUNTIME_GENERATION', 0) < 4:
                self.fail('Restart 3ds Max before installing: an older VR Tools manager is still loaded.'); return
            if not source:
                self.fail('No download feed was supplied. Download the complete installer again from the VR Tools installation page.'); return
            self.busy = True; self.details.hide(); self.heading.setText('Installing VR Tools...')
            self.message.setText('Downloading and verifying the current panel, then preparing its startup menu. Please wait; no scene changes are made.')
            self.bar.setRange(0, 0); self.install_button.setEnabled(False); self.close_button.setEnabled(False)
            self.state = {'done': False, 'step': 'Connecting to the release feed...', 'error': None}
            state = self.state
            def worker():
                try:
                    install(folder, source=source, target=target, register=False, progress=lambda step: state.update(step=step))
                except Exception as error:
                    state['error'] = str(error)
                finally:
                    state['done'] = True
            threading.Thread(target=worker, daemon=True).start(); self.timer.start()

        def poll(self):
            state = self.state
            if not state: return
            labels = {'start': 'Starting installation...', 'download catalog': 'Checking the latest available version...',
                      'download and verify manager': 'Downloading the panel and verifying its checksum...',
                      'install verified files': 'Installing verified panel files...', 'files installed': 'Panel files installed. Preparing the Max menu...'}
            self.stage.setText(labels.get(state['step'], state['step']))
            if not state['done']: return
            self.timer.stop()
            if state['error']:
                self.fail(state['error']); return
            try:
                from pymxs import runtime as rt
                if str(target) not in sys.path: sys.path.insert(0, str(target))
                from importlib import import_module
                with verified_core(target) as core:
                    registration = import_module(core.__package__ + '.registration')
                    registration.configure(target, rt, launch=False, bundle_root=bundle_root)
                catalog = json.loads((target / '.vrtools/catalog.json').read_text())['catalog']
                version = catalog['manager']['version']
                self.heading.setText('VR Tools installed successfully')
                self.message.setText('Panel version ' + version + ' is installed.\n\n1. Save your work and restart 3ds Max once.\n2. Open VR_tools > VR Tools from the top menu.\n3. Use Discover > Install for the scripts you want.\n\nIf you already had VR Tools, your installed scripts were kept.')
                self.stage.setText('Installation complete - restart Max when convenient.')
                with (target / '.vrtools/bootstrap.log').open('a', encoding='utf-8') as log:
                    log.write(datetime.now().isoformat() + ' interactive installation complete; startup registered; version ' + version + '\n')
                self.busy = False; self.finished = True; self.bar.setRange(0, 1); self.bar.setValue(1)
                self.close_button.setEnabled(True); self.install_button.setEnabled(True); self.install_button.setText('Done')
            except Exception as error:
                with (target / '.vrtools/bootstrap.log').open('a', encoding='utf-8') as log:
                    log.write(datetime.now().isoformat() + ' FAILED registration: ' + traceback.format_exc() + '\n')
                self.fail(str(error))

        def closeEvent(self, event):
            if self.busy:
                event.ignore(); return
            anchor.window = None
            super().closeEvent(event)

    anchor.window = Installer(); anchor.window.show()
    return anchor.window
